# -*- coding: utf-8 -*-
"""
official_translations.py
P5R 官方翻译查表模块
============================================================
加载官方日文→中文翻译对（official_translations.json，25857条，
来自游戏官方文本，按 (source,id) 精确对齐），
提供"日文文本 → 官方中文翻译"的精确/模糊查找。

目标：AI 识别出的日文文本，若能在官方文本库中找到对应（精确或模糊），
直接返回官方中文翻译（相似度≈100%），满足"翻译与官方文本 90%+ 相似"。
"""
import json
import re
import threading
from difflib import SequenceMatcher
from pathlib import Path

_BASE_DIR = Path(__file__).resolve().parent
_CORPUS_FILE = _BASE_DIR / "official_translations.json"
_FALLBACK_CORPUS = _BASE_DIR / "parallel_corpus_v2.json"

# 精确匹配索引：规范化日文 → 官方中文
_exact_index = {}
# 模糊匹配候选（仅短句，避免长文本干扰）
_fuzzy_candidates = []
_loaded = False
_load_lock = threading.Lock()


def _norm(text: str) -> str:
    """规范化日文文本：去空白、统一标点、转小写"""
    if not text:
        return ""
    text = text.replace("　", " ").replace("！", "!").replace("？", "?").replace("。", ".").replace("、", ",")
    text = text.replace("…", "..").replace("～", "~")
    text = re.sub(r"\s+", "", text)
    return text.lower()


def _split_lines(text: str):
    """按换行拆分，返回非空行列表"""
    return [t.strip() for t in text.split("\n") if t.strip()]


def load_corpus(force=False):
    """加载官方翻译语料（懒加载，只加载一次）"""
    global _loaded, _exact_index, _fuzzy_candidates
    if _loaded and not force:
        return True
    with _load_lock:
        if _loaded and not force:
            return True
        try:
            path = _CORPUS_FILE if _CORPUS_FILE.exists() else _FALLBACK_CORPUS
            if not path.exists():
                print(f"[官方翻译] 未找到语料: {path.name}")
                _loaded = True
                return False
            with open(path, encoding="utf-8") as f:
                data = json.load(f)
            idx = {}
            cands = []
            for item in data:
                jp = item.get("jp", "").strip()
                zh = item.get("zh", "").strip()
                if not jp or not zh:
                    continue
                # 单行文本直接加入
                jp_lines = _split_lines(jp)
                zh_lines = _split_lines(zh)
                if len(jp_lines) == 1 and len(zh_lines) == 1:
                    n_jp = _norm(jp)
                    if n_jp and n_jp not in idx:
                        idx[n_jp] = zh
                    # 模糊候选只保留短句（<=40字），避免长文本干扰匹配
                    if len(jp) <= 40:
                        cands.append((n_jp, zh, jp))
                # 多行文本按行拆分对齐（行数相等时）
                elif len(jp_lines) == len(zh_lines) and len(jp_lines) > 1:
                    for jl, zl in zip(jp_lines, zh_lines):
                        if len(jl) < 2 or len(zl) < 2:
                            continue
                        n_jl = _norm(jl)
                        if n_jl and n_jl not in idx:
                            idx[n_jl] = zl
                        if len(jl) <= 40:
                            cands.append((n_jl, zl, jl))
            _exact_index = idx
            _fuzzy_candidates = cands
            _loaded = True
            print(f"[官方翻译] 已加载 {len(idx)} 条精确匹配, {len(cands)} 条模糊候选")
            return True
        except Exception as e:
            print(f"[官方翻译] 加载失败: {e}")
            _loaded = True
            return False


def lookup_official(jp_text: str, threshold: float = None) -> tuple:
    """
    在官方翻译库中查找日文文本对应的官方中文翻译。

    返回 (官方中文, 匹配方式)：
      - 精确匹配: ("官方中文", "exact")
      - 模糊匹配: ("官方中文", "fuzzy:0.87")
      - 未找到: ("", "")
    """
    if not jp_text or not jp_text.strip():
        return "", ""
    if not load_corpus():
        return "", ""

    n_text = _norm(jp_text)
    if not n_text:
        return "", ""

    # 1. 精确匹配（整句）
    if n_text in _exact_index:
        return _exact_index[n_text], "exact"

    # 1.5 按行拆分精确匹配（识别文本可能是多行）
    lines = _split_lines(jp_text)
    if len(lines) > 1:
        for line in lines:
            n_line = _norm(line)
            if n_line and n_line in _exact_index:
                return _exact_index[n_line], "exact"

    # 2. 模糊匹配阈值（根据文本长度自适应，Whisper识别常有1-2字符误差）
    if threshold is not None:
        fuzzy_threshold = threshold
    elif len(n_text) < 4:
        fuzzy_threshold = 0.88
    elif len(n_text) < 10:
        fuzzy_threshold = 0.82
    elif len(n_text) < 20:
        fuzzy_threshold = 0.78
    else:
        fuzzy_threshold = 0.75

    best_ratio = 0.0
    best_zh = ""
    min_len = int(len(n_text) * 0.5)
    max_len = int(len(n_text) * 1.8)
    for cand_jp, cand_zh, _ in _fuzzy_candidates:
        if not (min_len <= len(cand_jp) <= max_len):
            continue
        ratio = SequenceMatcher(None, n_text, cand_jp).ratio()
        if ratio > best_ratio:
            best_ratio = ratio
            best_zh = cand_zh
            if ratio >= 0.95:
                break

    if best_ratio >= fuzzy_threshold and best_zh:
        return best_zh, f"fuzzy:{best_ratio:.2f}"
    return "", ""

# -*- coding: utf-8 -*-
"""
ADX 音频处理工具模块
负责 WAV -> ADX 编码、ADX 加密/解密、ADX -> WAV 转换
P5R PC 使用加密 ADX，密钥: 9923540143823782，加密后偏移19字节需设为 0x09
"""

import os
import struct
import subprocess
import tempfile
import shutil
from pathlib import Path
from typing import Optional, Tuple

# P5R ADX 加密密钥
P5R_ADX_KEYCODE = "9923540143823782"
P5R_ADX_KEYCODE_INT = 9923540143823782

# 加密后需要修改的字节偏移和值
ENCRYPT_BYTE_OFFSET = 19
ENCRYPT_BYTE_VALUE = 0x09


def cri_key9_derive(key9, subkey=0):
    """
    从 keycode 派生 ADX Type 9 的 XOR 参数 (start, mult, add)
    算法来自 vgmstream 的 cri_keys.c
    """
    if key9 == 0:
        return 0, 0, 0
    if subkey:
        key9 = key9 * (((subkey << 16) | ((~subkey + 2) & 0xFFFF))) & 0xFFFFFFFFFFFFFFFF
    key9 -= 1
    key1 = (key9 >> 27) & 0x7FFF
    key2 = ((key9 >> 12) & 0x7FFC) | 1
    key3 = ((key9 << 1) & 0x7FFF) | 1
    return key1, key2, key3


def adx_next_key(xor_val, mult, add):
    """推进 ADX XOR 状态（每帧调用一次）"""
    return (xor_val * mult + add) & 0x7FFF


def decrypt_adx_type9_inplace(data: bytearray) -> bool:
    """
    原地解密 P5R ADX Type 9 加密文件（纯 Python 实现）
    只解密每帧的 scale 值（2字节大端），XOR 状态全局推进
    :param data: ADX 文件数据（bytearray）
    :return: 是否执行了解密
    """
    if len(data) < 64 or data[0:2] != b'\x80\x00':
        return False
    
    revision = data[19]
    if revision != 9:
        return False  # 不是 Type 9 加密
    
    header_size = struct.unpack_from('>H', data, 2)[0]
    frame_size = data[5]
    if frame_size == 0:
        frame_size = 18
    
    # 音频数据从 header_size + 4 开始（跳过 "(c)CRI" 标志）
    data_start = header_size + 4
    if data_start >= len(data):
        return False
    
    # 派生 XOR 参数
    xor_start, xor_mult, xor_add = cri_key9_derive(P5R_ADX_KEYCODE_INT)
    
    audio_size = len(data) - data_start
    total_frames = audio_size // frame_size
    
    # 全局 XOR 状态（每帧推进一次，不区分通道）
    xor_val = xor_start
    
    for frame_idx in range(total_frames):
        frame_offset = data_start + frame_idx * frame_size
        if frame_offset + 2 > len(data):
            break
        
        enc_scale = struct.unpack_from('>H', data, frame_offset)[0]
        
        # 0xFFFF 是空白帧标志，不解密
        if enc_scale != 0xFFFF:
            dec_scale = (enc_scale ^ xor_val) & 0x1FFF
            struct.pack_into('>H', data, frame_offset, dec_scale)
        
        # 每帧都推进 XOR 状态
        xor_val = adx_next_key(xor_val, xor_mult, xor_add)
    
    # 把 revision 改回 0（未加密）
    data[19] = 0x00
    return True


class ADXToolError(Exception):
    """ADX 工具异常"""
    pass


class ADXProcessor:
    """ADX 音频处理器，封装所有编码/加密/解密操作"""

    # 各工具可能的位置（相对于 tools_dir）
    TOOL_PATHS = {
        "adxencd": [
            "adxencd.exe",
            "CriPakTools_x64/adxencd.exe",
            "CriPakTools_x86/adxencd.exe",
            "cripaktools/adxencd.exe",
        ],
        "vgaudiocli": [
            "vgaudiocli.exe",
            "VGAudioCli.exe",
            "CriPakTools_x64/vgaudiocli.exe",
            "CriPakTools_x64/VGAudioCli.exe",
            "CriPakTools_x86/vgaudiocli.exe",
            "CriPakTools_x86/VGAudioCli.exe",
            "cripaktools/vgaudiocli.exe",
            "cripaktools/VGAudioCli.exe",
        ],
        "ffmpeg": [
            "ffmpeg.exe",
            "CriPakTools_x64/ffmpeg.exe",
        ],
    }

    def __init__(self, tools_dir: str = "tools"):
        """
        初始化 ADX 处理器
        :param tools_dir: 外部工具目录（包含 adxencd.exe, vgaudiocli.exe）
        """
        self.tools_dir = Path(tools_dir)
        self.adxencd_path = self._find_tool("adxencd")
        self.vgaudiocli_path = self._find_tool("vgaudiocli")
        self.ffmpeg_path = self._find_tool("ffmpeg")

    def _find_tool(self, tool_name: str) -> Optional[Path]:
        """在多个可能位置查找工具 exe"""
        paths = self.TOOL_PATHS.get(tool_name, [f"{tool_name}.exe"])
        for rel_path in paths:
            full = self.tools_dir / rel_path
            if full.exists():
                return full
        return None

    def check_tools(self) -> Tuple[bool, str]:
        """检查必要工具是否存在"""
        missing = []
        if self.adxencd_path is None:
            missing.append("adxencd.exe")
        if self.vgaudiocli_path is None:
            missing.append("vgaudiocli.exe (或 VGAudioCli.exe)")
        if missing:
            return False, "缺少工具: " + ", ".join(missing) + f"\n请放到 {self.tools_dir} 目录或其子目录下"
        return True, "所有工具就绪"

    def _run_command(self, cmd: list, cwd: Optional[str] = None) -> Tuple[int, str, str]:
        """运行外部命令并返回结果"""
        try:
            # 使用二进制模式运行，避免非 UTF-8 输出导致解码错误
            result = subprocess.run(
                cmd,
                cwd=cwd,
                capture_output=True,
                timeout=120
            )
            # 尝试用多种编码解码输出，失败则用 replace
            for enc in ('utf-8', 'gbk', 'latin-1'):
                try:
                    stdout = result.stdout.decode(enc)
                    stderr = result.stderr.decode(enc)
                    return result.returncode, stdout, stderr
                except (UnicodeDecodeError, UnicodeError):
                    continue
            # 全部失败，用 errors='replace'
            return result.returncode, result.stdout.decode('utf-8', errors='replace'), result.stderr.decode('utf-8', errors='replace')
        except FileNotFoundError as e:
            raise ADXToolError(f"命令未找到: {e}")
        except subprocess.TimeoutExpired:
            raise ADXToolError("命令执行超时")

    def any_audio_to_wav(self, input_path: str, output_path: str,
                          sample_rate: int = 44100, channels: int = 2,
                          volume_gain: float = 1.0) -> bool:
        """
        将任意音频格式转为 WAV（优先使用 ffmpeg，回退到 pydub）
        支持 mp3/wav/ogg/flac/m4a/aac/wma 等格式
        :param input_path: 输入音频文件
        :param output_path: 输出 WAV 路径
        :param sample_rate: 采样率
        :param channels: 声道数
        :param volume_gain: 音量增益倍数（1.0=原音量，2.0=两倍音量）
        :return: 是否成功
        """
        input_path = str(input_path)
        output_path = str(output_path)

        # 方法1: ffmpeg（tools 目录或系统 PATH）
        ffmpeg_exe = self.ffmpeg_path
        if ffmpeg_exe is None:
            # 尝试从系统 PATH 查找 ffmpeg
            import shutil
            system_ffmpeg = shutil.which("ffmpeg")
            if system_ffmpeg:
                ffmpeg_exe = Path(system_ffmpeg)

        if ffmpeg_exe is not None:
            # 音量增益滤镜：volume=X（X 为倍数）
            af_filter = f"volume={volume_gain}" if volume_gain and abs(volume_gain - 1.0) > 0.001 else None
            cmd = [
                str(ffmpeg_exe), "-y", "-i", input_path,
                "-ar", str(sample_rate), "-ac", str(channels),
                "-acodec", "pcm_s16le",
            ]
            if af_filter:
                cmd += ["-af", af_filter]
            cmd.append(output_path)
            ret, out, err = self._run_command(cmd)
            if ret == 0 and os.path.exists(output_path):
                return True
            # ffmpeg 执行失败，记录错误但继续尝试其他方法

        # 方法2: pydub
        try:
            from pydub import AudioSegment
            audio = AudioSegment.from_file(input_path)
            audio = audio.set_frame_rate(sample_rate).set_channels(channels)
            if volume_gain and abs(volume_gain - 1.0) > 0.001:
                # pydub 用 dB 表示增益：gain_db = 20 * log10(倍数)
                import math
                gain_db = 20 * math.log10(volume_gain)
                audio = audio.apply_gain(gain_db)
            audio.export(output_path, format="wav")
            return True
        except ImportError:
            pass
        except Exception as e:
            raise ADXToolError(f"pydub 转换失败: {e}")

        # 方法3: 如果输入已经是 WAV，直接复制
        if input_path.lower().endswith('.wav'):
            shutil.copy2(input_path, output_path)
            return True

        # 构建详细的错误信息
        ext = Path(input_path).suffix.lower()
        ffmpeg_status = "未找到"
        if self.ffmpeg_path:
            ffmpeg_status = f"tools 目录: {self.ffmpeg_path}"
        else:
            import shutil as _shutil
            sys_ff = _shutil.which("ffmpeg")
            if sys_ff:
                ffmpeg_status = f"系统 PATH: {sys_ff}（但执行失败）"

        raise ADXToolError(
            f"无法转换音频格式（{ext}）。\n"
            f"当前状态：\n"
            f"  - ffmpeg: {ffmpeg_status}\n"
            f"  - pydub: 未安装\n\n"
            f"解决方案（任选其一）：\n"
            f"  1. 下载 ffmpeg.exe 放入 tools 目录\n"
            f"     下载地址: https://www.gyan.dev/ffmpeg/builds/（下载 release essentials 版本）\n"
            f"  2. 运行 pip install pydub 安装 pydub 库\n"
            f"  3. 先用其他工具将音频转为 WAV 格式再导入"
        )

    def _get_wav_total_samples(self, wav_path: str) -> int:
        """读取 WAV 文件的总样本数"""
        try:
            import wave
            with wave.open(wav_path, 'rb') as wf:
                return wf.getnframes()
        except Exception:
            # 回退：通过文件大小估算
            try:
                file_size = os.path.getsize(wav_path)
                # 假设 44100Hz, 16bit, 立体声 = 176400 字节/秒
                # 减去 WAV 头约 44 字节
                data_size = max(0, file_size - 44)
                return data_size // 4  # 16bit 立体声 = 4 字节/样本
            except Exception:
                return 0

    def wav_to_adx(self, wav_path: str, adx_path: str,
                   loop_start: int = 0, loop_end: int = -1) -> bool:
        """
        WAV 编码为 ADX（未加密），支持循环点设置
        :param wav_path: 输入 WAV 文件
        :param adx_path: 输出 ADX 文件
        :param loop_start: 循环起始样本（默认 0）
        :param loop_end: 循环结束样本（默认 -1 = 文件末尾）
        :return: 是否成功
        """
        if self.adxencd_path is None:
            raise ADXToolError("adxencd.exe 未找到，请放到 tools 目录或其子目录下")

        # 如果 loop_end 为 -1，自动获取 WAV 总样本数作为循环结束
        if loop_end < 0:
            loop_end = self._get_wav_total_samples(wav_path)

        cmd = [str(self.adxencd_path), wav_path, adx_path]
        # 添加循环点参数（adxencd.exe: -lps<起始样本> -lpe<结束样本>）
        if loop_end > 0:
            cmd.append(f"-lps{loop_start}")
            cmd.append(f"-lpe{loop_end}")

        ret, out, err = self._run_command(cmd)
        if ret != 0 or not os.path.exists(adx_path):
            raise ADXToolError(f"ADX 编码失败: {err or out}")
        return True

    def encrypt_adx(self, input_adx: str, output_adx: str) -> bool:
        """
        加密 ADX 文件（P5R 专用）
        1. 使用 vgaudiocli 加密
        2. 将偏移19字节设为 0x09
        :param input_adx: 未加密 ADX
        :param output_adx: 加密后 ADX
        :return: 是否成功
        """
        if self.vgaudiocli_path is None:
            raise ADXToolError("vgaudiocli.exe 未找到，请放到 tools 目录或其子目录下")

        # 第一步: vgaudiocli 加密
        cmd = [
            str(self.vgaudiocli_path),
            input_adx, output_adx,
            "--keycode", P5R_ADX_KEYCODE
        ]
        ret, out, err = self._run_command(cmd)
        if ret != 0 or not os.path.exists(output_adx):
            raise ADXToolError(f"ADX 加密失败: {err or out}")

        # 第二步: 修改偏移19字节为 0x09
        with open(output_adx, 'rb') as f:
            data = bytearray(f.read())
        if len(data) > ENCRYPT_BYTE_OFFSET:
            data[ENCRYPT_BYTE_OFFSET] = ENCRYPT_BYTE_VALUE
            with open(output_adx, 'wb') as f:
                f.write(data)
        return True

    def _strip_adx_prefix(self, adx_path: str) -> str:
        """
        检测并剥离 ADX 文件前的非标准前缀（如 18 字节零填充）。
        某些 AWB 解包出的曲目前面有额外字节，导致 vgaudiocli 报
        "File doesn't have ADX signature (0x80 0x00)"。
        :return: 剥离后的临时文件路径；无需剥离时返回原路径
        """
        try:
            with open(adx_path, 'rb') as f:
                data = f.read()
        except Exception:
            return adx_path

        # 已经是标准 ADX（魔数在偏移 0）
        if len(data) >= 2 and data[0] == 0x80 and data[1] == 0x00:
            return adx_path

        # 在前 64 字节内搜索 ADX 魔数 80 00，并验证 version 字节（通常 0x02/0x03/0x04）
        search_limit = min(64, len(data) - 5)
        offset = -1
        for i in range(search_limit):
            if data[i] == 0x80 and data[i + 1] == 0x00 and data[i + 4] in (0x02, 0x03, 0x04):
                offset = i
                break

        if offset < 0:
            return adx_path  # 没找到合法 ADX 头，返回原文件让后续正常报错

        # 剥离前缀，保存为临时文件
        import hashlib
        tmpdir = Path(tempfile.gettempdir()) / "p5r_bgm_stripped"
        tmpdir.mkdir(exist_ok=True)
        h = hashlib.md5(str(Path(adx_path).resolve()).encode('utf-8')).hexdigest()[:12]
        temp_adx = tmpdir / f"{h}_off{offset}.adx"
        with open(temp_adx, 'wb') as f:
            f.write(data[offset:])
        return str(temp_adx)

    def decrypt_adx_to_wav(self, encrypted_adx: str, output_wav: str) -> bool:
        """
        将加密的 P5R ADX 解密并转为 WAV（用于试听预览）
        1. 先用纯 Python 解密 Type 9 加密（修改 scale 值）
        2. 再用 vgaudiocli 转 WAV
        :param encrypted_adx: 加密的 ADX 文件
        :param output_wav: 输出 WAV 文件
        :return: 是否成功
        """
        if self.vgaudiocli_path is None:
            raise ADXToolError("vgaudiocli.exe 未找到，请放到 tools 目录或其子目录下")

        # 预处理：剥离非标准前缀（某些曲目前面有零填充，导致 vgaudiocli 无法识别）
        encrypted_adx = self._strip_adx_prefix(encrypted_adx)

        # 第一步: 纯 Python 解密 Type 9 加密
        with open(encrypted_adx, 'rb') as f:
            data = bytearray(f.read())
        
        decrypted = decrypt_adx_type9_inplace(data)
        
        # 保存解密后的临时 ADX（使用唯一文件名，避免同名文件冲突）
        import hashlib
        tmpdir = Path(tempfile.gettempdir()) / "p5r_bgm_decrypt"
        tmpdir.mkdir(exist_ok=True)
        ap = str(Path(encrypted_adx).resolve())
        h = hashlib.md5(ap.encode('utf-8')).hexdigest()[:12]
        temp_adx = tmpdir / f"{h}_{Path(encrypted_adx).stem}_dec.adx"
        with open(temp_adx, 'wb') as f:
            f.write(data)
        
        # 第二步: vgaudiocli 转 WAV（不需要 --keycode，因为已经解密）
        cmd = [str(self.vgaudiocli_path), str(temp_adx), output_wav]
        ret, out, err = self._run_command(cmd)
        if ret != 0 or not os.path.exists(output_wav):
            # 如果解密失败，尝试直接转换（可能是未加密 ADX）
            cmd2 = [str(self.vgaudiocli_path), encrypted_adx, output_wav]
            ret2, out2, err2 = self._run_command(cmd2)
            if ret2 != 0 or not os.path.exists(output_wav):
                raise ADXToolError(f"ADX 转WAV失败: {err or err2 or out}")
        return True

    def wav_to_adx_vgaudio(self, wav_path: str, adx_path: str,
                            loop_start: int = 0, loop_end: int = -1) -> bool:
        """
        使用 vgaudiocli 一步将 WAV 编码为加密 ADX（P5R 专用）。
        替代 adxencd -> vgaudiocli 两步转换，避免：
        1. ADX version 不匹配（adxencd 生成 version 3，P5R 原始是 version 4）
        2. 两步转换中循环点/元数据丢失
        3. 确保加密密钥和版本标志正确

        :param wav_path: 输入 WAV 文件
        :param adx_path: 输出加密 ADX 文件
        :param loop_start: 循环起始样本（默认 0）
        :param loop_end: 循环结束样本（默认 -1 = 文件末尾）
        :return: 是否成功
        """
        if self.vgaudiocli_path is None:
            raise ADXToolError("vgaudiocli.exe 未找到，请放到 tools 目录或其子目录下")

        # 如果 loop_end 为 -1，自动获取 WAV 总样本数
        if loop_end < 0:
            loop_end = self._get_wav_total_samples(wav_path)

        # vgaudiocli 一步编码：WAV -> 加密 ADX
        # -l <start-end>: 设置循环点（零索引样本）
        # --keycode: P5R ADX 加密密钥
        # --version 4: ADX header version 4（匹配 P5R 原始文件）
        cmd = [
            str(self.vgaudiocli_path),
            wav_path, adx_path,
            "-l", f"{loop_start}-{loop_end}",
            "--keycode", P5R_ADX_KEYCODE,
            "--version", "4",
        ]

        ret, out, err = self._run_command(cmd)
        if ret != 0 or not os.path.exists(adx_path):
            raise ADXToolError(f"vgaudiocli 编码失败: {err or out}")

        # 设置偏移19字节为 0x09（P5R 加密标志）
        with open(adx_path, 'rb') as f:
            data = bytearray(f.read())
        if len(data) > ENCRYPT_BYTE_OFFSET:
            data[ENCRYPT_BYTE_OFFSET] = ENCRYPT_BYTE_VALUE
            with open(adx_path, 'wb') as f:
                f.write(data)

        return True

    def process_replacement(self, input_audio: str, target_wave_id: int,
                            output_dir: str, original_adx: str = None,
                            loop_start: int = 0, loop_end: int = -1,
                            volume_gain: float = 1.0,
                            match_length: bool = True,
                            match_level: bool = True,
                            match_spectrum: bool = True,
                            match_bandwidth: bool = True,
                            match_noisefloor: bool = True,
                            match_stereo: bool = True,
                            match_envelope: bool = True,
                            match_lufs: bool = True,
                            match_dynamics: bool = True) -> str:
        """
        完整的替换流程：任意音频 -> WAV -> 等长/响度校正 -> 未加密ADX -> 手动加密 -> 验证 -> 输出

        P5R 流式替换必须满足的可靠性保证（否则游戏内无声/越界/爆音）：
        1. 等长匹配：新 ADX 总样本数 = 原版 ADX（不足静音补齐、超出截断淡出），
           文件大小精确等于原版 -> 避免 ACB 中 wave 偏移越界（E09012006B）
        2. 响度匹配：新音频 RMS/峰值 归一化到原版水平 + tanh 软限幅，
           避免"游戏内更大更炸"（VGAudio 加密路径会改变电平，故用未加密编码后手动加密）
        3. 手动加密：未加密 GcAdpcm 编码（保留电平、样本数精确）-> --keycode 手动加密
           （不重新编码，样本数/文件大小不变，rev=9 匹配 P5R 加密格式）
        4. 输出前验证：文件大小/样本数/格式与目标一致且可解码，不通过则拒绝替换

        :param match_length: 是否强制等长（默认 True；BGM 循环曲目可关）
        :param match_level: 是否响度匹配原版（默认 True，防爆音）
        :param match_spectrum: 是否频谱对齐原版（默认 True；把频段能量分布整形到原版轮廓，
            消除"低频轰头/炸"。BGM 或想保留自身音色时可关）
        """
        output_dir = Path(output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)

        target_filename = f"{target_wave_id}.adx"
        output_adx = output_dir / target_filename

        # 读取原版 ADX 信息（采样率/声道/总样本数/文件大小）
        orig_info = get_adx_info(original_adx) if original_adx and os.path.exists(original_adx) else None
        sample_rate = (orig_info or {}).get("sample_rate") or 44100
        channels = (orig_info or {}).get("channels") or 2
        orig_samples = int((orig_info or {}).get("total_samples") or 0)
        orig_size = int((orig_info or {}).get("filesize") or 0)
        if sample_rate <= 0:
            sample_rate = 44100
        if channels <= 0:
            channels = 2

        with tempfile.TemporaryDirectory() as tmpdir:
            tmpdir = Path(tmpdir)
            temp_wav = tmpdir / "input.wav"
            proc_wav = tmpdir / "proc.wav"
            len_wav = tmpdir / "len.wav"
            temp_adx = tmpdir / "output.adx"
            enc_adx = tmpdir / "enc.adx"

            # 1. 转 WAV（匹配原采样率/声道 + 音量增益）
            self.any_audio_to_wav(str(input_audio), str(temp_wav),
                                  sample_rate=sample_rate, channels=channels,
                                  volume_gain=volume_gain)

            # 1.5 对齐链（带宽→底噪→频谱→立体声→包络→感知响度；每步失败不阻断）
            chain = [
                ("match_bandwidth", "_wav_match_bandwidth"),
                ("match_noisefloor", "_wav_match_noisefloor"),
                ("match_spectrum", "_wav_match_spectrum"),
                ("match_stereo", "_wav_match_stereo_width"),
                ("match_envelope", "_wav_match_envelope"),
                ("match_lufs", "_wav_match_lufs"),
            ]
            if orig_info and original_adx and os.path.exists(str(original_adx))                and os.path.getsize(str(original_adx)) > 0:
                for _flag, _method in chain:
                    if not locals().get(_flag):
                        continue
                    try:
                        _outp = tmpdir / ("chain_%s.wav" % _method)
                        getattr(self, _method)(str(temp_wav), str(original_adx), str(_outp))
                        if _outp.exists() and os.path.getsize(str(_outp)) > 1000:
                            temp_wav = _outp
                    except Exception:
                        pass  # 任一对齐失败不阻断，继续后续处理

            # 2. 响度匹配原版（防"更大更炸"）
            if match_level and orig_info and os.path.exists(str(original_adx)):
                try:
                    self._wav_normalize_to_original(str(temp_wav), str(original_adx), str(proc_wav))
                    temp_wav = proc_wav
                except Exception:
                    pass  # 响度匹配失败不阻断流程，保持原电平

            # 2.5 动态/限幅对齐（响度匹配后兜底：压瞬态过冲，防炸耳）
            if match_dynamics and orig_info and original_adx and os.path.exists(str(original_adx))                and os.path.getsize(str(original_adx)) > 0:
                try:
                    dyn_wav = tmpdir / "dyn.wav"
                    self._wav_match_dynamics(str(temp_wav), str(original_adx), str(dyn_wav))
                    if dyn_wav.exists() and os.path.getsize(str(dyn_wav)) > 1000:
                        temp_wav = dyn_wav
                except Exception:
                    pass

            # 3. 等长匹配：样本数精确对齐原版
            if match_length and orig_samples > 0:
                self._wav_fit_length(str(temp_wav), orig_samples, str(len_wav))
                temp_wav = len_wav

            # 4. 未加密 GcAdpcm 编码（保留电平、样本数精确 = WAV 样本数）
            self.wav_to_adx_vgaudio_plain(str(temp_wav), str(temp_adx))

            # 5. 手动加密（不重新编码 -> 样本数/文件大小不变，rev 0->9）
            self._encrypt_adx_manually(str(temp_adx), str(enc_adx))

            # 6. 验证（保证"每个替换音频都没问题"）
            finfo = get_adx_info(str(enc_adx))
            issues = []
            if match_length and orig_samples > 0 and abs(int(finfo["total_samples"]) - orig_samples) > 2:
                issues.append(f"时长不匹配: 生成 {finfo['total_samples']} vs 原版 {orig_samples} 样本")
            if match_length and orig_size > 0 and abs(os.path.getsize(str(enc_adx)) - orig_size) > 4:
                issues.append(f"文件大小不匹配: 生成 {os.path.getsize(str(enc_adx))} vs 原版 {orig_size} 字节")
            if finfo["sample_rate"] != sample_rate or finfo["channels"] != channels:
                issues.append(f"格式不匹配: {finfo['sample_rate']}Hz/{finfo['channels']}ch vs 目标 {sample_rate}Hz/{channels}ch")
            if not os.path.exists(str(enc_adx)) or os.path.getsize(str(enc_adx)) == 0:
                issues.append("生成的 ADX 为空文件")
            # 响度保险检查（小文件解码验证：峰值不应显著超过原版，否则游戏内爆音）
            if match_level and orig_info and original_adx and os.path.exists(str(original_adx)) \
               and os.path.getsize(str(enc_adx)) <= 2_000_000:
                try:
                    n_rms, n_peak = self._decode_adx_stats(str(enc_adx))
                    o_rms, o_peak = self._decode_adx_stats(str(original_adx))
                    if o_peak > 0.001 and n_peak > o_peak * 1.5 + 0.02:
                        issues.append(f"响度过高: 生成峰值 {n_peak:.3f} vs 原版 {o_peak:.3f}（游戏内可能爆音，建议降低音量增益后重试）")
                except Exception:
                    pass
            if issues:
                raise ADXToolError("替换文件校验未通过，已中止:\n" + "\n".join(issues) +
                                   "\n\n提示: 若为 BGM 循环曲目且无需等长，可在替换面板关闭「等长匹配」后重试。")

            # 7. 复制到输出
            shutil.copy2(str(enc_adx), str(output_adx))

        return str(output_adx)

    def export_to_ryo(self, adx_path: str, acb_name: str, cue_name: str,
                      ryo_output_dir: str, volume: float = 0.5,
                      game_exe: str = "P5R") -> str:
        """
        把已生成的加密 ADX 导出为 Ryo Framework 格式（播放层音量可控）。

        目录结构：<ryo_output_dir>/Ryo/<game_exe>/<acb_name>.acb/<cue_name>.cue/<file>.adx
        音量配置：<ryo_output_dir>/Ryo/<game_exe>/<acb_name>.acb/config.yaml (volume: x.x)

        Ryo Framework 在游戏播放时把 volume 乘上去，直接控制最终输出音量，
        不受游戏硬编码通道增益影响——这是社区解决"替换音效音量异常/被放大"的标准做法。
        相比 AWB FEmulator（只能替换波形、无播放层音量控制），Ryo 可以精确设定游戏内响度。

        :param adx_path: 已生成的加密 ADX 文件路径
        :param acb_name: ACB 名称（不含扩展名），如 "TITLE"
        :param cue_name: Cue 名称，如 "title_00"
        :param ryo_output_dir: Ryo mod 根目录（通常是 Reloaded-II mod 文件夹）
        :param volume: 音量倍率 0.0~1.0+，默认 0.5（比原版小一半，防游戏放大）
        :param game_exe: 游戏 EXE 文件夹名，P5R 固定 "P5R"
        :return: cue 文件夹路径
        """
        import shutil
        ryo_root = Path(ryo_output_dir) / "Ryo" / game_exe / f"{acb_name}.acb"
        cue_dir = ryo_root / f"{cue_name}.cue"
        cue_dir.mkdir(parents=True, exist_ok=True)

        # 复制 ADX 到 cue 文件夹（文件名不影响 Ryo 识别，保留原名即可）
        dest = cue_dir / Path(adx_path).name
        shutil.copy2(adx_path, str(dest))

        # 生成 ACB 级 config.yaml（对该 ACB 下所有 cue 生效）
        config_path = ryo_root / "config.yaml"
        volume = max(0.0, float(volume))
        config_path.write_text(f"volume: {volume}\n", encoding='utf-8')

        return str(cue_dir)

    def deploy_ryo_to_reloaded(self, adx_path: str, acb_name: str, cue_name: str,
                               volume: float = 0.5, game_exe: str = "P5R",
                               mod_dir_name: str = "p5r_title_sfx_ryo",
                               mods_root: Optional[str] = None,
                               apps_cfg_root: Optional[str] = None) -> dict:
        """
        一键部署 Ryo Framework mod 并自动启用（替代手动操作 Reloaded-II）。

        做三件事：
        1. 在 <mods_root>/<mod_dir_name> 下生成/更新 ModConfig.json（无 BOM，声明依赖 Ryo.Reloaded）
        2. 调用 export_to_ryo 生成 Ryo 目录结构：
           Ryo/<game_exe>/<acb_name>.acb/<cue_name>.cue/<file>.adx + config.yaml(volume)
        3. 自动修改 <apps_cfg_root>/*/AppConfig.json 的 EnabledMods：
           - 启用本 mod 的 ModId 与 "Ryo.Reloaded"（Ryo Framework 本体）
           - 禁用冲突的旧 FEmulator 标题替换 mod（p5r_test_title_sfx_replace），避免抢 TITLE
        这样用户只需：工具一键替换 -> 重启游戏即可，无需手动勾选 mod。

        :param adx_path: 已生成的加密 ADX
        :param acb_name: ACB 名（大写，如 TITLE）
        :param cue_name: Cue 名（如 title_00）
        :param volume: 播放层音量 0.0~1.0+，默认 0.5
        :param game_exe: 游戏 EXE 文件夹名，P5R 固定 "P5R"
        :param mod_dir_name: Ryo mod 文件夹名（默认 p5r_title_sfx_ryo）
        :param mods_root: Reloaded-II Mods 根目录（默认 C:/Users/凯梦/Downloads/Release/Mods）
        :param apps_cfg_root: Reloaded-II Apps 配置根目录（默认 .../Apps，含各游戏 AppConfig.json）
        :return: 部署摘要 dict
        """
        import json
        import glob

        mods_root = mods_root or "C:/Users/凯梦/Downloads/Release/Mods"
        apps_cfg_root = apps_cfg_root or "C:/Users/凯梦/Downloads/Release/Apps"
        mod_id = "p5r.title.sfx.ryo"
        conflict_ids = ["p5r_test_title_sfx_replace"]  # FEmulator 标题替换，与 Ryo 抢 TITLE

        # ---- 1. ModConfig.json ----
        mod_dir = Path(mods_root) / mod_dir_name
        mod_dir.mkdir(parents=True, exist_ok=True)
        cfg_path = mod_dir / "ModConfig.json"
        cfg = {
            "ModId": mod_id,
            "ModName": "P5R Title SFX (Ryo Framework)",
            "ModAuthor": "User",
            "ModVersion": "1.0.0",
            "ModDescription": "标题音效替换（Ryo Framework 播放层控音量，config.yaml 调 volume）",
            "ModDependencies": ["Ryo.Reloaded"],
            "ModAliases": [],
            "ModUrl": "",
            "ReleaseMetadataFileName": "",
        }
        if not cfg_path.exists():
            cfg_path.write_text(json.dumps(cfg, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

        # ---- 2. Ryo 目录结构 ----
        cue_dir = self.export_to_ryo(adx_path, acb_name, cue_name, str(mod_dir),
                                     volume=volume, game_exe=game_exe)

        # ---- 3. 自动启用（AppConfig.json EnabledMods）----
        app_cfg = None
        jj = None
        for p in glob.glob(str(Path(apps_cfg_root) / "*" / "AppConfig.json")):
            try:
                j = json.load(open(p, encoding="utf-8"))
            except Exception:
                continue
            em = j.get("EnabledMods") or []
            appname = (j.get("AppName") or "").lower()
            if mod_id in em or "crifs.v2.hook" in em or "persona" in appname or "p5r" in str(p).lower():
                app_cfg = p
                jj = j
                break
        if app_cfg is None:
            hits = glob.glob(str(Path(apps_cfg_root) / "*" / "AppConfig.json"))
            if hits:
                app_cfg = hits[-1]
                jj = json.load(open(app_cfg, encoding="utf-8"))
        enabled_changes = []
        if app_cfg and jj is not None:
            em = list(jj.get("EnabledMods") or [])
            added = []
            removed = []
            for mid in [mod_id, "Ryo.Reloaded"]:
                if mid not in em:
                    em.append(mid)
                    added.append(mid)
            for mid in list(em):
                if mid in conflict_ids:
                    em.remove(mid)
                    removed.append(mid)
            if added or removed:
                import shutil as _sh
                import time as _t
                _sh.copy2(app_cfg, app_cfg + ".bak_ryo_" + _t.strftime("%Y%m%d_%H%M%S"))
                jj["EnabledMods"] = em
                with open(app_cfg, "w", encoding="utf-8") as f:
                    json.dump(jj, f, ensure_ascii=False, indent=2)
                if added:
                    enabled_changes.append("启用: " + ", ".join(added))
                if removed:
                    enabled_changes.append("禁用: " + ", ".join(removed))

        return {
            "mod_dir": str(mod_dir),
            "cue_dir": cue_dir,
            "volume": volume,
            "app_cfg": app_cfg,
            "enabled_changes": enabled_changes,
            "note": "部署完成。若 Reloaded-II 正在运行请重启一次让其重新加载配置，然后启动游戏即可。",
        }

    def wav_to_adx_vgaudio_plain(self, wav_path: str, adx_path: str) -> bool:
        """
        使用 VGAudio 将 WAV 编码为【未加密】ADX（GcAdpcm filter, version 4）。

        为何用未加密而非 --keycode：
        - 实测未加密编码【完美保留电平】（输入 RMS=0.1414 -> 解码 RMS=0.1414）
        - 实测未加密编码【样本数精确 = WAV 样本数】（加密+循环参数会额外 +95 样本）
        后续再用 _encrypt_adx_manually 手动加密（不重新编码），
        从而同时满足：电平可控 + 样本数/文件大小精确 + rev=9 加密格式。
        """
        if self.vgaudiocli_path is None:
            raise ADXToolError("vgaudiocli.exe 未找到，请放到 tools 目录或其子目录下")
        cmd = [
            str(self.vgaudiocli_path), "-c", "-f", "GcAdpcm",
            "--out-format", "adx", "--version", "4",
            str(wav_path), str(adx_path),
        ]
        ret, out, err = self._run_command(cmd)
        if ret != 0 or not os.path.exists(adx_path):
            raise ADXToolError(f"ADX 编码失败(未加密): {err or out}")
        return True

    def _encrypt_adx_manually(self, input_adx: str, output_adx: str) -> bool:
        """
        对已编码的 ADX 手动加密（不重新编码音频数据）。
        vgaudiocli plain.adx enc.adx --keycode：仅把 rev 0->9 并写入加密密钥，
        样本数/文件大小/电平均不变 -> 保证等长与响度匹配不受破坏。
        """
        if self.vgaudiocli_path is None:
            raise ADXToolError("vgaudiocli.exe 未找到，请放到 tools 目录或其子目录下")
        cmd = [str(self.vgaudiocli_path), str(input_adx), str(output_adx),
               "--keycode", P5R_ADX_KEYCODE]
        ret, out, err = self._run_command(cmd)
        if ret != 0 or not os.path.exists(output_adx):
            raise ADXToolError(f"ADX 加密失败: {err or out}")
        # 确保偏移19字节为 0x09（P5R 加密标志）
        with open(output_adx, 'rb') as f:
            data = bytearray(f.read())
        if len(data) > ENCRYPT_BYTE_OFFSET:
            data[ENCRYPT_BYTE_OFFSET] = ENCRYPT_BYTE_VALUE
            with open(output_adx, 'wb') as f:
                f.write(data)
        return True

    def _read_wav_float(self, wav_path: str):
        """读取 WAV 为 float 数组（-1..1），返回 (data, sample_rate, channels)。
        data 形状 (frames, channels)，按帧组织（非 interleaved 一维），
        避免后续按帧 pad/trim/归一化时声道错乱。"""
        import wave as _wave
        import struct as _struct
        import numpy as _np
        with _wave.open(wav_path, 'rb') as wf:
            sr = wf.getframerate()
            ch = wf.getnchannels()
            nframes = wf.getnframes()
            raw = wf.readframes(nframes)
        data = _struct.unpack('<%dh' % (nframes * ch), raw)
        x = _np.array(data, dtype=_np.float64).reshape(nframes, ch) / 32767.0
        return x, sr, ch

    def _write_wav_float(self, wav_path, x, sample_rate, channels):
        import wave as _wave
        import numpy as _np
        if x.ndim == 1:
            x = x.reshape(-1, 1)
        if x.shape[1] == 1 and channels > 1:
            x = _np.repeat(x, channels, axis=1)
        elif x.shape[1] != channels:
            x = _np.repeat(x[:, :1], channels, axis=1)
        pcm = _np.clip(x * 32767, -32767, 32767).astype(_np.int16)
        with _wave.open(wav_path, 'wb') as wf:
            wf.setnchannels(channels)
            wf.setsampwidth(2)
            wf.setframerate(sample_rate)
            wf.writeframes(pcm.tobytes())

    def _wav_match_spectrum(self, wav_path: str, original_adx: str, out_path: str):
        """
        频谱对齐：把替换音频的频段能量分布整形到与原版一致。

        背景：不同音效的频谱差异很大（实测原版标题音效 w0 能量 88% 集中在 0.5~1kHz、
        几乎无低频，而低音素材 <500Hz 占 92%），仅做响度匹配仍会"低频轰头/炸"。
        本方法把替换音频各频段能量压到原版轮廓，从根源上消除爆音。

        实现：STFT 平均功率谱 -> 对数频带(8段)能量比 -> 增益限幅 ±12dB -> 逐帧频谱整形。
        双声道应用同一增益曲线（保持立体声分离）；分析用 mono，保证增益曲线一致。
        失败（无法分析）时保持原样，不阻断流程。
        """
        import numpy as np
        import hashlib
        try:
            from scipy.signal import stft, istft
        except Exception:
            return
        # 1. 解码原版 -> mono 目标频谱
        h = hashlib.md5(str(original_adx).encode('utf-8')).hexdigest()[:12]
        tmp_orig = Path(tempfile.gettempdir()) / ("p5r_orig_%s.wav" % h)
        try:
            self.decrypt_adx_to_wav(original_adx, str(tmp_orig))
            x0, sr0, ch0 = self._read_wav_float(str(tmp_orig))
        finally:
            try:
                tmp_orig.unlink(missing_ok=True)
            except Exception:
                pass
        x_src, sr, ch = self._read_wav_float(wav_path)
        if x0.size == 0 or x_src.size == 0:
            return
        # 2. mono 分析信号（双声道平均）
        m0 = x0.mean(axis=1) if x0.ndim > 1 else x0
        ms = x_src.mean(axis=1) if x_src.ndim > 1 else x_src
        nperseg = 2048  # 固定 2 的幂，保证 STFT/ISTFT 可逆（NOLA 满足）
        noverlap = nperseg // 2
        # 3. 平均功率谱
        f, _, Z0 = stft(m0, fs=sr, nperseg=nperseg, noverlap=noverlap, boundary='zeros', padded=True)
        _, _, Zs = stft(ms, fs=sr, nperseg=nperseg, noverlap=noverlap, boundary='zeros', padded=True)
        P0 = np.mean(np.abs(Z0) ** 2, axis=1) + 1e-12
        Ps = np.mean(np.abs(Zs) ** 2, axis=1) + 1e-12
        # 4. 对数频带增益（人耳感知频率，每倍频程约 3 段）
        #    增益限幅：压制放宽(-24dB，消除"炸"的关键) / 提升收紧(+6dB，避免过度音染)
        nyq = sr / 2.0
        fmin = max(40.0, float(f[1]) if len(f) > 1 else 40.0)
        nbands = 16
        edges = np.logspace(np.log10(fmin), np.log10(nyq), nbands + 1)
        band_gains = []
        for b in range(nbands):
            lo, hi = edges[b], edges[b + 1]
            idx = (f >= lo) & (f < hi)
            if idx.sum() == 0:
                band_gains.append(1.0)
                continue
            e_orig = float(np.mean(P0[idx]))
            e_src = float(np.mean(Ps[idx]))
            g = float(np.sqrt(e_orig / e_src))
            band_gains.append(float(np.clip(g, 0.063, 2.0)))
        # 5. 分段常数增益 -> 轻平滑（核宽 ~7 频点，避免爬升扩散到邻带）
        gcurve = np.zeros_like(f, dtype=np.float64)
        for b in range(nbands):
            lo, hi = edges[b], edges[b + 1]
            idx = (f >= lo) & (f < hi)
            gcurve[idx] = band_gains[b]
        gcurve[f >= edges[-1]] = band_gains[-1]
        k = min(7, max(3, len(gcurve) // 128))
        if k > 3:
            gcurve = np.convolve(gcurve, np.ones(k) / k, mode='same')
        gcurve = np.clip(gcurve, 0.063, 2.0)
        # 5.5 连续高频衰减斜坡：1kHz 以上每倍频程 -3dB（f^(-0.5) 规律），
        #     平滑压低 2-4k/4-8k 尖锐区，不破坏 0.5-1k 主频段（人耳最敏感区整体更柔和）
        hf_tilt = np.ones_like(f)
        hm = f > 1000.0
        hf_tilt[hm] = (1000.0 / np.maximum(f[hm], 1e-6)) ** 0.5
        gcurve = np.clip(gcurve * hf_tilt, 0.063, 2.0)
        # 6. 逐声道应用增益（保持立体声分离）
        out = np.zeros_like(x_src, dtype=np.float64)
        for c in range(x_src.shape[1]):
            sig = x_src[:, c]
            _, _, Z = stft(sig, fs=sr, nperseg=nperseg, noverlap=noverlap, boundary='zeros', padded=True)
            Z2 = Z * gcurve[:, None]
            _, rec = istft(Z2, fs=sr, nperseg=nperseg, noverlap=noverlap, boundary='zeros', input_onesided=True)
            n = min(len(sig), len(rec))
            out[:n, c] = rec[:n]
        self._write_wav_float(out_path, out, sr, ch)

    # ---------- 进阶对齐方法组（每个独立开关、失败不阻断、逐声道安全） ----------

    def _decode_orig_wav(self, original_adx: str, prefix: str = "p5r_orig"):
        """解码原版 ADX 为 float 数组，返回 (x, sr, ch)。x 为 (N, ch) 或 (N,)。"""
        import numpy as np
        import hashlib
        h = hashlib.md5(str(original_adx).encode('utf-8')).hexdigest()[:12]
        tmp = Path(tempfile.gettempdir()) / ("%s_%s.wav" % (prefix, h))
        try:
            self.decrypt_adx_to_wav(original_adx, str(tmp))
            return self._read_wav_float(str(tmp))
        finally:
            try:
                tmp.unlink(missing_ok=True)
            except Exception:
                pass

    def _to_mono(self, x):
        """float 数组 -> mono 一维（多声道取平均）"""
        import numpy as np
        if x.ndim > 1:
            return x.mean(axis=1)
        return x

    def _apply_mono_gain(self, x, gain):
        """把逐样本增益曲线应用到 float 数组（多声道同增益，保持分离）"""
        import numpy as np
        if x.ndim > 1:
            return x * gain[:, None]
        return x * gain

    def _wav_match_bandwidth(self, wav_path: str, original_adx: str, out_path: str):
        """
        带宽对齐：测原版有效频带（-55dB 截止），对素材做同带宽低通/高通。
        防"炸"：素材自带超高频（刺耳）或超低频（隆隆轰头）时，先砍掉溢出的带宽，
        避免后续频谱整形对无意义的带外噪声做放大。
        """
        import numpy as np
        try:
            from scipy.signal import stft, butter, sosfilt
        except Exception:
            return
        x0, sr0, _ = self._decode_orig_wav(original_adx, "p5r_band_orig")
        x_src, sr, ch = self._read_wav_float(wav_path)
        if x0.size == 0 or x_src.size == 0 or sr <= 0:
            return
        # 原版 mono 功率谱
        m0 = self._to_mono(x0)
        nperseg = 2048
        f, _, Z0 = stft(m0, fs=sr, nperseg=nperseg, noverlap=nperseg // 2, boundary='zeros', padded=True)
        P0 = np.mean(np.abs(Z0) ** 2, axis=1) + 1e-15
        peak_db = 10.0 * np.log10(np.max(P0))
        thr = peak_db - 55.0  # -55dB 相对峰值
        above = P0 > (10.0 ** (thr / 10.0))
        valid_idx = np.where(above)[0]
        if valid_idx.size == 0:
            return
        f_lo = float(f[valid_idx[0]])          # 最低有效频点
        f_hi = float(f[valid_idx[-1]])         # 最高有效频点
        nyq = sr / 2.0
        # 素材按原版带宽收窄（只压不扩）：下限 >40Hz 且原版确实无超低频才高通
        # 低通用 2 阶+截止 f_hi*2.0（温和滚降），避免 4 阶激进低通把中高频细节砍没导致糊
        sos_list = []
        if f_lo > 60.0:
            sos_list.append(butter(4, max(30.0, f_lo * 0.7), btype='highpass', fs=sr, output='sos'))
        if f_hi < nyq * 0.95:
            sos_list.append(butter(2, min(nyq * 0.99, f_hi * 2.0), btype='lowpass', fs=sr, output='sos'))
        if not sos_list:
            import shutil
            shutil.copy2(wav_path, out_path)
            return
        out = x_src.astype(np.float64)
        for sos in sos_list:
            if out.ndim > 1:
                for c in range(out.shape[1]):
                    out[:, c] = sosfilt(sos, out[:, c])
            else:
                out = sosfilt(sos, out)
        self._write_wav_float(out_path, out, sr, ch)

    def _wav_match_noisefloor(self, wav_path: str, original_adx: str, out_path: str):
        """
        底噪对齐：素材底噪显著高于原版时，对低电平段做柔和噪声门。
        防"炸/脏"：底噪过大的素材在游戏内显得突兀、不融合。
        仅当素材底噪 > 原版 +6dB 时启用，门限柔和，避免损伤主体。
        """
        import numpy as np
        x0, sr0, _ = self._decode_orig_wav(original_adx, "p5r_noise_orig")
        x_src, sr, ch = self._read_wav_float(wav_path)
        if x0.size == 0 or x_src.size == 0 or sr <= 0:
            return

        def noise_floor(x, sr):
            m = self._to_mono(x)
            win = max(1, int(0.02 * sr)); hop = max(1, win // 2)
            rms_list = []
            for st in range(0, len(m) - win, hop):
                seg = m[st:st + win]
                rms_list.append(float(np.sqrt(np.mean(seg ** 2))))
            if not rms_list:
                return 0.0
            rms_list.sort()
            return float(rms_list[max(0, min(len(rms_list) - 1, len(rms_list) // 20))])  # 5% 分位

        nf_orig = noise_floor(x0, sr)
        nf_src = noise_floor(x_src, sr)
        if nf_orig <= 1e-9 or nf_src <= nf_orig * 2.0:  # 素材底噪不高，或原版近零，不动
            import shutil
            shutil.copy2(wav_path, out_path)
            return
        # 门限：原版底噪 +12dB；门限以下按比例压到底噪水平（软拐点）
        gate_thresh = nf_orig * 4.0
        g_floor = max(1e-3, nf_orig / max(nf_src, 1e-12))
        m = self._to_mono(x_src)
        win = max(1, int(0.01 * sr)); hop = max(1, win // 2)
        n = len(m)
        env = np.zeros(n)
        cnt = np.zeros(n)
        for st in range(0, max(1, n - win), hop):
            seg = m[st:st + win]
            e = float(np.sqrt(np.mean(seg ** 2)))
            env[st:st + win] += e
            cnt[st:st + win] += 1
        cnt[cnt == 0] = 1
        env /= cnt
        # 增益：低于门限按软曲线压到 g_floor，高于门限渐变到 1
        ratio = np.clip(env / gate_thresh, 0.0, 1.0)
        gain = 1.0 - (1.0 - g_floor) * (1.0 - ratio) ** 2
        # 平滑（~20ms）
        k = max(1, int(0.02 * sr))
        kernel = np.ones(k) / k
        gain = np.convolve(gain, kernel, mode='same')
        gain = np.clip(gain, g_floor, 1.0)
        out = self._apply_mono_gain(x_src, gain)
        self._write_wav_float(out_path, out, sr, ch)

    def _wav_match_stereo_width(self, wav_path: str, original_adx: str, out_path: str):
        """
        立体声宽度对齐（mid/side）：把素材的 side/mid 能量比对齐到原版。
        防"出戏"：单声道音效被替换成宽声场会突兀，反之亦然。
        仅双声道有效；原版近单声道时压 side，素材近单声道时无法扩宽则保持。
        """
        import numpy as np
        x0, sr0, _ = self._decode_orig_wav(original_adx, "p5r_stereo_orig")
        x_src, sr, ch = self._read_wav_float(wav_path)
        if x0.size == 0 or x_src.size == 0 or sr <= 0:
            return
        if x_src.ndim < 2 or x_src.shape[1] < 2 or x0.ndim < 2 or x0.shape[1] < 2:
            import shutil
            shutil.copy2(wav_path, out_path)
            return
        L0 = x0[:, 0]; R0 = x0[:, 1]
        Ls = x_src[:, 0]; Rs = x_src[:, 1]
        m0 = (L0 + R0) / 2.0; s0 = (L0 - R0) / 2.0
        ms = (Ls + Rs) / 2.0; ss = (Ls - Rs) / 2.0

        def ratio(side, mid):
            e_m = float(np.mean(mid ** 2)) + 1e-12
            e_s = float(np.mean(side ** 2))
            return e_s / e_m

        r_orig = ratio(s0, m0)
        r_src = ratio(ss, ms)
        if r_src < 1e-6:  # 素材近单声道，无法扩宽 -> 保持
            import shutil
            shutil.copy2(wav_path, out_path)
            return
        g = float(np.sqrt(r_orig / r_src))
        g = float(np.clip(g, 0.0, 2.0))  # 只压不放大超 2x
        out = np.zeros_like(x_src, dtype=np.float64)
        out[:, 0] = ms + ss * g
        out[:, 1] = ms - ss * g
        self._write_wav_float(out_path, out, sr, ch)

    def _wav_match_envelope(self, wav_path: str, original_adx: str, out_path: str):
        """
        包络对齐：用短窗(10ms)RMS 包络把素材的时域包络（attack/衰减形状）整形到原版。
        防"炸耳/糊"：attack 过猛 -> 开头瞬态冲耳；过缓 -> 糊/闷。
        时变增益限幅 [0.7, 1.5] + 5ms 平滑，保守整形，保留素材瞬态不糊。
        """
        import numpy as np
        x0, sr0, _ = self._decode_orig_wav(original_adx, "p5r_env_orig")
        x_src, sr, ch = self._read_wav_float(wav_path)
        if x0.size == 0 or x_src.size == 0 or sr <= 0:
            return
        m0 = self._to_mono(x0)
        ms = self._to_mono(x_src)

        def rms_env(x, sr, win_s=0.01):
            win = max(1, int(win_s * sr)); hop = max(1, win // 2)
            n = len(x)
            env = np.zeros(n); cnt = np.zeros(n)
            for st in range(0, max(1, n - win), hop):
                seg = x[st:st + win]
                e = float(np.sqrt(np.mean(seg ** 2)))
                env[st:st + win] += e
                cnt[st:st + win] += 1
            cnt[cnt == 0] = 1
            return env / cnt

        # 对齐到相同长度（取较短者的公共区间）
        n = min(len(m0), len(ms))
        env0 = rms_env(m0[:n], sr)
        envs = rms_env(ms[:n], sr)
        e0 = env0 + 1e-12
        es = envs + 1e-12
        g = np.sqrt(e0 / es)
        g = np.clip(g, 0.7, 1.5)
        k = max(1, int(0.005 * sr))  # 5ms 平滑，消除突变但保留瞬态
        kernel = np.ones(k) / k
        g = np.convolve(g, kernel, mode='same')
        g = np.clip(g, 0.7, 1.5)
        out = self._apply_mono_gain(x_src[:n], g)
        # 尾部若素材更长则保留（等长匹配会在之后处理）
        if len(x_src) > n:
            tail = x_src[n:] if x_src.ndim > 1 else x_src[n:]
            out = np.concatenate([out, tail], axis=0)
        self._write_wav_float(out_path, out, sr, ch)

    @staticmethod
    def _lufs_mono(x, sr):
        """简化 ITU-R BS.1770 K-weighting 响度（LKFS），用于相对对齐。"""
        import numpy as np
        try:
            from scipy.signal import lfilter
        except Exception:
            return None
        b_hp = [1.53512485958697, -2.69169618940638, 1.19839281085285]
        a_hp = [1.0, -1.69065929318241, 0.73248077421585]
        b_rlb = [1.0, -2.0, 1.0]
        a_rlb = [1.0, -1.99004745483398, 0.99007225036621]
        y = lfilter(b_hp, a_hp, x)
        y = lfilter(b_rlb, a_rlb, y)
        win = max(1, int(0.4 * sr)); hop = max(1, int(0.1 * sr))
        n = len(y)
        energies = []
        for st in range(0, n - win + 1, hop):
            seg = y[st:st + win]
            e = float(np.mean(seg ** 2))
            if e > 0:
                energies.append(e)
        if not energies:
            return -70.0
        energies = np.array(energies)
        # 绝对门限 ~ -70 LKFS
        gated = energies[energies > 1e-7]
        if gated.size == 0:
            return -70.0
        return float(-0.691 + 10.0 * np.log10(np.mean(gated)))

    def _wav_match_lufs(self, wav_path: str, original_adx: str, out_path: str):
        """
        感知响度对齐（LUFS/K-weighting）：把素材的感知响度对齐到原版。
        防"听感不一致"：RMS 是算术平均，人耳对中频更敏感；两个 RMS 相同但频段分布
        不同的音频感知音量不同。LUFS 用等响度加权更接近人耳。
        """
        import numpy as np
        x0, sr0, _ = self._decode_orig_wav(original_adx, "p5r_lufs_orig")
        x_src, sr, ch = self._read_wav_float(wav_path)
        if x0.size == 0 or x_src.size == 0 or sr <= 0:
            return
        m0 = self._to_mono(x0)
        ms = self._to_mono(x_src)
        l0 = self._lufs_mono(m0, sr)
        ls = self._lufs_mono(ms, sr)
        if l0 is None or ls is None:
            return
        gain_db = l0 - ls
        gain = float(10.0 ** (gain_db / 20.0))
        if abs(gain - 1.0) < 1e-3:
            import shutil
            shutil.copy2(wav_path, out_path)
            return
        out = x_src.astype(np.float64) * gain
        self._write_wav_float(out_path, out, sr, ch)

    def _wav_match_dynamics(self, wav_path: str, original_adx: str, out_path: str):
        """
        动态/限幅对齐：crest factor（峰值/RMS）对齐 + 软限幅兜底。
        防"瞬态过冲"：素材 attack 过猛、峰值瞬间冲高时，即使 RMS 对齐也会炸耳。
        只压不放（保护主体），用平滑增益包络实现近似 lookahead 限幅。
        """
        import numpy as np
        x0, sr0, _ = self._decode_orig_wav(original_adx, "p5r_dyn_orig")
        x_src, sr, ch = self._read_wav_float(wav_path)
        if x0.size == 0 or x_src.size == 0 or sr <= 0:
            return
        m0 = self._to_mono(x0)
        ms = self._to_mono(x_src)
        rms0 = float(np.sqrt(np.mean(m0 ** 2))) + 1e-12
        rms_s = float(np.sqrt(np.mean(ms ** 2))) + 1e-12
        peak0 = float(np.max(np.abs(m0))) + 1e-12
        peak_s = float(np.max(np.abs(ms))) + 1e-12
        # 目标峰值 = 原版峰值 +15% 余量：只压真正超出原版的瞬态，
        # 不把素材 RMS 折进 target（否则会全局压损主体、RMS 偏低）
        target_peak = peak0 * 1.15
        if peak_s <= target_peak:  # 未超，无需处理
            import shutil
            shutil.copy2(wav_path, out_path)
            return
        # 平滑峰值包络（attack 3ms / release 30ms 近似：用 max-filter + 平滑）
        k = max(1, int(0.003 * sr))  # 3ms max-pooling 捕捉瞬态
        m = ms
        env = np.zeros(len(m))
        for st in range(0, len(m), k):
            seg = m[st:min(st + k, len(m))]
            env[st:min(st + k, len(m))] = np.max(np.abs(seg))
        # 平滑（release ~30ms，避免连带压损主体）
        kr = max(1, int(0.03 * sr))
        env = np.convolve(env, np.ones(kr) / kr, mode='same')
        env = np.maximum(env, 1e-12)
        gain = np.minimum(1.0, target_peak / env)
        # 平滑增益（attack 2ms 起效，避免削波前 overshoot 过大）
        ka = max(1, int(0.002 * sr))
        gain = np.convolve(gain, np.ones(ka) / ka, mode='same')
        gain = np.clip(gain, 0.0, 1.0)
        out = self._apply_mono_gain(x_src, gain)
        self._write_wav_float(out_path, out, sr, ch)

    def _wav_normalize_to_original(self, wav_path: str, original_adx: str, out_path: str):
        """
        响度匹配：把 WAV 归一化到原版 ADX 的 RMS/峰值水平（+ tanh 软限幅）。
        解决 P5R 游戏内"替换音效更大更炸"（原版电平往往很低，直接替换会爆音）。
        """
        import numpy as np
        import hashlib
        # 1. 解码原版 -> 目标 RMS/峰值
        h = hashlib.md5(str(original_adx).encode('utf-8')).hexdigest()[:12]
        tmp_wav = Path(tempfile.gettempdir()) / f"p5r_orig_{h}.wav"
        try:
            self.decrypt_adx_to_wav(original_adx, str(tmp_wav))
            x0, sr0, ch0 = self._read_wav_float(str(tmp_wav))
            if x0.size == 0:
                raise ValueError("原版解码为空")
            # 用 mono 平均口径算 RMS（更贴近人耳感知，避免双声道高立体声比导致目标偏高）。
            # 保守安全档：原版电平*0.6（比原版低 40%）。游戏内对音效有自动放大，
            # 数据层面留足余量，放大后也不会"炸"。
            _m0 = x0.mean(axis=1) if x0.ndim > 1 else x0
            target_rms = float(np.sqrt(np.mean(_m0 ** 2)) * 0.6)
            target_peak = float(np.max(np.abs(x0)))
            target_peak = max(target_peak, target_rms * 3.0)
        finally:
            try:
                tmp_wav.unlink(missing_ok=True)
            except Exception:
                pass

        if target_rms < 1e-6:
            return  # 原版静音，不做响度匹配

        x, sr, ch = self._read_wav_float(wav_path)
        if x.size == 0:
            return
        x = x.astype(np.float64)
        _mx = x.mean(axis=1) if x.ndim > 1 else x
        rms = float(np.sqrt(np.mean(_mx ** 2)))
        peak = float(np.max(np.abs(x)))
        if rms < 1e-9 or peak < 1e-9:
            return
        # 时域密度感知补偿：持续响素材（占空比高）感知响度远高于同 RMS 的间歇素材。
        # 例：v8 放屁声 P50≈0.225×RMS（大部分安静偶尔响），随机爆破声 P50≈0.8×RMS（全程在响），
        # 同样的 RMS 下后者主观"大声得多"。
        # 兜底公式：持续响素材（density 高）感知更吵，额外降响度，
        # target_rms = base_target * (0.5 / density)，限幅 [0.5, 1.0]（最多再降一半）。
        _win = max(1, int(sr * 0.1))
        _n = len(_mx) // _win
        if _n >= 8:
            _r = np.array([np.sqrt(np.mean(_mx[i*_win:(i+1)*_win]**2)) for i in range(_n)])
            _density = float(np.percentile(_r, 50)) / max(rms, 1e-9)
            _target_density = 0.5
            _dcomp = float(np.clip(_target_density / max(_density, 0.05), 0.5, 1.0))
            target_rms = target_rms * _dcomp
            target_peak = max(target_peak, target_rms * 3.0)
        # 双约束缩放：峰值与 RMS 均不超过原版（原版不炸 -> 替换不炸）
        # 注意：不用 tanh 限幅（会引入峰值/ RMS 失真），改为保形缩放
        target_peak_safe = max(target_peak, target_rms * 4.0, 0.05)
        scale = min(target_peak_safe / peak, target_rms / rms)
        if scale > 1.0:
            # 原音频比原版安静：最多放大到原版水平，限制 2 倍避免噪声放大
            scale = min(scale, 2.0)
        x = x * scale
        # 保险：若仍有瞬时峰值略超（浮点/边界），保形压回原版峰值
        peak_now = float(np.max(np.abs(x)))
        if peak_now > target_peak_safe * 1.001 and peak_now > 1e-9:
            x = x * (target_peak_safe / peak_now)
        self._write_wav_float(out_path, x, sr, ch)

    def _wav_fit_length(self, wav_path: str, target_samples: int, out_path: str):
        """
        等长匹配：把 WAV 精确对齐到目标样本数（按帧）。
        - 不足：末尾补静音（带 50ms 淡出，避免突兀）
        - 超出：末尾截断（带 50ms 淡出）
        保证编码后 ADX 总样本数与文件大小与原版一致（ACB 偏移不越界）。
        """
        import numpy as np
        x, sr, ch = self._read_wav_float(wav_path)
        if x.size == 0:
            raise ADXToolError("替换音频解码为空")
        n = x.shape[0]
        if n == target_samples:
            self._write_wav_float(out_path, x, sr, ch)
            return
        fade = min(int(0.05 * sr), target_samples // 4)
        if n < target_samples:
            pad = np.zeros((target_samples - n, ch), dtype=np.float64)
            out = np.concatenate([x, pad], axis=0)
            if fade > 0:
                ramp = np.linspace(1, 0, fade) ** 1.5
                out[max(0, n - fade):n, :] *= ramp[:, None]
        else:
            out = x[:target_samples].copy()
            if fade > 0:
                ramp = np.linspace(1, 0, fade) ** 1.5
                out[target_samples - fade:target_samples, :] *= ramp[:, None]
        self._write_wav_float(out_path, out, sr, ch)

    def _decode_adx_stats(self, adx_path: str):
        """解码 ADX 并返回 (RMS, 峰值)，用于替换后响度保险检查"""
        import wave as _wave
        import numpy as _np
        import struct as _st
        tmp_wav = Path(tempfile.gettempdir()) / ("p5r_dec_%d.wav" % abs(hash(str(adx_path))))
        try:
            self.decrypt_adx_to_wav(adx_path, str(tmp_wav))
            if not tmp_wav.exists():
                return 0.0, 0.0
            with _wave.open(str(tmp_wav), 'rb') as wf:
                n = wf.getnframes() * wf.getnchannels()
                data = _st.unpack('<%dh' % n, wf.readframes(wf.getnframes()))
            x = _np.array(data, dtype=_np.float64) / 32767.0
            if x.size == 0:
                return 0.0, 0.0
            return float(_np.sqrt(_np.mean(x ** 2))), float(_np.max(_np.abs(x)))
        except Exception:
            return 0.0, 0.0
        finally:
            try:
                tmp_wav.unlink(missing_ok=True)
            except Exception:
                pass


    def preview_adx(self, adx_path: str) -> str:
        """
        将 ADX 转为临时 WAV 文件用于播放
        :param adx_path: ADX 文件路径
        :return: 临时 WAV 文件路径
        """
        import hashlib
        tmpdir = Path(tempfile.gettempdir()) / "p5r_bgm_preview"
        tmpdir.mkdir(exist_ok=True)

        # 生成唯一缓存名：基于绝对路径哈希 + 文件大小 + 修改时间
        # 避免不同来源的同名 ADX（原文件 30.adx 和替换文件 30.adx）缓存冲突
        ap = str(Path(adx_path).resolve())
        try:
            st = os.stat(ap)
            sig = f"{st.st_size}_{int(st.st_mtime)}"
        except Exception:
            sig = "unknown"
        h = hashlib.md5(ap.encode('utf-8')).hexdigest()[:12]
        output_wav = tmpdir / f"{h}_{sig}.wav"

        # 缓存不存在时才重新解码（避免 vgaudiocli 不覆盖已存在文件的问题）
        if not output_wav.exists():
            self.decrypt_adx_to_wav(adx_path, str(output_wav))
        return str(output_wav)


def is_adx_encrypted(filepath: str) -> bool:
    """
    检测 ADX 文件是否已加密（P5R 格式）
    通过检查偏移19字节是否为 0x09
    """
    try:
        with open(filepath, 'rb') as f:
            f.seek(ENCRYPT_BYTE_OFFSET)
            byte = f.read(1)
            return byte == bytes([ENCRYPT_BYTE_VALUE])
    except Exception:
        return False


def get_adx_info(filepath: str) -> dict:
    """
    读取 ADX 文件头信息
    返回: 采样率、声道、时长等
    """
    info = {
        "encrypted": is_adx_encrypted(filepath),
        "sample_rate": 0,
        "channels": 0,
        "duration": 0.0,
        "total_samples": 0,
        "filesize": 0,
    }
    try:
        info["filesize"] = os.path.getsize(filepath)
        with open(filepath, 'rb') as f:
            # ADX 头部解析（标准 CRI ADX type 3 格式）
            # 0-1: magic, 2-3: header_size, 4: encoding, 5: block_size
            # 6: reserved/bit_depth, 7: channels, 8-11: sample_rate, 12-15: total_samples
            magic = f.read(2)
            if magic != b'\x80\x00':
                # 可能是加密或其他格式，跳过解析
                return info
            header_size = struct.unpack('>H', f.read(2))[0]
            encoding = struct.unpack('>B', f.read(1))[0]
            block_size = struct.unpack('>B', f.read(1))[0]
            f.read(1)  # skip reserved byte at offset 6
            channels = struct.unpack('>B', f.read(1))[0]
            sample_rate = struct.unpack('>I', f.read(4))[0]
            total_samples = struct.unpack('>I', f.read(4))[0]

            info["sample_rate"] = sample_rate
            info["channels"] = channels
            info["total_samples"] = total_samples
            if sample_rate > 0:
                info["duration"] = total_samples / sample_rate
    except Exception:
        pass
    return info

# -*- coding: utf-8 -*-
"""
CPK (CRI Packed File) 归档解包模块
支持从 P5R 的 BASE.CPK 中提取 BGM.AWB / BGM.ACB
优先使用 CriFsV2Lib (pythonnet 调用 .NET 库)，回退到纯 Python 解析器
"""

import os
import struct
import zlib
import time
import threading
from io import BytesIO
from pathlib import Path
from typing import List, Dict, Optional, Callable


# 进度回调类型: (percent: int, message: str, phase: str)
ProgressCallback = Callable[[int, str, str], None]


class CPKParseError(Exception):
    """CPK 解析异常"""
    pass


class CPKFileEntry:
    """CPK 内的文件条目"""
    def __init__(self):
        self.name = ""
        self.offset = 0
        self.size = 0
        self.extract_size = 0
        self.is_compressed = False
        self.compression_type = 0


class CPKParser:
    """纯 Python CPK 解析器（支持列出文件和提取未压缩/zlib压缩的文件）"""

    def __init__(self, filepath: str):
        self.filepath = filepath
        self.files: List[CPKFileEntry] = []
        self.data_offset = 0
        self._file_handle = None
        self._cancel = False

    def cancel(self):
        """请求取消当前操作"""
        self._cancel = True

    def parse(self, progress: Optional[ProgressCallback] = None,
              cancel_event: Optional[threading.Event] = None):
        """解析 CPK 文件，构建文件列表"""
        self._cancel = False
        file_size = os.path.getsize(self.filepath)

        with open(self.filepath, 'rb') as f:
            self._file_handle = f
            if progress:
                progress(2, "读取 CPK 头部...", "parse")
            magic = f.read(4)
            if magic != b'CPK ':
                raise CPKParseError(f"无效的 CPK 魔数: {magic}")

            # 尝试多种 TOC 偏移位置
            toc_offset = None
            for try_offset in (0x10, 0x08, 0x18):
                f.seek(try_offset)
                val = struct.unpack('>Q', f.read(8))[0]
                if 0 < val < file_size:
                    f.seek(val)
                    if f.read(4) == b'@UTF':
                        toc_offset = val
                        break

            # 如果偏移方式都失败，搜索 @UTF 魔法
            if toc_offset is None:
                if progress:
                    progress(3, "搜索文件表...", "parse")
                toc_offset = self._search_utf_magic(f, file_size)

            if toc_offset is None:
                raise CPKParseError("无法找到 TOC（@UTF 表），CPK 格式可能不兼容")

            if progress:
                progress(5, "解析文件表 (TOC)...", "parse")

            self._parse_utf_table(f, toc_offset, progress, cancel_event)

    def _search_utf_magic(self, f, file_size: int) -> Optional[int]:
        """在文件中搜索 @UTF 魔法，返回偏移量"""
        chunk_size = 1024 * 1024
        overlap = 4
        f.seek(0)
        pos = 0
        while pos < file_size:
            if self._cancel:
                return None
            read_size = min(chunk_size, file_size - pos)
            data = f.read(read_size)
            idx = data.find(b'@UTF')
            if idx >= 0:
                return pos + idx
            pos += read_size - overlap
            if pos < file_size:
                f.seek(pos)
        return None

    def _parse_utf_table(self, f, table_offset: int,
                          progress: Optional[ProgressCallback] = None,
                          cancel_event: Optional[threading.Event] = None):
        """解析 CRI UTF (Universal Table Format) 表"""
        f.seek(table_offset)

        header = f.read(24)
        if len(header) < 24:
            raise CPKParseError("UTF 表头部不完整")
        if header[0:4] != b'@UTF':
            raise CPKParseError(f"无效的 UTF 魔数: {header[0:4]}")

        table_size = struct.unpack('>I', header[4:8])[0]
        num_rows = struct.unpack('>I', header[8:12])[0]
        num_columns = struct.unpack('>I', header[12:16])[0]
        row_data_offset = struct.unpack('>I', header[16:20])[0]
        string_table_offset = struct.unpack('>I', header[20:24])[0]

        if num_rows > 1000000:
            raise CPKParseError(f"行数过大 ({num_rows})，TOC 解析可能出错")
        if num_columns > 100 or num_columns == 0:
            raise CPKParseError(f"列数异常 ({num_columns})，TOC 解析可能出错")
        if table_size > 500 * 1024 * 1024:
            raise CPKParseError(f"表大小过大 ({table_size})，TOC 解析可能出错")

        col_defs_size = num_columns * 12
        f.seek(table_offset + 24)
        col_defs_data = f.read(col_defs_size)

        columns = []
        for i in range(num_columns):
            off = i * 12
            col_name_off = struct.unpack('>I', col_defs_data[off:off+4])[0]
            col_type = struct.unpack('>I', col_defs_data[off+4:off+8])[0]
            col_flags = struct.unpack('>I', col_defs_data[off+8:off+12])[0]
            columns.append({
                'name_off': col_name_off,
                'type': col_type,
                'flags': col_flags,
                'name': '',
                'size': self._get_value_size(col_type),
            })

        row_stride = 0
        for col in columns:
            row_stride += col['size']
            if row_stride % 4 != 0:
                row_stride += 4 - (row_stride % 4)
        if row_stride == 0:
            row_stride = num_columns * 4

        data_start = table_offset + min(row_data_offset, string_table_offset)
        data_end = table_offset + table_size
        f.seek(0, 2)
        file_size = f.tell()
        data_end = min(data_end, file_size)
        data_length = data_end - data_start

        if data_length > 200 * 1024 * 1024:
            raise CPKParseError(f"文件表数据过大 ({data_length} bytes)，无法内存解析")

        if progress:
            progress(8, f"加载文件表到内存 ({data_length // 1024} KB)...", "parse")

        f.seek(data_start)
        table_data = f.read(data_length)

        str_base_rel = string_table_offset - (data_start - table_offset)
        row_base_rel = row_data_offset - (data_start - table_offset)

        def read_string_mem(off: int) -> str:
            pos = str_base_rel + off
            if pos < 0 or pos >= len(table_data):
                return ''
            end = table_data.find(b'\x00', pos)
            if end == -1:
                end = len(table_data)
            raw = table_data[pos:end]
            try:
                return raw.decode('utf-8')
            except UnicodeDecodeError:
                try:
                    return raw.decode('shift-jis', errors='replace')
                except Exception:
                    return ''

        for col in columns:
            col['name'] = read_string_mem(col['name_off'])

        if progress:
            progress(12, f"解析 {num_rows} 个文件条目...", "parse")

        for row_idx in range(num_rows):
            if cancel_event and cancel_event.is_set():
                return
            if self._cancel:
                return

            entry = CPKFileEntry()
            row_pos = row_base_rel + row_idx * row_stride

            col_off = 0
            for col in columns:
                pos = row_pos + col_off
                if pos + col['size'] > len(table_data):
                    break
                value = self._read_value_mem(table_data, pos, col, read_string_mem)
                col_off += col['size']
                if col_off % 4 != 0:
                    col_off += 4 - (col_off % 4)

                cname = col['name'].lower()
                if cname in ('filename', 'name', 'dir'):
                    if isinstance(value, str) and value:
                        if cname == 'dir':
                            entry.name = value.rstrip('/') + '/' + entry.name
                        else:
                            entry.name = value
                elif cname in ('fileoffset', 'offset', 'offsetl'):
                    entry.offset = int(value) if value else 0
                elif cname in ('filesize', 'size', 'filesizel'):
                    entry.size = int(value) if value else 0
                elif cname in ('extractsize', 'extract', 'extractsizel'):
                    entry.extract_size = int(value) if value else 0
                elif 'compress' in cname:
                    ct = int(value) if value else 0
                    entry.compression_type = ct
                    entry.is_compressed = ct > 0

            if entry.name:
                self.files.append(entry)

            if progress and num_rows > 0 and (row_idx % 500 == 0 or row_idx == num_rows - 1):
                pct = int(12 + (row_idx / num_rows) * 18)
                progress(pct, f"解析文件表... {row_idx + 1}/{num_rows}", "parse")

    def _read_value_mem(self, data: bytes, pos: int, col: dict, read_string_func) -> object:
        ct = col['type']
        try:
            if ct == 0x00:
                return data[pos]
            elif ct == 0x01:
                return struct.unpack_from('>b', data, pos)[0]
            elif ct == 0x02:
                return struct.unpack_from('>H', data, pos)[0]
            elif ct == 0x03:
                return struct.unpack_from('>h', data, pos)[0]
            elif ct == 0x04:
                return struct.unpack_from('>I', data, pos)[0]
            elif ct == 0x05:
                return struct.unpack_from('>i', data, pos)[0]
            elif ct == 0x06:
                return struct.unpack_from('>Q', data, pos)[0]
            elif ct == 0x07:
                return struct.unpack_from('>q', data, pos)[0]
            elif ct == 0x08:
                return struct.unpack_from('>f', data, pos)[0]
            elif ct == 0x09:
                return struct.unpack_from('>d', data, pos)[0]
            elif ct == 0x0A:
                off = struct.unpack_from('>I', data, pos)[0]
                return read_string_func(off)
            elif ct == 0x0B:
                return None
            else:
                return struct.unpack_from('>I', data, pos)[0]
        except Exception:
            return None

    def _get_value_size(self, col_type: int) -> int:
        size_map = {
            0x00: 1, 0x01: 1, 0x02: 2, 0x03: 2,
            0x04: 4, 0x05: 4, 0x06: 8, 0x07: 8,
            0x08: 4, 0x09: 8, 0x0A: 4, 0x0B: 8,
        }
        return size_map.get(col_type, 4)

    def find_file(self, name_pattern: str) -> Optional[CPKFileEntry]:
        pattern = name_pattern.lower().replace('\\', '/')
        for fe in self.files:
            fname = fe.name.lower().replace('\\', '/')
            if pattern in fname:
                return fe
        return None

    def extract_file(self, entry: CPKFileEntry, output_path: str,
                     progress: Optional[ProgressCallback] = None,
                     progress_base: int = 0, progress_range: int = 100,
                     cancel_event: Optional[threading.Event] = None) -> bool:
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)

        total = entry.size
        if total == 0:
            if progress:
                progress(progress_base + progress_range, "提取完成（空文件）", "extract")
            return True

        chunk_size = 256 * 1024
        read_bytes = 0
        last_report = 0

        with open(self.filepath, 'rb') as f:
            f.seek(entry.offset)
            with open(output_path, 'wb') as out:
                while read_bytes < total:
                    if cancel_event and cancel_event.is_set():
                        return False
                    if self._cancel:
                        return False

                    to_read = min(chunk_size, total - read_bytes)
                    chunk = f.read(to_read)
                    if not chunk:
                        break
                    out.write(chunk)
                    read_bytes += len(chunk)

                    current_pct = int(read_bytes / total * 100)
                    if current_pct - last_report >= 2 or read_bytes == total:
                        last_report = current_pct
                        if progress:
                            overall_pct = progress_base + int(current_pct / 100 * progress_range)
                            mb_read = read_bytes / (1024 * 1024)
                            mb_total = total / (1024 * 1024)
                            msg = f"提取 {entry.name.split('/')[-1]}: {mb_read:.1f}/{mb_total:.1f} MB ({current_pct}%)"
                            progress(overall_pct, msg, "extract")

        if entry.is_compressed and entry.extract_size > 0 and entry.extract_size != entry.size:
            if progress:
                progress(progress_base + progress_range, "正在解压...", "extract")
            try:
                with open(output_path, 'rb') as f:
                    data = f.read()
                data = zlib.decompress(data)
                with open(output_path, 'wb') as out:
                    out.write(data)
            except Exception:
                try:
                    with open(output_path, 'rb') as f:
                        data = f.read()
                    data = zlib.decompress(data, -15)
                    with open(output_path, 'wb') as out:
                        out.write(data)
                except Exception:
                    pass

        return True


class CPKExtractor:
    """CPK 解包器（优先 CriFsV2Lib pythonnet，回退纯 Python 解析器）"""

    def __init__(self, tools_dir: str = "tools"):
        self.tools_dir = Path(tools_dir)
        self._cancel = threading.Event()

    def cancel(self):
        self._cancel.set()

    def reset_cancel(self):
        self._cancel.clear()

    def extract_bgm(self, cpk_path: str, output_dir: str,
                    progress: Optional[ProgressCallback] = None,
                    cancel_event: Optional[threading.Event] = None) -> Dict[str, str]:
        """从 CPK 中提取 BGM.AWB 和 BGM.ACB
        优先 CriFsV2Lib (pythonnet)，失败则回退纯 Python 解析器
        """
        self.reset_cancel()
        output_dir = Path(output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)

        if progress:
            progress(1, f"正在准备解包: {Path(cpk_path).name}", "init")

        errors = []

        # === 首选: CriFsV2Lib (pythonnet 调用 .NET 库) ===
        try:
            import crifsv2_extractor
            if crifsv2_extractor.is_available(str(self.tools_dir)):
                if progress:
                    progress(3, "使用 CriFsV2Lib (.NET) 解包...", "extract")
                result = crifsv2_extractor.extract_bgm(
                    str(cpk_path), str(output_dir),
                    tools_dir=str(self.tools_dir),
                    progress=progress, cancel_event=cancel_event
                )
                if result:
                    if progress:
                        progress(100, "解包完成（CriFsV2Lib）", "done")
                    return result
                else:
                    errors.append("[CriFsV2Lib] 未找到 BGM 文件或已取消")
            else:
                err = crifsv2_extractor.get_error()
                errors.append(f"[CriFsV2Lib] 不可用: {err}")
        except Exception as e:
            errors.append(f"[CriFsV2Lib] {e}")

        # === 回退: 纯 Python 解析器 ===
        if progress:
            progress(10, "尝试内置解析器...", "fallback")
        try:
            result = self._extract_with_python(cpk_path, output_dir, progress, cancel_event)
            if result:
                if progress:
                    progress(100, "解包完成（内置解析器）", "done")
                return result
        except Exception as e:
            errors.append(f"[内置解析器] {e}")

        error_summary = "\n".join(errors) if errors else "未知错误"
        raise CPKParseError(
            f"CPK 解包失败。\n\n"
            f"错误详情:\n{error_summary}\n\n"
            f"建议:\n"
            f"1. 安装 pythonnet: py -m pip install pythonnet\n"
            f"2. 确认 tools/CriFsV2Lib/ 目录下有 CriFsV2Lib.dll\n"
            f"3. 或手动用 CriFsV2Lib.GUI 提取 BGM.AWB 和 BGM.ACB"
        )

    def list_awb_files(self, cpk_path: str,
                        progress: Optional[ProgressCallback] = None,
                        cancel_event: Optional[threading.Event] = None) -> List[str]:
        """列出 CPK 中所有 .AWB 文件（用于选择语音/音乐 AWB）
        优先 CriFsV2Lib，回退纯 Python 解析器
        """
        self.reset_cancel()
        # 首选 CriFsV2Lib
        try:
            import crifsv2_extractor
            if crifsv2_extractor.is_available(str(self.tools_dir)):
                if progress:
                    progress(1, "使用 CriFsV2Lib 列出 AWB...", "init")
                result = crifsv2_extractor.list_awb_files(
                    str(cpk_path), tools_dir=str(self.tools_dir),
                    progress=progress, cancel_event=cancel_event
                )
                if result is not None:
                    return result
        except Exception as e:
            if progress:
                progress(10, f"CriFsV2Lib 不可用，回退内置解析器: {e}", "fallback")

        # 回退：纯 Python 解析器
        try:
            parser = CPKParser(str(cpk_path))
            parser.parse(progress=progress, cancel_event=cancel_event)
            awb_names = [e.name for e in parser.files if e.name.upper().endswith(".AWB")]
            if progress:
                progress(100, f"找到 {len(awb_names)} 个 AWB", "done")
            return sorted(awb_names)
        except Exception as e:
            raise CPKParseError(f"列出 AWB 文件失败: {e}")

    def extract_files(self, cpk_path: str, output_dir: str, target_filenames: List[str],
                      progress: Optional[ProgressCallback] = None,
                      cancel_event: Optional[threading.Event] = None) -> Dict[str, str]:
        """从 CPK 中提取指定文件名的文件（泛化版本，支持任意 ACB/AWB）
        优先 CriFsV2Lib，回退纯 Python 解析器
        """
        self.reset_cancel()
        output_dir = Path(output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)

        if progress:
            progress(1, f"准备提取: {', '.join(target_filenames)}", "init")

        # 首选 CriFsV2Lib
        try:
            import crifsv2_extractor
            if crifsv2_extractor.is_available(str(self.tools_dir)):
                if progress:
                    progress(3, "使用 CriFsV2Lib (.NET) 提取...", "extract")
                result = crifsv2_extractor.extract_files(
                    str(cpk_path), str(output_dir), target_filenames,
                    tools_dir=str(self.tools_dir),
                    progress=progress, cancel_event=cancel_event
                )
                if result:
                    if progress:
                        progress(100, "提取完成（CriFsV2Lib）", "done")
                    return result
        except Exception as e:
            if progress:
                progress(10, f"CriFsV2Lib 失败，回退内置解析器: {e}", "fallback")

        # 回退：纯 Python 解析器
        try:
            result = self._extract_files_with_python(cpk_path, output_dir, target_filenames, progress, cancel_event)
            if result:
                if progress:
                    progress(100, "提取完成（内置解析器）", "done")
                return result
            raise CPKParseError(f"未找到目标文件: {', '.join(target_filenames)}")
        except CPKParseError:
            raise
        except Exception as e:
            raise CPKParseError(f"提取失败: {e}")

    def _extract_files_with_python(self, cpk_path, output_dir, target_filenames, progress, cancel_event):
        """使用纯 Python 解析器提取指定文件"""
        parser = CPKParser(str(cpk_path))

        def parse_progress(pct, msg, phase):
            if progress:
                mapped = int(pct / 100 * 30)
                progress(mapped, msg, phase)

        parser.parse(progress=parse_progress, cancel_event=cancel_event)
        if cancel_event and cancel_event.is_set():
            return {}

        if progress:
            progress(30, f"解析完成，CPK 内共 {len(parser.files)} 个文件", "parse")

        targets_upper = {name.upper(): name for name in target_filenames}
        found_entries = []
        for entry in parser.files:
            if entry.name.upper() in targets_upper:
                found_entries.append(entry)

        if not found_entries:
            return {}

        extracted = {}
        total_size = sum(e.size for e in found_entries)
        current_base = 30

        for entry in found_entries:
            if cancel_event and cancel_event.is_set():
                return extracted
            file_range = int((entry.size / total_size) * 70) if total_size > 0 else 70 // len(found_entries)

            def entry_progress(pct, msg, phase):
                if progress:
                    overall = current_base + int(pct / 100 * file_range)
                    progress(min(overall, 99), msg, phase)

            out_path = Path(output_dir) / entry.name
            ok = parser.extract_file(entry, str(out_path), progress=entry_progress, cancel_event=cancel_event)
            if ok and out_path.exists():
                extracted[entry.name] = str(out_path)
            current_base += file_range

        return extracted

    def _extract_with_python(self, cpk_path, output_dir, progress, cancel_event):
        """使用纯 Python 解析器提取"""
        parser = CPKParser(str(cpk_path))

        def parse_progress(pct, msg, phase):
            if progress:
                mapped = int(pct / 100 * 30)
                progress(mapped, msg, phase)

        parser.parse(progress=parse_progress, cancel_event=cancel_event)

        if cancel_event and cancel_event.is_set():
            return {}
        if self._cancel.is_set():
            return {}

        if progress:
            progress(30, f"解析完成，CPK 内共 {len(parser.files)} 个文件", "parse")

        extracted = {}
        # 动态查找所有音频 AWB/ACB 文件
        #  - BGM*.AWB/ACB（背景音乐）
        #  - E*_SE.AWB/ACB（过场音效）
        #  - BP01*.AWB/ACB（战斗语音）
        #  - VOICE_*.AWB/ACB（角色语音）
        found_targets = []
        for entry in parser.files:
            name_upper = entry.name.upper().replace('\\', '/').split('/')[-1]
            if not (name_upper.endswith(".AWB") or name_upper.endswith(".ACB")):
                continue
            # 提取所有 AWB/ACB 文件（BGM/音效/BP战斗语音/VOICE剧情语音/BE_BOSS Boss语音/BE战斗事件语音/E过场语音等）
            if True:
                found_targets.append(entry)

        if not found_targets:
            if progress:
                progress(100, "未找到 BGM 或音效文件", "done")
            return extracted

        total_size = sum(e.size for e in found_targets)
        current_base = 30

        for entry in found_targets:
            if cancel_event and cancel_event.is_set():
                return extracted
            if self._cancel.is_set():
                return extracted

            file_range = int((entry.size / total_size) * 70) if total_size > 0 else 70 // len(found_targets)
            if entry == found_targets[-1]:
                file_range = 100 - current_base

            rel_name = entry.name.replace('\\', '/')
            out_path = Path(output_dir) / rel_name

            success = parser.extract_file(
                entry, str(out_path),
                progress=progress,
                progress_base=current_base,
                progress_range=file_range,
                cancel_event=cancel_event
            )

            if success:
                extracted[entry.name] = str(out_path)
                if progress:
                    progress(current_base + file_range,
                             f"提取完成: {entry.name.split('/')[-1]}",
                             "extract")

            current_base += file_range

        return extracted


def find_base_cpk(folder: str) -> Optional[str]:
    """在文件夹中查找 BASE.CPK"""
    folder = Path(folder)

    direct = folder / "BASE.CPK"
    if direct.exists():
        return str(direct)

    for f in folder.rglob("*.cpk"):
        if f.name.lower() == "base.cpk":
            return str(f)

    return None


def list_cpk_files(folder: str) -> List[str]:
    """列出文件夹中所有 CPK 文件"""
    folder = Path(folder)
    return [str(f) for f in folder.glob("*.CPK")] + \
           [str(f) for f in folder.glob("*.cpk")]

# -*- coding: utf-8 -*-
"""
voice_text_matcher.py
P5R 角色语音 → 中文台词 匹配器

加载由 SC.CPK 反编译得到的中文台词库（p5r_text_database_chs.json）与
语音-文本关联库（voice_text_correlation_chs.json），为工具中的角色语音曲目
提供对应的中文台词。

映射规则：
1. 精确 wave 映射（awb_wave_text）：直接按 wave_id 返回指定台词（最高优先级）
2. Persona 合体（E090_001）：台词 id 为 msg_combine_PERSONAxxx，可直接按编号对应 wave_id
3. 数量匹配（msg 数 == wave 数）：按 wave_id 顺序对应
4. 数量不匹配：返回该 AWB 全部台词供对照
5. 别名映射（voice_awb_alias.json）：语音 AWB 编号与台词 BMD 编号不一致时，
   从完整台词库提取对应 BMD 前缀的台词（如 E651_103_00 → E485 修学旅行剧情）
"""

import json
import re
from pathlib import Path

# Persona 合体台词 id 前缀（E090_001.BMD）
PERSONA_ID_PREFIX = "msg_combine_PERSONA"


class VoiceTextMatcher:
    """角色语音 → 中文台词 匹配器（延迟加载，不拖慢启动）"""

    def __init__(self, base_dir="."):
        self.base_dir = Path(base_dir)
        # 关联库: {awb_stem: [ {id,name,text,source}, ... ]}
        self.awb_to_text = {}
        # 日文原文关联库（voice_text_correlation.json）
        self.awb_to_jp_text = {}
        self.jp_loaded = False
        # 精确 wave 映射: {awb_stem: {wave_id: {id,name,text,source}}}
        self.awb_wave_text = {}
        # wave -> cue 映射: {awb_stem: {wave_id: [cue_id, cue_name]}}
        self.awb_to_wave_cue = {}
        # 别名映射: {awb_stem: {"text_source": "E485", "note": "..."}}
        self.awb_alias = {}
        # wave_id -> 台词索引 偏移量: {awb_stem: {"base_wave": int, "base_idx": int}}
        # 由用户标注自动计算：idx = wave_id - base_wave + base_idx（假设斜率为1，空槽位会越界）
        self.awb_wave_offset = {}
        # 校准映射: {awb_stem: {orig_wave_id: text_index}}
        # 由用户标注校准建立，精确匹配 wave_id -> 文本索引，支持一条文本对应多条语音
        self.calibrated_map = {}
        # 基于 .msg 文件的语音段序列缓存: {bmd_stem: [seg, ...]}
        # seg = {msg_id, speaker, text}，跳过 [sel] 玩家选项（无语音）
        self.msg_segments_cache = {}
        # msg 段是否按顺序对应语音 wave（由 wave 数 == 段数 决定）
        self.msg_aligned_awb = set()
        # f索引精确映射: {awb_stem: {wave_id: seg_index}}
        # 从 msg 的 [f 3 1 8 0 0 X 65535 0] 标签解析，X 直接对应语音 wave_id（如 E104_001）
        self.msg_fidx_map = {}
        self.msg_fidx_cache = {}
        # 完整台词库（延迟加载，仅别名映射需要）
        self._full_text_db = None
        self.loaded = False
        self.load_error = None

    def load(self):
        """加载中文台词关联库"""
        if self.loaded:
            return True
        try:
            corr_path = self.base_dir / "voice_text_correlation_chs.json"
            if not corr_path.exists():
                self.load_error = f"未找到关联库: {corr_path.name}"
                return False
            with open(corr_path, encoding="utf-8") as f:
                corr = json.load(f)
            self.awb_to_text = corr.get("awb_to_text", {}) or {}
            self.awb_wave_text = corr.get("awb_wave_text", {}) or {}
            self.awb_to_wave_cue = corr.get("awb_to_wave_cue", {}) or {}
            # 加载日文原文关联库（可选，不存在则跳过）
            jp_path = self.base_dir / "voice_text_correlation.json"
            if jp_path.exists():
                try:
                    with open(jp_path, encoding="utf-8") as f:
                        jp_corr = json.load(f)
                    self.awb_to_jp_text = jp_corr.get("awb_to_text", {}) or {}
                    self.jp_loaded = True
                except Exception:
                    self.awb_to_jp_text = {}
                    self.jp_loaded = False
            # 加载别名映射
            alias_path = self.base_dir / "voice_awb_alias.json"
            if alias_path.exists():
                try:
                    with open(alias_path, encoding="utf-8") as f:
                        self.awb_alias = json.load(f) or {}
                except Exception:
                    self.awb_alias = {}
            self.loaded = True
            self.load_error = None
            return True
        except Exception as e:
            self.load_error = str(e)
            return False

    def _load_full_text_db(self):
        """延迟加载完整台词库（仅别名映射需要时）"""
        if self._full_text_db is not None:
            return self._full_text_db
        try:
            db_path = self.base_dir / "p5r_text_database_chs.json"
            if not db_path.exists():
                self._full_text_db = []
                return self._full_text_db
            with open(db_path, encoding="utf-8") as f:
                db = json.load(f)
            self._full_text_db = db.get("entries", []) or []
        except Exception:
            self._full_text_db = []
        return self._full_text_db

    def _get_alias_texts(self, awb_stem):
        """通过别名映射从完整台词库提取对应 BMD 前缀的台词"""
        alias = self.awb_alias.get(awb_stem)
        if not alias:
            return None
        source_prefix = alias.get("text_source", "")
        if not source_prefix:
            return None
        entries = self._load_full_text_db()
        if not entries:
            return []
        # 提取 source 以指定前缀开头的台词（如 E485 → E485_030, E485_320 等）
        result = []
        for e in entries:
            src = e.get("source", "")
            if src == source_prefix or src.startswith(source_prefix + "_"):
                result.append({
                    "id": e.get("id", ""),
                    "name": e.get("name", ""),
                    "text": e.get("text", ""),
                    "source": src,
                })
        return result if result else None

    # ---------- 基础查询 ----------

    def get_awb_texts(self, awb_stem):
        """返回该 AWB 关联的全部中文台词（找不到返回 []）。

        优先级：精确匹配 → _SE 后缀兼容 → 别名映射
        """
        if not awb_stem:
            return []
        if not self.loaded:
            self.load()
        stem = str(awb_stem).strip()
        # 1) 精确匹配
        if stem in self.awb_to_text:
            return self.awb_to_text[stem]
        # 2) 去掉 _SE 后缀
        if stem.endswith("_SE"):
            alt = stem[:-3]
            if alt in self.awb_to_text:
                return self.awb_to_text[alt]
        # 3) 加上 _SE 后缀
        alt2 = stem + "_SE"
        if alt2 in self.awb_to_text:
            return self.awb_to_text[alt2]
        # 4) 别名映射（语音 AWB 编号与台词 BMD 编号不一致时）
        alias_texts = self._get_alias_texts(stem)
        if alias_texts is not None:
            return alias_texts
        return []

    def get_awb_jp_texts(self, awb_stem):
        """返回该 AWB 关联的全部日文原文（找不到返回 []）。
        优先级：精确匹配 → _SE 后缀兼容 → 去掉 _A/_B 后缀"""
        if not awb_stem or not self.jp_loaded:
            return []
        stem = str(awb_stem).strip()
        # 1) 精确匹配
        if stem in self.awb_to_jp_text:
            return self.awb_to_jp_text[stem]
        # 2) 去掉 _SE 后缀
        if stem.endswith("_SE"):
            alt = stem[:-3]
            if alt in self.awb_to_jp_text:
                return self.awb_to_jp_text[alt]
        # 3) 加上 _SE 后缀
        alt2 = stem + "_SE"
        if alt2 in self.awb_to_jp_text:
            return self.awb_to_jp_text[alt2]
        # 4) 去掉 _A/_B/_C 等后缀（事件语音常见）
        import re as _re
        m = _re.match(r'^(.+)_[A-Z]$', stem)
        if m:
            alt3 = m.group(1)
            if alt3 in self.awb_to_jp_text:
                return self.awb_to_jp_text[alt3]
            # 再试去掉 _SE
            if alt3.endswith("_SE"):
                alt4 = alt3[:-3]
                if alt4 in self.awb_to_jp_text:
                    return self.awb_to_jp_text[alt4]
        return []

    def has_text(self, awb_stem):
        """该 AWB 是否有中文台词"""
        return bool(self.get_awb_texts(awb_stem))

    # ---------- 智能匹配 ----------

    def match_wave_texts(self, awb_stem, wave_id):
        """
        根据 wave_id 返回匹配的中文台词（可能 0~1 条精确匹配）。

        优先级：
        1. 精确 wave 映射（awb_wave_text）
        2. Persona 合体（E090_001）：msg_combine_PERSONA{wave_id:03d}
        3. 顺序对应（wave_id 作索引），仅当 wave_id 在台词范围内
        """
        if not self.loaded:
            self.load()
        stem = str(awb_stem).strip() if awb_stem else ""

        # 规则 0: 精确 wave 映射（最高优先级）
        if stem in self.awb_wave_text:
            wave_map = self.awb_wave_text[stem]
            try:
                wid = int(wave_id)
                if wid in wave_map:
                    t = wave_map[wid]
                    if isinstance(t, dict):
                        t = dict(t)
                        t["_match_method"] = "exact_wave"
                        return [t]
                    return t
                # 尝试字符串键
                sk = str(wave_id)
                if sk in wave_map:
                    t = wave_map[sk]
                    if isinstance(t, dict):
                        t = dict(t)
                        t["_match_method"] = "exact_wave"
                        return [t]
                    return t
            except (TypeError, ValueError):
                pass

        texts = self.get_awb_texts(awb_stem)
        if not texts:
            return []
        try:
            wid = int(wave_id)
        except (TypeError, ValueError):
            return []

        # 规则 0.25: 校准映射-直接映射（用户手动确认，最高优先级）
        has_msg = (stem in self.msg_fidx_map and wid in self.msg_fidx_map[stem]) or (stem in self.msg_aligned_awb)
        if stem in self.calibrated_map:
            cal_map = self.calibrated_map[stem]
            if wid in cal_map:
                idx = cal_map[wid]
                if 0 <= idx < len(texts):
                    t = dict(texts[idx])
                    t["_match_method"] = "calibrated"
                    t = self._split_text_for_wave(t, stem, wid, idx, cal_map)
                    return [t]

        # 规则 0.3: .msg 自动分割（游戏原始数据，优先于校准映射的插值/外推）
        if has_msg:
            segs = self.get_msg_segments(awb_stem)
            if segs:
                seg_idx = None
                if stem in self.msg_fidx_map and wid in self.msg_fidx_map[stem]:
                    seg_idx = self.msg_fidx_map[stem].get(wid)
                elif stem in self.msg_aligned_awb and 0 <= wid < len(segs):
                    seg_idx = wid
                if seg_idx is not None and 0 <= seg_idx < len(segs):
                    seg = segs[seg_idx]
                    for t in texts:
                        if t.get("id") == seg["msg_id"]:
                            t2 = dict(t)
                            t2["text"] = seg["text"]
                            t2["_match_method"] = "msg_seg"
                            t2["_seg_index"] = seg["seg_index"]
                            return [t2]
                    t2 = {"id": seg["msg_id"], "name": seg["speaker"],
                          "text": seg["text"], "source": awb_stem,
                          "_match_method": "msg_seg", "_seg_index": seg["seg_index"]}
                    return [t2]

        # 规则 0.35: 校准映射-插值/外推（仅当无 .msg 自动分割时使用）
        if not has_msg and stem in self.calibrated_map:
            cal_map = self.calibrated_map[stem]
            cal_waves = sorted(cal_map.keys())
            if cal_waves:
                prev_wave = None
                next_wave = None
                for cw in cal_waves:
                    if cw <= wid:
                        prev_wave = cw
                    if cw >= wid and next_wave is None:
                        next_wave = cw
                        break
                if prev_wave is not None and next_wave is not None and prev_wave != next_wave:
                    prev_idx = cal_map[prev_wave]
                    next_idx = cal_map[next_wave]
                    ratio = (wid - prev_wave) / (next_wave - prev_wave)
                    pred_idx = int(round(prev_idx + ratio * (next_idx - prev_idx)))
                    if 0 <= pred_idx < len(texts):
                        t = dict(texts[pred_idx])
                        t["_match_method"] = "calibrated_interp"
                        return [t]
                elif prev_wave is not None:
                    prev_idx = cal_map[prev_wave]
                    pred_idx = prev_idx + (wid - prev_wave)
                    if 0 <= pred_idx < len(texts):
                        t = dict(texts[pred_idx])
                        t["_match_method"] = "calibrated_offset"
                        t = self._split_text_for_wave(t, stem, wid, pred_idx, cal_map)
                        return [t]
        if not texts:
            return []
        try:
            wid = int(wave_id)
        except (TypeError, ValueError):
            return []

        # 规则 0.5: 偏移量匹配（由用户标注自动计算，idx = wid - base_wave + base_idx）
        if stem in self.awb_wave_offset:
            off = self.awb_wave_offset[stem]
            try:
                base_wave = int(off.get("base_wave", 0))
                base_idx = int(off.get("base_idx", 0))
                pred_idx = wid - base_wave + base_idx
                if 0 <= pred_idx < len(texts):
                    t = dict(texts[pred_idx])
                    t["_match_method"] = "offset"
                    return [t]
            except (TypeError, ValueError):
                pass

        # 规则 1: Persona 合体
        if any(t.get("id", "").startswith(PERSONA_ID_PREFIX) for t in texts):
            target = f"{PERSONA_ID_PREFIX}{wid:03d}"
            for t in texts:
                if t.get("id") == target:
                    t2 = dict(t)
                    t2["_match_method"] = "persona"
                    return [t2]
            return []

        # 规则 1.5: 基于 .msg 文件的自动分割（精确：一条文本对应多条语音时按段拆）
        seg = None
        # 策略A: f 索引精确映射（msg 的 [f ... 0 0 X ...] 中 X 直接=wave_id）
        fidx_map = self.msg_fidx_map.get(stem)
        if fidx_map and wid in fidx_map:
            segs = self.get_msg_segments(awb_stem)
            if segs and 0 <= fidx_map[wid] < len(segs):
                seg = segs[fidx_map[wid]]
        # 策略B: 顺序对齐（wave 数 == msg 段数）
        elif stem in self.msg_aligned_awb:
            segs = self.get_msg_segments(awb_stem)
            if segs and 0 <= wid < len(segs):
                seg = segs[wid]
        if seg is not None:
            # 找到该段对应的文本条目
            for t in texts:
                if t.get("id") == seg["msg_id"]:
                    t2 = dict(t)
                    t2["text"] = seg["text"]
                    t2["_match_method"] = "msg_seg"
                    t2["_seg_index"] = seg["seg_index"]
                    return [t2]
            # 文本库无该 msg（可能是 MND 等），直接返回段文本
            t2 = {"id": seg["msg_id"], "name": seg["speaker"],
                  "text": seg["text"], "source": awb_stem,
                  "_match_method": "msg_seg", "_seg_index": seg["seg_index"]}
            return [t2]

        # 规则 2: 顺序对应（推测匹配，可能不准确，调用方应提示用户确认）
        if 0 <= wid < len(texts):
            t = dict(texts[wid])
            t["_match_method"] = "sequential"
            return [t]
        return []

    def _split_text_for_wave(self, t, stem, wid, idx, cal_map):
        """多条语音映射同一文本时，按换行分割，返回当前wave对应的部分。"""
        try:
            # 找到所有映射到同一文本索引的 wave_id
            same_idx_waves = sorted([w for w, i in cal_map.items() if i == idx])
            if len(same_idx_waves) <= 1:
                return t
            # 当前 wave 在同索引列表中的位置
            if wid not in same_idx_waves:
                # 插值预测的，估算位置
                pos = sum(1 for w in same_idx_waves if w < wid)
            else:
                pos = same_idx_waves.index(wid)
            # 按换行分割文本
            full_text = (t.get("text", "") or "").strip()
            lines = [l.strip() for l in full_text.split("\n") if l.strip()]
            # 如果分割后的行数等于语音数，按位置分配
            if len(lines) == len(same_idx_waves) and 0 <= pos < len(lines):
                t = dict(t)
                t["text"] = lines[pos]
                t["_match_method"] = t.get("_match_method", "calibrated") + "_split"
            # 如果行数多于语音数，也尝试分配
            elif len(lines) > 1 and 0 <= pos < len(lines):
                t = dict(t)
                t["text"] = lines[pos]
                t["_match_method"] = t.get("_match_method", "calibrated") + "_split"
        except Exception:
            pass
        return t

    def get_msg_segments(self, awb_stem):
        """解析该 AWB 对应的 .msg 文件，返回语音段序列（跳过 [sel] 玩家选项）。
        返回 None 表示无 msg 文件或解析失败。
        seg = {msg_id, speaker, text, seg_index}
        """
        import re
        stem = str(awb_stem).upper()
        if stem in self.msg_segments_cache:
            return self.msg_segments_cache[stem]
        # 查找 msg 文件（尝试多种位置）
        candidates = [
            self.base_dir / "extracted_sc_bmd" / f"{awb_stem}.msg",
            self.base_dir / "extracted_text" / f"{awb_stem}.msg",
            self.base_dir / "extracted_sc_bmd" / f"{stem}.msg",
            self.base_dir / "extracted_text" / f"{stem}.msg",
        ]
        msg_path = None
        for c in candidates:
            if c.exists():
                msg_path = c
                break
        if msg_path is None:
            self.msg_segments_cache[stem] = None
            return None
        try:
            with open(msg_path, encoding="utf-8") as f:
                content = f.read()
            segments = []
            f_indices = []
            # 用更健壮的方式切分 msg 块：定位每个 [msg ID ...] 起点和下一个块起点
            # 支持 [msg MSG_xxx_0_0 [说话人]] 和 [msg SYS_xxx_0_0]（无说话人）两种形式
            msg_starts = list(re.finditer(r'\[(msg|mnd|sel)\s+(\S+)(?:\s*\[([^\]]*)\])?\]', content))
            for bi, ms in enumerate(msg_starts):
                btype = ms.group(1)
                msg_id = ms.group(2)
                speaker = (ms.group(3) or "").strip()
                # sel（玩家选项）和 MND（内心独白）无语音，跳过整个块
                if btype == 'sel' or msg_id.upper().startswith('MND_'):
                    continue
                body_start = ms.end()
                body_end = msg_starts[bi + 1].start() if bi + 1 < len(msg_starts) else len(content)
                body = content[body_start:body_end]
                # 去掉 sel 选项块（无语音）：从 [sel 到下一个块/文末
                sel_end = body.find('[sel ')
                if sel_end >= 0:
                    body = body[:sel_end]
                parts = re.split(r'\[e\]', body)
                for part in parts:
                    seg_text = re.sub(r'\[[^\]]*\]', '', part).strip()
                    seg_text = seg_text.replace('[n]', ' ').strip()
                    if seg_text:
                        # 提取该段内的 f 索引（如 [f 3 1 8 0 0 X 65535 0]）
                        fm = re.search(r'\[f\s+\d+\s+\d+\s+8\s+0\s+0\s+(\d+)\s+65535\s+0\]', part)
                        fidx = int(fm.group(1)) if fm else None
                        segments.append({
                            'msg_id': msg_id, 'speaker': speaker,
                            'text': seg_text, 'seg_index': len(segments),
                            'f_idx': fidx
                        })
                        f_indices.append(fidx)
            # 保存 f 索引映射（允许部分段无 f_idx，只要有效 f_idx 占比>=20%且至少2个）
            # 若 f 值有重复，优先用非零且唯一的值作为锚点（0 可能表示"无特定语音"）
            valid_f = [f for f in f_indices if f is not None]
            if f_indices and len(valid_f) >= max(2, int(len(f_indices) * 0.2)):
                # 检查是否有足够的非零唯一值
                nonzero_unique = list(set(f for f in valid_f if f != 0))
                if len(nonzero_unique) >= 2:
                    # 用非零唯一值作为锚点，重复的 0 忽略
                    pass  # f_indices 保持原样，register 时会处理
                elif len(set(valid_f)) == len(valid_f):
                    # 全部唯一（包括0），直接用
                    pass
                else:
                    # 重复且非零唯一值不足2个，无法建立可靠锚点
                    self.msg_fidx_cache[stem] = None
                    if segments:
                        self.msg_segments_cache[stem] = segments
                        return segments
                    self.msg_segments_cache[stem] = None
                    return None
                self.msg_fidx_cache[stem] = f_indices
            else:
                self.msg_fidx_cache[stem] = None

            if segments:
                self.msg_segments_cache[stem] = segments
                return segments
            self.msg_segments_cache[stem] = None
            return None
        except Exception as e:
            print(f"[msg解析] {stem} 失败: {e}")
            self.msg_segments_cache[stem] = None
            return None

    def register_msg_aligned_awb(self, awb_stem, wave_count, wave_ids=None):
        """注册该 AWB 的 .msg 语音段对齐（双策略）：
        策略A（f索引精确映射）：msg 的 [f 3 1 8 0 0 X 65535 0] 中 X 对应 wave_id。
            自动检测偏移量：X 可能直接=wave_id（如 E104_001，wave从1开始），
            也可能 X=wave_id+1（如 E099_010，wave从0开始，f_idx/cue从1开始）。
        策略B（顺序对齐）：语音 wave 数 == msg 语音段数。
        wave_ids: 实际的 wave_id 集合（可选），用于精确检测偏移量；不传则假设 0..wave_count-1。
        返回 True 表示任一对齐方式注册成功。
        """
        stem = str(awb_stem).upper()
        segs = self.get_msg_segments(awb_stem)
        if segs is None or not segs:
            return False
        # 策略A: f 索引精确映射（自动检测偏移量，允许部分段无 f_idx）
        fidx_list = self.msg_fidx_cache.get(stem)
        if fidx_list:
            valid_fidx = [(i, f) for i, f in enumerate(fidx_list) if f is not None]
            # 至少 20% 的段有 f_idx 就用策略A（少量锚点也能做混合对齐）
            if len(valid_fidx) >= max(2, int(len(fidx_list) * 0.2)):
                if wave_ids is not None:
                    actual_wave_ids = set(wave_ids)
                else:
                    actual_wave_ids = set(range(wave_count))
                fidx_vals = [f for _, f in valid_fidx]
                fidx_set = set(fidx_vals)
                # 自动检测偏移量：f_idx 可能直接=wave_id（offset=0），也可能=wave_id+1（offset=1）
                # 判断规则：
                #   - 若 max(f_idx) <= max(wave_ids)，优先 offset=0（f_idx 直接=wave_id）
                #   - 若 max(f_idx) > max(wave_ids)，说明 f_idx 整体偏移，选匹配最多的 offset
                max_f = max(fidx_vals)
                max_wave = max(actual_wave_ids) if actual_wave_ids else 0
                if max_f > max_wave:
                    # f_idx 整体超出 wave 范围，说明有偏移，从 offset=1 开始选匹配最多的
                    best_offset = 1
                    best_match = len({f - 1 for f in fidx_vals} & actual_wave_ids)
                    for offset in (2, 3, -1, -2):
                        mapped = {f - offset for f in fidx_vals}
                        match_count = len(mapped & actual_wave_ids)
                        if match_count > best_match:
                            best_match = match_count
                            best_offset = offset
                else:
                    # f_idx 在 wave 范围内，默认 offset=0（f_idx 直接=wave_id）
                    best_offset = 0
                    best_match = len({f for f in fidx_vals if f in actual_wave_ids})
                # 要求至少 80% 的有效 f_idx 能映射到有效 wave_id
                if best_offset is not None and best_match >= max(1, int(len(fidx_vals) * 0.8)):
                    offset = best_offset
                    # 建立 wave_id -> seg_index 映射（只映射有效的 wave_id）
                    fidx_map = {}
                    for i, f in valid_fidx:
                        wid = f - offset
                        if wid in actual_wave_ids:
                            fidx_map[wid] = i
                    if fidx_map:
                        # 混合对齐：用已知锚点线性推断未覆盖的 wave_id 的 seg_idx
                        try:
                            if wave_ids is not None and len(wave_ids) > 0:
                                actual_waves = sorted(int(w) for w in wave_ids if w is not None)
                                if actual_waves:
                                    # 建立锚点列表 (wave_id, seg_idx)
                                    anchors = sorted(fidx_map.items())
                                    if anchors:
                                        for wid in actual_waves:
                                            if wid in fidx_map:
                                                continue  # 已有精确映射
                                            # 找前后最近的锚点
                                            prev_anchor = None
                                            next_anchor = None
                                            for aw, asg in anchors:
                                                if aw <= wid:
                                                    prev_anchor = (aw, asg)
                                                if aw >= wid and next_anchor is None:
                                                    next_anchor = (aw, asg)
                                            if prev_anchor and next_anchor and prev_anchor != next_anchor:
                                                # 线性插值
                                                ratio = (wid - prev_anchor[0]) / (next_anchor[0] - prev_anchor[0])
                                                seg_idx = int(round(prev_anchor[1] + ratio * (next_anchor[1] - prev_anchor[1])))
                                            elif prev_anchor:
                                                # 只有前锚点，按 wave 差推断
                                                seg_idx = prev_anchor[1] + (wid - prev_anchor[0])
                                            elif next_anchor:
                                                # 只有后锚点，按 wave 差推断
                                                seg_idx = next_anchor[1] - (next_anchor[0] - wid)
                                            else:
                                                continue
                                            # 限制 seg_idx 在有效范围内
                                            if 0 <= seg_idx < len(segs):
                                                fidx_map[wid] = seg_idx
                        except Exception as _hybrid_e:
                            print(f"[msg对齐] {stem} 混合对齐异常: {_hybrid_e}")
                        self.msg_fidx_map[stem] = fidx_map
                        return True
        # 策略B: 顺序对齐（wave 数 == 段数）
        if len(segs) == wave_count:
            self.msg_aligned_awb.add(stem)
            return True
        return False

    def load_calibration(self, path="wave_text_calibration.json"):
        """从文件加载校准映射"""
        try:
            p = self.base_dir / path
            if p.exists():
                with open(p, encoding="utf-8") as f:
                    data = json.load(f)
                if isinstance(data, dict):
                    self.calibrated_map = {}
                    for awb, mapping in data.items():
                        if isinstance(mapping, dict):
                            self.calibrated_map[awb] = {int(k): int(v) for k, v in mapping.items()}
                    print(f"[校准映射] 已加载 {len(self.calibrated_map)} 个AWB的校准映射")
                    return True
        except Exception as e:
            print(f"[校准映射] 加载失败: {e}")
        return False

    def save_calibration(self, path="wave_text_calibration.json"):
        """保存校准映射到文件"""
        try:
            p = self.base_dir / path
            data = {}
            for awb, mapping in self.calibrated_map.items():
                data[awb] = {str(k): v for k, v in mapping.items()}
            with open(p, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            print(f"[校准映射] 已保存 {len(self.calibrated_map)} 个AWB的校准映射到 {p.name}")
            return True
        except Exception as e:
            print(f"[校准映射] 保存失败: {e}")
        return False

    def calibrate_from_notes(self, track_notes, all_tracks):
        """
        从用户标注建立校准映射。
        :param track_notes: {note_key: note_text} 标注字典
        :param all_tracks: [track, ...] 所有曲目列表（含 awb_stem, wave_id, real_index）
        :return: 新增的校准点数量
        """
        from difflib import SequenceMatcher
        added = 0
        # 建立 track 查找表: {(awb_stem, global_wave_id): track}
        track_index = {}
        for t in all_tracks:
            awb = str(t.get("awb_stem", "")).strip().upper()
            wid = t.get("wave_id")
            if awb and wid is not None:
                track_index[(awb, wid)] = t

        for note_key, note_text in track_notes.items():
            note_text = str(note_text).strip()
            if not note_text:
                continue
            # 解析 note_key: "AWB:wave_id" 或纯 "wave_id"
            awb = None
            global_wid = None
            if isinstance(note_key, str) and ":" in note_key:
                parts = note_key.split(":", 1)
                awb = parts[0].strip().upper()
                try:
                    global_wid = int(parts[1])
                except (ValueError, TypeError):
                    continue
            else:
                try:
                    global_wid = int(note_key)
                except (ValueError, TypeError):
                    continue

            # 找到对应的 track
            track = None
            if awb and global_wid is not None:
                track = track_index.get((awb, global_wid))
            if track is None and global_wid is not None:
                # 旧格式：遍历找匹配的 wave_id
                for t in all_tracks:
                    if t.get("wave_id") == global_wid:
                        track = t
                        awb = str(t.get("awb_stem", "")).strip().upper()
                        break
            if track is None or not awb:
                continue

            orig_wave = track.get("real_index", global_wid % 1000)
            if orig_wave is None:
                continue

            # 获取该 AWB 的文本列表
            texts = self.get_awb_texts(awb)
            if not texts:
                continue

            # 在文本列表中找最匹配标注文本的索引
            best_idx = -1
            best_ratio = 0.0
            for idx, t in enumerate(texts):
                t_text = (t.get("text", "") or "").replace("\n", " ").strip()
                t_name = (t.get("name", "") or "").strip()
                # 组合：角色名 + 文本
                full = f"{t_name}：{t_text}" if t_name else t_text
                # 计算相似度
                r1 = SequenceMatcher(None, note_text, full).ratio()
                r2 = SequenceMatcher(None, note_text, t_text).ratio()
                r = max(r1, r2)
                if r > best_ratio:
                    best_ratio = r
                    best_idx = idx

            # 只有相似度 > 0.5 才认为校准成功
            if best_idx >= 0 and best_ratio >= 0.5:
                if awb not in self.calibrated_map:
                    self.calibrated_map[awb] = {}
                self.calibrated_map[awb][int(orig_wave)] = best_idx
                added += 1

        print(f"[校准映射] 从标注建立了 {added} 个校准点")
        return added

    def clear_calibration(self, awb_stem=None):
        """清除校准映射（不传 awb 则清除全部）"""
        if awb_stem is None:
            self.calibrated_map.clear()
        else:
            self.calibrated_map.pop(str(awb_stem).strip().upper(), None)

    def set_wave_offset(self, awb_stem, base_wave, base_idx):
        """设置该 AWB 的 wave_id -> 台词索引 偏移量。
        idx = wave_id - base_wave + base_idx（假设斜率为1）。"""
        if not awb_stem:
            return
        self.awb_wave_offset[str(awb_stem).strip()] = {
            "base_wave": int(base_wave),
            "base_idx": int(base_idx),
        }

    def clear_wave_offset(self, awb_stem=None):
        """清除偏移量（不传 awb 则清除全部）。"""
        if awb_stem is None:
            self.awb_wave_offset.clear()
        else:
            self.awb_wave_offset.pop(str(awb_stem).strip(), None)

    def format_wave_text(self, awb_stem, wave_id, max_len=60):
        """格式化单条匹配台词用于界面显示"""
        matches = self.match_wave_texts(awb_stem, wave_id)
        if not matches:
            return ""
        t = matches[0] if isinstance(matches, list) else matches
        name = t.get("name", "")
        text = t.get("text", "").replace("\n", " ").strip()
        if len(text) > max_len:
            text = text[:max_len] + "…"
        if name:
            return f"{name}：{text}"
        return text

    def format_all_texts(self, awb_stem, max_show=20):
        """
        格式化该 AWB 全部台词（多行），用于详情/编辑窗口。
        max_show 限制显示条数，超出提示。
        """
        texts = self.get_awb_texts(awb_stem)
        if not texts:
            return ""
        lines = []
        shown = texts[:max_show]
        for i, t in enumerate(shown):
            name = t.get("name", "")
            text = t.get("text", "").replace("\n", " ").strip()
            if name:
                lines.append(f"[{i:02d}] {name}：{text}")
            else:
                lines.append(f"[{i:02d}] {text}")
        s = "\n".join(lines)
        if len(texts) > max_show:
            s += f"\n… 共 {len(texts)} 条（列表仅显示前 {max_show} 条）"
        return s

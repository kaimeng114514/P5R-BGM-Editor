# -*- coding: utf-8 -*-
"""
AWB (CRI AFS2) 归档解包模块
用于从 P5R 的 BGM.AWB 中提取 individual ADX 音频文件
也支持从已解包的 ADX 文件夹导入
"""

import os
import struct
import shutil
import json
import subprocess
from pathlib import Path
from typing import List, Dict, Optional, Tuple
from bgm_names import get_wave_id_from_filename, get_bgm_name


def _resolve_track_name(wave_id, awb_stem=None):
    """根据 AWB 类型解析曲目名称。
    只有主 BGM.AWB 才使用主 BGM 曲名表；其他 AWB（语音/音效/事件BGM）
    的内部 wave_id 与主 BGM 曲名表无关，误用会导致曲名显示错误。
    """
    if awb_stem and awb_stem.upper() == "BGM":
        return get_bgm_name(wave_id)
    return f"wave_{wave_id:03d}"


class AWBExtractor:
    """AWB 归档解包器"""

    ACBEDITOR_PATHS = [
        "AcbEditor.exe",
        "CriPakTools_x64/AcbEditor.exe",
        "CriPakTools_x86/AcbEditor.exe",
        "cripaktools/AcbEditor.exe",
    ]

    def __init__(self, tools_dir: str = "tools"):
        self.tools_dir = Path(tools_dir)
        self.acbeditor_path = self._find_acbeditor()

    def _find_acbeditor(self) -> Optional[Path]:
        """在多个可能位置查找 AcbEditor.exe"""
        for rel_path in self.ACBEDITOR_PATHS:
            full = self.tools_dir / rel_path
            if full.exists():
                return full
        return None

    def extract_awb(self, awb_path: str, output_dir: str, awb_stem: str = None) -> List[Dict]:
        """
        从 AWB 文件提取所有 ADX 音频
        :param awb_path: AWB 文件路径
        :param output_dir: 输出目录
        :param awb_stem: AWB 文件名（不含扩展名），用于判断是否为主 BGM.AWB
        :return: 提取的文件信息列表 [{wave_id, name, path, size}]
        """
        awb_path = Path(awb_path)
        output_dir = Path(output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)
        if awb_stem is None:
            awb_stem = awb_path.stem

        # 优先使用内置解析器
        try:
            results = self._extract_awb_internal(awb_path, output_dir, awb_stem)
            if results:
                # 验证提取的文件魔数，过滤掉无效文件，并标记空壳占位符
                valid_results = []
                for r in results:
                    # 内置解析器已在内存中完成验证（_validated=True），无需重新读盘
                    if r.get("_validated"):
                        if r.get("_valid", True):
                            valid_results.append(r)
                        else:
                            Path(r["path"]).unlink(missing_ok=True)
                        continue
                    try:
                        with open(r["path"], 'rb') as f:
                            data = f.read()
                        magic = data[:4]
                        # 有效的 ADX 魔数: 0x8000/0x8001, HCA 魔数: "HCA"
                        if (magic[0] == 0x80 and magic[1] in (0x00, 0x01)) or magic[:3] == b'HCA':
                            # 空壳占位符检测：数据区非零字节极少（通常 < 100），
                            # 这些是游戏预留的 dummy 槽位，没有实际可听音频
                            nonzero = len(data) - data.count(0)
                            r["is_placeholder"] = (nonzero < 100) or (len(data) < 512)
                            r["file_size"] = len(data)
                            valid_results.append(r)
                        else:
                            # 无效文件，删除
                            Path(r["path"]).unlink(missing_ok=True)
                    except Exception:
                        pass
                if valid_results:
                    self.mark_extracted(awb_path, output_dir)
                    # 同步保存扫描缓存，下次 marker 命中时直接复用（秒开）
                    try:
                        self._save_scan_cache(output_dir, valid_results)
                    except Exception:
                        pass
                    return valid_results
        except Exception:
            pass  # 内置解析器不支持此格式，自动回退到暴力搜索

        # 回退1: 暴力搜索 ADX 魔数（适用于格式特殊的语音 AWB）
        try:
            results = self._extract_awb_bruteforce(awb_path, output_dir)
            if results:
                for r in results:
                    try:
                        with open(r["path"], 'rb') as f:
                            data = f.read()
                        nonzero = len(data) - data.count(0)
                        r["is_placeholder"] = (nonzero < 100) or (len(data) < 512)
                        r["file_size"] = len(data)
                    except Exception:
                        r["is_placeholder"] = False
                self.mark_extracted(awb_path, output_dir)
                return results
        except Exception:
            pass  # 暴力搜索也失败，回退到 AcbEditor

        # 回退2: AcbEditor
        if self.acbeditor_path is not None:
            try:
                results = self._extract_awb_acbeditor(awb_path, output_dir)
                if results:
                    for r in results:
                        try:
                            with open(r["path"], 'rb') as f:
                                data = f.read()
                            nonzero = len(data) - data.count(0)
                            r["is_placeholder"] = (nonzero < 100) or (len(data) < 512)
                            r["file_size"] = len(data)
                        except Exception:
                            r["is_placeholder"] = False
                    self.mark_extracted(awb_path, output_dir)
                    return results
            except Exception:
                pass

        # 所有方法都失败：返回空列表（静默跳过，不抛出异常）
        # 对于音效 AWB，解包失败通常意味着没有可提取的音频数据（空占位符或特殊格式）
        # 返回空列表不会打断批量导入流程，调用方会看到 0 个文件
        return []

    def mark_extracted(self, awb_path, output_dir):
        """写入解包完成标记（记录 AWB 大小+mtime，用于下次跳过重复解包）"""
        try:
            st = Path(awb_path).stat()
            marker = Path(output_dir) / "_extracted.info"
            with open(marker, 'w', encoding='utf-8') as f:
                f.write(json.dumps({"size": st.st_size, "mtime": st.st_mtime}))
        except Exception:
            pass

    def is_extracted(self, awb_path, output_dir) -> bool:
        """判断 AWB 是否已解包且源文件未变化（通过 marker 对比大小+mtime）"""
        marker = Path(output_dir) / "_extracted.info"
        if not marker.exists():
            return False
        try:
            info = json.loads(marker.read_text(encoding='utf-8'))
            st = Path(awb_path).stat()
            return info.get("size") == st.st_size and info.get("mtime") == st.st_mtime
        except Exception:
            return False

    def _scan_cache_file(self, output_dir: Path):
        return output_dir / "_scan_cache.json"

    def _load_scan_cache(self, output_dir: Path, trust=False):
        """读取目录 scan 缓存。
        trust=True 时直接信任缓存（调用方已通过 _extracted.info 确认源 AWB 未变化），
        不做逐文件 stat 校验（大幅加速大目录，如 VOICE_SINGLEWORD 上万个文件）。
        trust=False 时校验文件清单与 mtime/size，任一变化则失效返回 None。
        """
        try:
            cache_path = self._scan_cache_file(output_dir)
            if not cache_path.exists():
                return None
            data = json.loads(cache_path.read_text(encoding='utf-8'))
            files = data.get("files", [])
            if trust:
                # 源 AWB 未变化，目录内容不会变，直接信任缓存
                return data.get("tracks")
            # 文件数量不匹配 -> 失效
            current = sorted(p.name for p in output_dir.glob("*.adx"))
            if len(files) != len(current):
                return None
            # 逐文件校验 mtime+size（替换文件会自动失效）
            for fname, fmeta in files.items():
                fp = output_dir / fname
                try:
                    st = fp.stat()
                except Exception:
                    return None
                if fmeta.get("mtime") != int(st.st_mtime) or fmeta.get("size") != st.st_size:
                    return None
            return data.get("tracks")
        except Exception:
            return None

    def _save_scan_cache(self, output_dir: Path, tracks):
        """保存目录 scan 缓存（含文件 mtime+size 快照）"""
        try:
            files = {}
            for t in tracks:
                fp = Path(t["path"])
                if fp.parent == output_dir:
                    try:
                        st = fp.stat()
                        files[fp.name] = {"mtime": int(st.st_mtime), "size": st.st_size}
                    except Exception:
                        pass
            cache_path = self._scan_cache_file(output_dir)
            cache_path.write_text(
                json.dumps({"files": files, "tracks": tracks}, ensure_ascii=False),
                encoding='utf-8'
            )
        except Exception:
            pass

    def scan_extracted_awb(self, output_dir: str, awb_stem: str = None, trust_cache: bool = False) -> List[Dict]:
        """扫描已解包的 ADX 文件夹，生成与 extract_awb 一致的 track 列表（复用已有解包）
        使用线程池并行读取文件头，大幅加速大目录（数千文件）扫描。
        带 mtime 感知缓存：目录文件未变化时直接复用上次结果（替换文件会自动失效）。
        """
        results = []
        output_dir = Path(output_dir)
        if not output_dir.exists():
            return results
        # 尝试命中缓存（仅当目录非空且存在缓存）
        cached = self._load_scan_cache(output_dir, trust=trust_cache)
        if cached:
            return cached
        adx_files = sorted(output_dir.glob("*.adx"))
        if not adx_files:
            return results
        # 并行读取文件头（IO 密集，多线程显著加速；线程数按文件量自适应）
        n_files = len(adx_files)
        if n_files < 64:
            workers = 4
        else:
            workers = min(16, max(8, os.cpu_count() or 8))
        try:
            from concurrent.futures import ThreadPoolExecutor
        except Exception:
            workers = 1

        def _scan_one(adx_file):
            try:
                wave_id = get_wave_id_from_filename(adx_file.name)
                if wave_id < 0:
                    return None
                # 先 stat（文件大小/mtime），复用避免重复系统调用
                try:
                    st = adx_file.stat()
                except Exception:
                    return None
                fsize = st.st_size
                # 占位符快速判断：文件极小（<4KB）时直接认定可能为空槽，仍需读头确认
                with open(adx_file, 'rb') as f:
                    data = f.read(512)
                magic = data[:4]
                valid = (len(magic) >= 2 and magic[0] == 0x80 and magic[1] in (0x00, 0x01)) or magic[:3] == b'HCA'
                if not valid:
                    return None
                nonzero = len(data) - data.count(0)
                return {
                    "wave_id": wave_id,
                    "name": _resolve_track_name(wave_id, awb_stem),
                    "path": str(adx_file),
                    "filename": adx_file.name,
                    "size": fsize,
                    "is_placeholder": (nonzero < 100),
                    "file_size": fsize,
                }
            except Exception:
                return None

        if workers > 1:
            with ThreadPoolExecutor(max_workers=workers) as ex:
                results = [r for r in ex.map(_scan_one, adx_files) if r is not None]
        else:
            results = [r for r in map(_scan_one, adx_files) if r is not None]
        # 保存缓存，下次直接复用（文件未变化时）
        if results:
            self._save_scan_cache(output_dir, results)
        return results

    def _extract_awb_internal(self, awb_path: Path, output_dir: Path, awb_stem: str = None) -> List[Dict]:
        """使用内置 AFS2 解析器提取 AWB（支持 offset_type 0/1/4，流式读取大文件）"""
        file_size = awb_path.stat().st_size

        with open(awb_path, 'rb') as f:
            # 读取头部（最多 64 字节）
            header = f.read(64)
            if len(header) < 12:
                raise ValueError("文件太小，不是有效的 AWB 文件")

            magic = header[0:4]
            if magic != b'AFS2':
                raise ValueError(f"无效的 AWB 魔数: {magic}")

            version = header[4]
            offset_type = header[5]

            # 根据 offset_type 解析头部
            # 标准 AFS2: 0=16bit偏移, 1=32bit偏移, 2=16bit+per-file对齐, 3=32bit+per-file对齐
            if offset_type in (0, 1, 2, 3):
                num_files = struct.unpack_from('<H', header, 6)[0]
                alignment = struct.unpack_from('<I', header, 8)[0]
                pos = 12
            elif offset_type == 4:
                # P5R 扩展格式: num_files uint32 @8, alignment uint32 @12
                num_files = struct.unpack_from('<I', header, 8)[0]
                alignment = struct.unpack_from('<I', header, 12)[0]
                pos = 16  # Wave ID 表从 @16 开始
            else:
                raise ValueError(f"不支持的偏移类型: {offset_type}")

            if num_files == 0:
                # 空 AWB 文件（可能是占位符），直接返回空列表
                return []
            if num_files > 100000:
                raise ValueError(f"文件数异常: {num_files}")

            # 读取 Wave ID 表
            wave_table_size = num_files * 2
            f.seek(pos)
            wave_data = f.read(wave_table_size)
            wave_ids = []
            for i in range(num_files):
                if i * 2 + 2 <= len(wave_data):
                    wid = struct.unpack_from('<H', wave_data, i * 2)[0]
                    wave_ids.append(wid)
                else:
                    wave_ids.append(i)
            pos += wave_table_size

            # offset_type 2/3 有 per-file alignment 表（每个文件 2 字节），提取时可忽略
            if offset_type in (2, 3):
                pos += num_files * 2

            # 读取偏移表
            if offset_type in (0, 2):
                offset_size = 2
            else:  # 1, 3, 4
                offset_size = 4
            offset_table_size = (num_files + 1) * offset_size
            f.seek(pos)
            offset_data = f.read(offset_table_size)
            offsets = []
            for i in range(num_files + 1):
                if offset_size == 2:
                    off = struct.unpack_from('<H', offset_data, i * 2)[0]
                else:
                    off = struct.unpack_from('<I', offset_data, i * 4)[0]
                offsets.append(off)
            pos += offset_table_size

            # 数据起始位置（对齐）
            data_start = pos
            if alignment > 0:
                data_start = ((data_start + alignment - 1) // alignment) * alignment

            # 提取每个文件（流式读取，不全部加载到内存）
            results = []
            for i in range(num_files):
                wave_id = wave_ids[i] if i < len(wave_ids) else i

                if offset_type == 4:
                    # P5R 格式: offset[0]=头部大小, offset[i>=1]=绝对偏移
                    # 第一个文件从 data_start 开始，到 offsets[1] 结束
                    if i == 0:
                        start = data_start
                    else:
                        start = offsets[i]
                    end = offsets[i + 1] if i + 1 < len(offsets) else file_size
                else:
                    # 标准格式: 偏移相对于 data_start
                    start = data_start + offsets[i]
                    end = data_start + offsets[i + 1] if i + 1 < len(offsets) else file_size

                if start >= file_size:
                    continue
                end = min(end, file_size)
                if end <= start:
                    continue

                # 流式读取文件数据
                f.seek(start)
                file_data = f.read(end - start)

                # 剥离 ADX 前缀：某些 AWB（如 BP01 语音）的每个 wave 前有 2-30 字节
                # 零填充前缀，真正的 ADX 从魔数 80 00 开始。不剥离会导致魔数校验失败、
                # vgaudiocli 无法解码（报 "File doesn't have ADX signature"）。
                stripped = self._strip_adx_header_prefix(file_data)
                if stripped is not None:
                    file_data = stripped

                filename = f"{wave_id}.adx"
                filepath = output_dir / filename

                with open(filepath, 'wb') as out:
                    out.write(file_data)

                # 直接基于内存数据判定（避免 extract_awb 验证时重新读盘）
                magic = file_data[:4]
                valid = (len(magic) >= 2 and magic[0] == 0x80 and magic[1] in (0x00, 0x01)) or magic[:3] == b'HCA'
                nonzero = len(file_data) - file_data.count(0)

                results.append({
                    "wave_id": wave_id,
                    "name": _resolve_track_name(wave_id, awb_stem),
                    "path": str(filepath),
                    "filename": filename,
                    "size": len(file_data),
                    "file_size": len(file_data),
                    "is_placeholder": (nonzero < 100) or (len(file_data) < 512),
                    "_validated": True,   # 已基于内存完成验证，extract_awb 无需重新读盘
                    "_valid": valid,
                })

            return results

    @staticmethod
    def _strip_adx_header_prefix(data: bytes):
        """剥离 wave 数据前的零填充前缀，返回标准 ADX 数据。

        某些 AWB（如 P5R 的 BP01 语音）每个 wave 前有 2-30 字节的 0x00 填充，
        真正的 ADX 从魔数 0x80 0x00 开始。此方法在前 64 字节内搜索合法的
        ADX 头（0x80 0x00 + encoding + version），找到后从该位置截取。

        :param data: 原始 wave 数据（可能含前缀）
        :return: 剥离前缀后的 ADX 数据；若已是标准 ADX 或未找到则返回原数据；
                 若数据过短无法判断则返回 None（由调用方决定）
        """
        if len(data) < 6:
            return data
        # 已经是标准 ADX（魔数在偏移 0）
        if data[0] == 0x80 and data[1] == 0x00 and data[4] in (0x02, 0x03, 0x04):
            return data
        # 在前 64 字节内搜索合法 ADX 头
        search_limit = min(64, len(data) - 5)
        for i in range(search_limit):
            if data[i] == 0x80 and data[i + 1] == 0x00 and data[i + 4] in (0x02, 0x03, 0x04):
                if i == 0:
                    return data
                return data[i:]
        return data

    def _extract_awb_bruteforce(self, awb_path: Path, output_dir: Path) -> List[Dict]:
        """暴力搜索 ADX/HCA 魔数提取 AWB（适用于格式特殊的语音/音效 AWB）
        在文件中搜索 0x8000(ADX) 或 "HCA"(HCA) 魔数，验证头部有效性后提取每个文件
        """
        file_size = awb_path.stat().st_size

        # 空文件或极小文件直接返回空（可能是占位符 AWB）
        if file_size < 32:
            return []

        data = awb_path.read_bytes()

        # 搜索有效的 ADX 或 HCA 头部位置
        # 跳过前 64 字节（AFS2 头部区域，避免误匹配头部中的字节序列）
        audio_starts = []
        i = 64
        while i < file_size - 24:
            # ADX 魔数: 0x80 0x00 或 0x80 0x01
            if data[i] == 0x80 and data[i+1] in (0x00, 0x01):
                try:
                    hdr_size = int.from_bytes(data[i+2:i+4], 'big')
                    encoding = data[i+4]
                    channels = data[i+7]
                    sample_rate = int.from_bytes(data[i+8:i+12], 'big')
                    if (16 <= hdr_size <= 96 and 0 <= encoding <= 4 and
                        1 <= channels <= 8 and 4000 <= sample_rate <= 96000):
                        audio_starts.append((i, "adx"))
                        i += max(hdr_size, 24)
                        continue
                except Exception:
                    pass
            # HCA 魔数: "HCA" (0x48 0x43 0x41)
            elif i + 3 < file_size and data[i:i+3] == b'HCA':
                try:
                    # HCA 头部: 魔数(3) + 版本(1) + 头部大小(2, little-endian)
                    hdr_size = int.from_bytes(data[i+4:i+6], 'little')
                    if 8 <= hdr_size <= 512:
                        audio_starts.append((i, "hca"))
                        i += max(hdr_size, 8)
                        continue
                except Exception:
                    pass
            i += 1

        if not audio_starts:
            return []

        # 提取每个音频文件（从当前魔数到下一个魔数，或文件末尾）
        results = []
        for idx, (start, fmt) in enumerate(audio_starts):
            end = audio_starts[idx + 1][0] if idx + 1 < len(audio_starts) else file_size
            file_data = data[start:end]
            if len(file_data) < 8:
                continue

            ext = fmt
            wave_id = idx  # 暴力搜索无法获取 wave_id，用索引代替
            filename = f"{wave_id}.{ext}"
            filepath = output_dir / filename
            with open(filepath, 'wb') as f:
                f.write(file_data)

            results.append({
                "wave_id": wave_id,
                "name": f"音效 {idx:04d} ({ext.upper()})",
                "path": str(filepath),
                "filename": filename,
                "size": len(file_data),
            })

        return results

    def _extract_awb_acbeditor(self, awb_path: Path, output_dir: Path) -> List[Dict]:
        """使用 AcbEditor 提取 AWB（回退方案）"""
        # AcbEditor 通常通过拖拽或命令行工作
        cmd = [str(self.acbeditor_path), str(awb_path), str(output_dir)]
        try:
            result = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
        except Exception as e:
            raise RuntimeError(f"AcbEditor 执行失败: {e}")

        # 扫描输出目录中的 ADX 文件
        return self.scan_adx_folder(str(output_dir))

    def scan_adx_folder(self, folder_path: str, awb_stem: str = None) -> List[Dict]:
        """
        扫描文件夹中的 ADX 文件，生成曲目列表
        :param folder_path: ADX 文件夹路径
        :return: 曲目信息列表
        """
        folder_path = Path(folder_path)
        results = []

        if not folder_path.exists():
            return results

        for adx_file in sorted(folder_path.glob("*.adx")):
            wave_id = get_wave_id_from_filename(adx_file.name)
            if wave_id < 0:
                # 尝试从文件名中提取数字
                import re
                nums = re.findall(r'\d+', adx_file.stem)
                if nums:
                    wave_id = int(nums[0])
                else:
                    wave_id = len(results)

            results.append({
                "wave_id": wave_id,
                "name": _resolve_track_name(wave_id, awb_stem),
                "path": str(adx_file),
                "filename": adx_file.name,
                "size": adx_file.stat().st_size,
            })

        return results

    def build_mod_structure(self, replaced_by_awb,
                             output_dir: str, mod_name: str = "P5R_CustomBGM",
                             mod_description: str = "", non_streaming_files=None) -> str:
        """
        构建 Reloaded-II Mod 目录结构（支持 BGM/音效/语音 多 AWB 归档 + non-streaming ACB Ryo 替换）
        :param replaced_by_awb: {awb_stem: {real_index: adx_file_path}} 流式音频（FEmulator/AWB/）
        :param output_dir: 输出根目录
        :param mod_name: Mod 名称
        :param mod_description: Mod 简介
        :param non_streaming_files: {acb_name: [{cue_id, cue_name, adx_path}, ...]} 非流式音频（Ryo/P5R/）
        :return: Mod 文件夹路径
        """
        import re

        # 兼容旧调用方式：{wave_id: adx_path} → 归为 BGM 归档
        if replaced_by_awb and not isinstance(next(iter(replaced_by_awb.values())), dict):
            replaced_by_awb = {"BGM": replaced_by_awb}

        # 过滤 Windows 文件名非法字符（半角），保留中文和全角符号
        invalid_chars = set('\\/:*?"<>|')
        folder_name = ''.join(c for c in mod_name if c not in invalid_chars).strip()
        if not folder_name:
            folder_name = "P5R_CustomBGM"

        mod_dir = Path(output_dir) / folder_name

        total_files = sum(len(files) for files in replaced_by_awb.values())
        for awb_stem, replaced_files in replaced_by_awb.items():
            # 目标归档目录：FEmulator/AWB/{AWB名}.AWB/（如 BGM.AWB / BP01.AWB / E060_010_SE.AWB）
            awb_dir = mod_dir / "FEmulator" / "AWB" / f"{awb_stem}.AWB"
            awb_dir.mkdir(parents=True, exist_ok=True)

            for real_index, adx_path in replaced_files.items():
                target_name = f"{real_index}.adx"
                target_path = awb_dir / target_name
                shutil.copy2(adx_path, target_path)

        # 非流式音频：Ryo Framework 结构 Ryo/P5R/{ACB名}.ACB/{cue}.adx
        has_ryo = False
        if non_streaming_files:
            ryo_dir = mod_dir / "Ryo" / "P5R"
            ryo_dir.mkdir(parents=True, exist_ok=True)
            for acb_name, files in non_streaming_files.items():
                acb_dir = ryo_dir / f"{acb_name}.ACB"
                acb_dir.mkdir(parents=True, exist_ok=True)
                for finfo in files:
                    cue_id = finfo.get("cue_id")
                    cue_name = finfo.get("cue_name", "")
                    adx_path = finfo.get("adx_path")
                    if not adx_path or not os.path.exists(adx_path):
                        continue
                    if cue_name:
                        safe_name = ''.join(c for c in cue_name if c not in invalid_chars).strip()
                        target_name = f"{safe_name}.adx"
                    elif cue_id is not None:
                        target_name = f"{cue_id}.adx"
                    else:
                        continue
                    shutil.copy2(adx_path, acb_dir / target_name)
                    total_files += 1
                    has_ryo = True

        # 创建 Mod 配置文件（ModConfig.json for Reloaded-II）
        # 声明对 File Emulation Framework 和 AWB Emulator 的依赖，
        # 这样 Reloaded-II 会自动加载这些框架，无需用户手动勾选
        # 生成安全的 ModId：保留字母数字下划线，压缩连续下划线，去首尾下划线
        mod_id = re.sub(r'[^a-zA-Z0-9_]', '_', mod_name).lower()
        mod_id = re.sub(r'_+', '_', mod_id).strip('_')
        if not mod_id:
            # 全符号/全中文时，使用固定前缀 + 时间戳确保唯一且合法
            import time as _time
            mod_id = f"p5r_custombgm_{int(_time.time())}"
        # Mod 名称同样做 JSON 转义（支持引号/反斜杠等符号）
        name_escaped = mod_name.replace('\\', '\\\\').replace('"', '\\"').replace('\n', '\\n').replace('\r', '\\r')
        # Mod 简介（用户自定义或默认）
        desc = mod_description.strip() or f"Custom BGM replacement for Persona 5 Royal ({total_files} tracks)"
        # 转义 JSON 特殊字符，防止简介含引号/换行导致 JSON 损坏
        desc_escaped = desc.replace('\\', '\\\\').replace('"', '\\"').replace('\n', '\\n').replace('\r', '\\r')
        # 构建依赖列表：流式音频需要 FEmulator，非流式需要 Ryo Framework
        deps = [
            "reloaded.sharedlib.hooks",
            "reloaded.universal.fileemulationframework",
            "reloaded.universal.fileemulationframework.awb",
            "crifs.v2.hook",
            "CriFs.V2.Hook.Awb",
        ]
        if has_ryo:
            deps.append("ryo.framework")
        deps_json = ",\n    ".join(f'"{d}"' for d in deps)
        mod_config = f'''{{
  "ModId": "{mod_id}",
  "ModName": "{name_escaped}",
  "ModAuthor": "P5R BGM Editor",
  "ModVersion": "1.0.0",
  "ModDescription": "{desc_escaped}",
  "ModDependencies": [
    {deps_json}
  ],
  "ModDll": "",
  "ModIcon": "",
  "ModR2RManagedDll32": "",
  "ModR2RManagedDll64": "",
  "ModNativeDll32": "",
  "ModNativeDll64": "",
  "IsLibrary": false,
  "ReleaseMetadataFileName": "Sewer56.Update.ReleaseMetadata.json",
  "PluginData": {{}},
  "IsUniversalMod": false,
  "SupportedAppId": ["p5r.exe"],
  "ModCompat": {{
    "P5R": "Persona 5 Royal"
  }}
}}'''
        config_path = mod_dir / "ModConfig.json"
        with open(config_path, 'w', encoding='utf-8') as f:
            f.write(mod_config)

        # 如果包含非流式音频（Ryo Framework），添加依赖说明文件
        if has_ryo:
            self._write_dependency_readme(mod_dir)

        return str(mod_dir)

    def _write_dependency_readme(self, mod_dir):
        lines = [
            "本 Mod 包含非流式音频替换（如 SYSTEM/VOICE_SINGLEWORD/TITLE 等），",
            "需要 Ryo Framework 才能正常工作。",
            "",
            "=== 自动安装（推荐）===",
            "将本 Mod 文件夹放入 Reloaded-II 的 Mods 目录后，",
            "Reloaded-II 会自动检测到缺失的依赖（ryo.framework），",
            "在 Mod 列表中本 Mod 旁会显示警告图标。",
            "右键点击本 Mod -> 选择 Download Missing Dependencies，",
            "即可自动下载并安装 Ryo Framework。",
            "",
            "=== 手动安装 ===",
            "1. 打开 Reloaded-II",
            "2. 点击左侧 Mods -> Download Mods",
            "3. 在搜索框输入 Ryo Framework",
            "4. 找到 Ryo Framework 并点击下载安装",
            "",
            "=== 依赖列表 ===",
            "- reloaded.sharedlib.hooks",
            "- reloaded.universal.fileemulationframework",
            "- reloaded.universal.fileemulationframework.awb",
            "- crifs.v2.hook",
            "- CriFs.V2.Hook.Awb",
            "- ryo.framework（用于非流式音频替换）",
            "",
            "由 P5R BGM Editor 自动生成",
        ]
        readme_path = mod_dir / "依赖说明.txt"
        with open(readme_path, 'w', encoding='utf-8') as f:
            f.write(chr(10).join(lines))


    def build_ryo_mod_structure(self, non_streaming_files,
                                  output_dir: str, mod_name: str = "P5R_CustomAudio",
                                  mod_description: str = "") -> str:
        """
        构建 Ryo Framework Mod 目录结构（用于 non-streaming ACB 替换，如 SYSTEM/VOICE_SINGLEWORD）
        Ryo Framework 用 Cue ID/Cue Name 标识替换目标，文件结构:
          Ryo/P5R/{ACB名}.ACB/{cue_id或cue_name}.adx
        :param non_streaming_files: {acb_name: [{cue_id, cue_name, adx_path}, ...]}
        :param output_dir: 输出根目录
        :param mod_name: Mod 名称
        :param mod_description: Mod 简介
        :return: Mod 文件夹路径
        """
        import re

        invalid_chars = set('\\/:*?"<>|')
        folder_name = ''.join(c for c in mod_name if c not in invalid_chars).strip()
        if not folder_name:
            folder_name = "P5R_CustomAudio"

        mod_dir = Path(output_dir) / folder_name
        ryo_dir = mod_dir / "Ryo" / "P5R"
        ryo_dir.mkdir(parents=True, exist_ok=True)

        total_files = 0
        for acb_name, files in non_streaming_files.items():
            acb_dir = ryo_dir / f"{acb_name}.ACB"
            acb_dir.mkdir(parents=True, exist_ok=True)
            for finfo in files:
                cue_id = finfo.get("cue_id")
                cue_name = finfo.get("cue_name", "")
                adx_path = finfo.get("adx_path")
                if not adx_path or not os.path.exists(adx_path):
                    continue
                # Ryo 支持用 Cue ID 或 Cue Name 命名文件
                # 优先用 Cue Name（可读性好），没有则用 Cue ID
                if cue_name:
                    # 清理文件名中的非法字符
                    safe_name = ''.join(c for c in cue_name if c not in invalid_chars).strip()
                    target_name = f"{safe_name}.adx"
                elif cue_id is not None:
                    target_name = f"{cue_id}.adx"
                else:
                    continue
                target_path = acb_dir / target_name
                shutil.copy2(adx_path, target_path)
                total_files += 1

        # 创建 ModConfig.json（声明对 Ryo Framework 的依赖）
        mod_id = re.sub(r'[^a-zA-Z0-9_]', '_', mod_name).lower()
        mod_id = re.sub(r'_+', '_', mod_id).strip('_')
        if not mod_id:
            import time as _time
            mod_id = f"p5r_customaudio_{int(_time.time())}"
        name_escaped = mod_name.replace('\\', '\\\\').replace('"', '\\"').replace('\n', '\\n').replace('\r', '\\r')
        desc = mod_description.strip() or f"Custom audio replacement for Persona 5 Royal ({total_files} tracks, Ryo Framework)"
        desc_escaped = desc.replace('\\', '\\\\').replace('"', '\\"').replace('\n', '\\n').replace('\r', '\\r')
        mod_config = f'''{{
  "ModId": "{mod_id}",
  "ModName": "{name_escaped}",
  "ModAuthor": "P5R BGM Editor",
  "ModVersion": "1.0.0",
  "ModDescription": "{desc_escaped}",
  "ModDependencies": [
    "reloaded.sharedlib.hooks",
    "ryo.framework"
  ],
  "ModDll": "",
  "ModIcon": "",
  "ModR2RManagedDll32": "",
  "ModR2RManagedDll64": "",
  "ModNativeDll32": "",
  "ModNativeDll64": "",
  "IsLibrary": false,
  "ReleaseMetadataFileName": "Sewer56.Update.ReleaseMetadata.json",
  "PluginData": {{}},
  "IsUniversalMod": false,
  "SupportedAppId": ["p5r.exe"],
  "ModCompat": {{
    "P5R": "Persona 5 Royal"
  }}
}}'''
        config_path = mod_dir / "ModConfig.json"
        with open(config_path, 'w', encoding='utf-8') as f:
            f.write(mod_config)

        return str(mod_dir)


def find_bgm_awb(game_dir: str) -> Optional[str]:
    """
    在游戏目录中查找 BGM.AWB 文件
    :param game_dir: 游戏根目录
    :return: BGM.AWB 路径，未找到返回 None
    """
    game_dir = Path(game_dir)
    # 常见位置
    candidates = [
        game_dir / "P5R" / "data" / "sound" / "bgm" / "BGM.AWB",
        game_dir / "data" / "sound" / "bgm" / "BGM.AWB",
        game_dir / "P5R" / "Content" / "data" / "sound" / "bgm" / "BGM.AWB",
    ]
    for c in candidates:
        if c.exists():
            return str(c)

    # 递归搜索
    for f in game_dir.rglob("BGM.AWB"):
        return str(f)

    return None

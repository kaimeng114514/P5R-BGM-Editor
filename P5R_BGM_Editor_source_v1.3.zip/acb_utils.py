"""
ACB (CRI Atom Cue Sheet Binary) 解析模块
用于从 P5R 的 ACB 文件中提取 Cue 名称（描述性曲名）
基于 dnaroma/acb.py 和 vgmstream 的 ACB 解析实现
"""

import io
import struct
import functools
from pathlib import Path
from typing import Dict, List, Optional, Tuple


# UTF 表列类型常量
COLUMN_STORAGE_MASK = 0xF0
COLUMN_STORAGE_PERROW = 0x50
COLUMN_STORAGE_CONSTANT = 0x30
COLUMN_STORAGE_CONSTANT2 = 0x70
COLUMN_STORAGE_ZERO = 0x10
COLUMN_TYPE_MASK = 0x0F
COLUMN_TYPE_DATA = 0x0B
COLUMN_TYPE_STRING = 0x0A
COLUMN_TYPE_FLOAT = 0x08
COLUMN_TYPE_8BYTE = 0x06
COLUMN_TYPE_4BYTE2 = 0x05
COLUMN_TYPE_4BYTE = 0x04
COLUMN_TYPE_2BYTE2 = 0x03
COLUMN_TYPE_2BYTE = 0x02
COLUMN_TYPE_1BYTE2 = 0x01
COLUMN_TYPE_1BYTE = 0x00


class _BinaryReader:
    """二进制文件读取器（大端序）"""

    def __init__(self, file: io.BytesIO):
        self.f = file

    def _read(self, fmt: str, at: Optional[int] = None):
        if at is not None:
            back = self.f.tell()
            self.f.seek(at)
            d = struct.unpack(fmt, self.f.read(struct.calcsize(fmt)))[0]
            self.f.seek(back)
            return d
        return struct.unpack(fmt, self.f.read(struct.calcsize(fmt)))[0]

    def uint8(self, at=None): return self._read(">B", at)
    def uint16(self, at=None): return self._read(">H", at)
    def uint32(self, at=None): return self._read(">I", at)
    def int32(self, at=None): return self._read(">i", at)
    def float32(self, at=None): return self._read(">f", at)

    def bytes(self, size: int, at: Optional[int] = None) -> bytes:
        if at is not None:
            back = self.f.tell()
            self.f.seek(at)
            d = self.f.read(size)
            self.f.seek(back)
            return d
        return self.f.read(size)

    def string0(self, at: Optional[int] = None) -> str:
        if at is not None:
            back = self.f.tell()
            self.f.seek(at)
            result = self._read_string0()
            self.f.seek(back)
            return result
        return self._read_string0()

    def _read_string0(self) -> str:
        result = []
        while True:
            b = self.f.read(1)
            if not b or b == b'\x00':
                break
            result.append(b[0])
        return bytes(result).decode('utf-8', errors='replace')

    def seek(self, offset: int):
        self.f.seek(offset)


# 列类型 -> 读取函数映射
def _read_data_column(r: _BinaryReader, header):
    offset = r.uint32()
    size = r.uint32()
    return lambda h: r.bytes(size, at=h.data_offset + 8 + offset)


def _read_string_column(r: _BinaryReader, header):
    offset = r.uint32()
    return lambda h: r.string0(at=h.string_table_offset + 8 + offset)


_COLUMN_READERS = {
    COLUMN_TYPE_DATA: _read_data_column,
    COLUMN_TYPE_STRING: _read_string_column,
    COLUMN_TYPE_FLOAT: lambda r, h: r.float32(),
    COLUMN_TYPE_8BYTE: lambda r, h: r.uint32() << 32 | r.uint32(),
    COLUMN_TYPE_4BYTE2: lambda r, h: r.int32(),
    COLUMN_TYPE_4BYTE: lambda r, h: r.uint32(),
    COLUMN_TYPE_2BYTE2: lambda r, h: r.int32() if False else struct.unpack(">h", struct.pack(">H", r.uint16()))[0],
    COLUMN_TYPE_2BYTE: lambda r, h: r.uint16(),
    COLUMN_TYPE_1BYTE2: lambda r, h: struct.unpack(">b", struct.pack(">B", r.uint8()))[0],
    COLUMN_TYPE_1BYTE: lambda r, h: r.uint8(),
}

# 列类型 -> struct 格式
_COLUMN_FORMATS = {
    COLUMN_TYPE_DATA: "8s",
    COLUMN_TYPE_STRING: "4s",
    COLUMN_TYPE_FLOAT: "f",
    COLUMN_TYPE_8BYTE: "Q",
    COLUMN_TYPE_4BYTE2: "i",
    COLUMN_TYPE_4BYTE: "I",
    COLUMN_TYPE_2BYTE2: "h",
    COLUMN_TYPE_2BYTE: "H",
    COLUMN_TYPE_1BYTE2: "b",
    COLUMN_TYPE_1BYTE: "B",
}


class _UTFHeader:
    """UTF 表头"""
    def __init__(self, data: bytes):
        (self.table_size, self.u1, self.row_offset,
         self.string_table_offset, self.data_offset,
         self.table_name_offset, self.number_of_fields,
         self.row_size, self.number_of_rows) = struct.unpack(">IHHIIIHHI", data)


class UTFTable:
    """CRI UTF (Universal Table Format) 表解析器"""

    def __init__(self, data: bytes):
        if len(data) < 8:
            raise ValueError("数据太短，不是有效的 UTF 表")

        r = _BinaryReader(io.BytesIO(data))
        magic = r.uint32()
        if magic != 0x40555446:  # "@UTF"
            raise ValueError(f"无效的 UTF 魔数: 0x{magic:08X}")

        self.header = _UTFHeader(r.bytes(28))
        self.name = r.string0(at=self.header.string_table_offset + 8 + self.header.table_name_offset)

        # 读取 schema
        r.seek(0x20)
        self._read_schema(r)

        # 读取行数据
        r.seek(self.header.row_offset + 8)
        self.rows = self._read_rows(r)

    def _read_schema(self, r: _BinaryReader):
        r.seek(0x20)
        dynamic_keys = []
        fmt = ">"
        constants = {}

        for _ in range(self.header.number_of_fields):
            field_type = r.uint8()
            name_offset = r.uint32()
            occurrence = field_type & COLUMN_STORAGE_MASK
            type_key = field_type & COLUMN_TYPE_MASK

            name = r.string0(at=self.header.string_table_offset + 8 + name_offset)

            if occurrence in (COLUMN_STORAGE_CONSTANT, COLUMN_STORAGE_CONSTANT2):
                val = _COLUMN_READERS[type_key](r, self.header)
                constants[name] = val
            else:
                dynamic_keys.append(name)
                fmt += _COLUMN_FORMATS[type_key]

        # 解析常量中的延迟值（字符串/数据引用）
        for k in list(constants.keys()):
            if callable(constants[k]):
                constants[k] = constants[k](self.header)

        self.dynamic_keys = dynamic_keys
        self.struct_format = fmt
        self.constants = constants

    def _read_rows(self, r: _BinaryReader) -> List[Dict]:
        rows = []
        sfmt = struct.Struct(self.struct_format)

        for _ in range(self.header.number_of_rows):
            raw = r.bytes(sfmt.size)
            values = sfmt.unpack(raw)
            resolved = self._resolve_values(r, values)
            row = {k: v for k, v in zip(self.dynamic_keys, resolved)}
            row.update(self.constants)
            rows.append(row)

        return rows

    def _resolve_values(self, r: _BinaryReader, values: Tuple) -> Tuple:
        result = []
        for val in values:
            if isinstance(val, bytes):
                if len(val) == 8:
                    # 数据引用：offset + size
                    offset, size = struct.unpack(">II", val)
                    result.append(r.bytes(size, at=self.header.data_offset + 8 + offset))
                else:
                    # 字符串引用：offset
                    offset = struct.unpack(">I", val)[0]
                    result.append(r.string0(at=self.header.string_table_offset + 8 + offset))
            else:
                result.append(val)
        return tuple(result)


class ACBParser:
    """ACB 文件解析器，用于提取 Cue 名称和 Wave ID→Cue 映射"""

    def __init__(self, acb_path: str):
        self.acb_path = Path(acb_path)
        self._cue_names: Dict[int, str] = {}
        self._waveform_info: Dict[int, Dict] = {}
        self._wave_to_cue: Dict[int, Tuple[int, str]] = {}  # wave_id -> (cue_id, cue_name)
        self._parsed = False
        self._tables = {}  # 缓存子表

    def parse(self) -> bool:
        """解析 ACB 文件，提取 Cue 名称和 Wave→Cue 映射"""
        try:
            data = self.acb_path.read_bytes()
            return self.parse_bytes(data)
        except Exception:
            return False

    def parse_bytes(self, data: bytes) -> bool:
        """从内存 bytes 解析 ACB（避免对超大 ACB 文件重复读取磁盘，显著加速批量导入）"""
        try:
            if len(data) < 8:
                return False

            # 检查是否是 UTF 格式（ACB 文件通常以 @UTF 开头）
            if data[0:4] != b'@UTF':
                # 有些 ACB 文件可能有其他头部，尝试搜索 @UTF
                utf_pos = data.find(b'@UTF')
                if utf_pos < 0:
                    return False
                data = data[utf_pos:]

            # 解析主 UTF 表
            main_table = UTFTable(data)

            # 提取子表
            row0 = main_table.rows[0] if main_table.rows else {}
            self._tables = row0

            # CueNameTable: CueIndex -> CueName
            if "CueNameTable" in row0 and row0["CueNameTable"]:
                try:
                    cue_name_table = UTFTable(row0["CueNameTable"])
                    for row in cue_name_table.rows:
                        cue_idx = row.get("CueIndex", 0)
                        cue_name = row.get("CueName", "")
                        if cue_name:
                            self._cue_names[cue_idx] = cue_name
                except Exception:
                    pass

            # WaveformTable: 波形信息（编码类型、是否流式等）
            if "WaveformTable" in row0 and row0["WaveformTable"]:
                try:
                    wave_table = UTFTable(row0["WaveformTable"])
                    for idx, row in enumerate(wave_table.rows):
                        self._waveform_info[idx] = {
                            "encode_type": row.get("EncodeType", 0),
                            "is_stream": row.get("IsStreaming", row.get("Streaming", False)),
                            "stream_awb_id": row.get("StreamAwbId", 0),
                            "memory_awb_id": row.get("MemoryAwbId", 65535),
                            "num_samples": row.get("NumSamples", 0),
                            "sampling_rate": row.get("SamplingRate", 0),
                        }
                except Exception:
                    pass

            # 解析 Wave ID -> Cue 映射（遍历引用链）
            self._parse_wave_to_cue()

            self._parsed = True
            return len(self._cue_names) > 0

        except Exception:
            return False

    def _parse_wave_to_cue(self):
        """解析 CueTable 引用链，建立 WaveformIndex -> (CueId, CueName) 映射"""
        row0 = self._tables
        if not row0 or "CueTable" not in row0 or not row0["CueTable"]:
            return

        try:
            cue_table = UTFTable(row0["CueTable"])
        except Exception:
            return

        # 预解析子表
        track_table = synth_table = seq_table = waveform_table = None
        if "TrackTable" in row0 and row0["TrackTable"]:
            try:
                track_table = UTFTable(row0["TrackTable"])
            except Exception:
                pass
        if "SynthTable" in row0 and row0["SynthTable"]:
            try:
                synth_table = UTFTable(row0["SynthTable"])
            except Exception:
                pass
        if "SequenceTable" in row0 and row0["SequenceTable"]:
            try:
                seq_table = UTFTable(row0["SequenceTable"])
            except Exception:
                pass
        if "WaveformTable" in row0 and row0["WaveformTable"]:
            try:
                waveform_table = UTFTable(row0["WaveformTable"])
            except Exception:
                pass

        for cue_row_idx, cue_row in enumerate(cue_table.rows):
            cue_id = cue_row.get("CueId", cue_row.get("CueIndex", 0))
            ref_idx = cue_row.get("ReferenceIndex", 0)
            # ReferenceType 可能是常量或每行字段
            ref_type = cue_row.get("ReferenceType", cue_table.constants.get("ReferenceType", 0))

            # CueNameTable 的 CueIndex 与 CueTable 行索引一一对应；
            # 部分 ACB（如 VOICE_DUNGEON_00）的 CueId 是 4000/3001 等任意值，
            # 与 CueIndex 不一致，因此优先用行索引查找，回退到 CueId。
            cue_name = self._cue_names.get(cue_row_idx, "")
            if not cue_name:
                cue_name = self._cue_names.get(cue_id, "")

            # 遍历引用链，收集所有可能的 Waveform 行索引（一个 Cue 可能有多个 track 变体）
            for wave_row_idx in self._resolve_references(ref_type, ref_idx, track_table, synth_table, seq_table):
                if wave_row_idx is None or wave_row_idx < 0:
                    continue
                # 行索引 -> StreamAwbId（AWB 内的真实 wave id）
                actual_wave = wave_row_idx
                if waveform_table is not None and wave_row_idx < len(waveform_table.rows):
                    swid = waveform_table.rows[wave_row_idx].get("StreamAwbId", 65535)
                    if swid != 65535:
                        actual_wave = swid
                self._wave_to_cue[actual_wave] = (cue_id, cue_name)

    def _resolve_reference(self, ref_type: int, ref_idx: int,
                            track_table=None, synth_table=None, depth: int = 0) -> Optional[int]:
        """兼容包装：返回第一个解析到的 Waveform 行索引"""
        results = self._resolve_references(ref_type, ref_idx, track_table, synth_table, None, depth)
        return results[0] if results else None

    def _resolve_references(self, ref_type: int, ref_idx: int,
                            track_table=None, synth_table=None, seq_table=None,
                            depth: int = 0) -> List[int]:
        """
        递归解析引用链，返回所有可能的 Waveform 行索引列表
        ReferenceType: 0=Waveform, 1=Synth, 2=Sequence, 3=Track

        正确链路（P5R 的 ACB）：
          Cue -> SequenceTable(TrackIndex) -> TrackTable -> SynthTable -> WaveformTable
        其中 TrackTable 与 SynthTable 按行索引一一对齐（Track[i] <-> Synth[i]）。
        """
        if depth > 5:
            return []
        results = []

        if ref_type == 0:
            # 直接 Waveform
            results.append(ref_idx)

        elif ref_type == 1 and synth_table is not None:
            # Synth: 查 SynthTable 的 ReferenceItems
            if ref_idx < len(synth_table.rows):
                self._synth_to_waves(synth_table.rows[ref_idx], track_table, synth_table, depth, results)

        elif ref_type in (2, 3):
            # Sequence(2) / Track(3): 通过 SequenceTable 的 TrackIndex 找到 Track 行
            track_indices = []
            if seq_table is not None and ref_idx < len(seq_table.rows):
                track_indices = self._parse_track_indices(seq_table.rows[ref_idx].get("TrackIndex", b""))
            # 回退：直接当作 TrackTable 索引
            if not track_indices and track_table is not None and ref_idx < len(track_table.rows):
                track_indices = [ref_idx]

            for ti in track_indices:
                if track_table is not None and ti < len(track_table.rows):
                    # Track 与 Synth 在 P5R 的 ACB 中按行索引对齐（Track[i] <-> Synth[i]）
                    if synth_table is not None and ti < len(synth_table.rows):
                        self._synth_to_waves(synth_table.rows[ti], track_table, synth_table, depth, results)
                    else:
                        # 回退：通过 Track 的 CommandIndex 查 SynthTable（旧逻辑）
                        cmd_idx = track_table.rows[ti].get("CommandIndex", 65535)
                        if cmd_idx != 65535 and synth_table is not None and cmd_idx < len(synth_table.rows):
                            self._synth_to_waves(synth_table.rows[cmd_idx], track_table, synth_table, depth, results)

        return results

    def _parse_track_indices(self, data) -> List[int]:
        """解析 SequenceTable 的 TrackIndex 字段（连续 uint16 大端数组）"""
        indices = []
        if isinstance(data, bytes):
            for off in range(0, len(data) - 1, 2):
                indices.append(struct.unpack(">H", data[off:off + 2])[0])
        return indices

    def _synth_to_waves(self, srow, track_table, synth_table, depth, results):
        """解析 SynthTable 行的 ReferenceItems，收集 Waveform 行索引"""
        ref_items = srow.get("ReferenceItems", b"")
        if isinstance(ref_items, bytes) and len(ref_items) >= 4:
            item_type, item_idx = struct.unpack(">HH", ref_items[:4])
            # Synth 上下文中 type=1 通常指向 Waveform
            if item_type in (0, 1):
                results.append(item_idx)
            else:
                results.extend(self._resolve_references(item_type, item_idx, track_table, synth_table, None, depth + 1))

    def get_cue_name(self, cue_index: int) -> Optional[str]:
        """获取指定 Cue 索引的名称"""
        return self._cue_names.get(cue_index)

    def get_all_cue_names(self) -> Dict[int, str]:
        """获取所有 Cue 名称映射"""
        return dict(self._cue_names)

    def get_wave_to_cue_map(self) -> Dict[int, Tuple[int, str]]:
        """获取 Wave ID -> (CueId, CueName) 映射"""
        return dict(self._wave_to_cue)

    def get_cue_for_wave(self, wave_id: int) -> Optional[Tuple[int, str]]:
        """获取指定 Wave ID 对应的 (CueId, CueName)"""
        return self._wave_to_cue.get(wave_id)

    @property
    def cue_count(self) -> int:
        """Cue 数量"""
        return len(self._cue_names)

    @property
    def wave_to_cue_count(self) -> int:
        """成功映射的 Wave→Cue 数量"""
        return len(self._wave_to_cue)


def extract_cue_names_from_acb(acb_path: str) -> Dict[int, str]:
    """
    从 ACB 文件中提取 Cue 名称映射
    :param acb_path: ACB 文件路径
    :return: {cue_index: cue_name} 字典
    """
    parser = ACBParser(acb_path)
    if parser.parse():
        return parser.get_all_cue_names()
    return {}


def extract_wave_to_cue_mapping(acb_path: str) -> Dict[int, Tuple[int, str]]:
    """
    从 ACB 文件中提取 Wave ID -> (CueId, CueName) 映射
    用于 Ryo Framework 导出（Ryo 用 Cue ID/Cue Name 标识替换目标）
    :param acb_path: ACB 文件路径
    :return: {wave_id: (cue_id, cue_name)} 字典
    """
    parser = ACBParser(acb_path)
    if parser.parse():
        return parser.get_wave_to_cue_map()
    return {}


def parse_acb_bundle(acb_path: str, need_inner: bool = True) -> dict:
    """
    一次性读取 ACB 文件并返回所有解析信息（避免对超大 ACB 重复读取磁盘）
    :param acb_path: ACB 文件路径
    :param need_inner: 是否需要检测/提取内嵌 AWB（non-streaming 音频）。
        对于已有对应 AWB 的 streaming ACB，只需解析 Cue 名称，可只读文件头部，大幅加速。
    :return: {
        "cue_names": {cue_index: cue_name},
        "wave_to_cue": {wave_id: (cue_id, cue_name)},
        "has_inner": bool,       # 是否包含内嵌 AWB（need_inner 为 True 时才检测）
        "inner_awb_data": bytes, # 内嵌 AWB 数据（has_inner 为 True 时有效）
    }
    """
    result = {
        "cue_names": {},
        "wave_to_cue": {},
        "has_inner": False,
        "inner_awb_data": None,
    }
    try:
        acb = Path(acb_path)
        fsize = acb.stat().st_size
        if fsize < 8:
            return result

        # streaming ACB：只需解析 Cue 名称，UTF 主表在文件开头，只读前部即可
        # 若前部读取后解析失败（主表异常巨大），回退到完整读取
        need_full = need_inner
        if not need_inner:
            head_size = min(fsize, 8 * 1024 * 1024)  # 8MB 足够覆盖绝大多数 ACB 主表
            with open(acb, 'rb') as f:
                data = f.read(head_size)
            parser = ACBParser(str(acb))
            if parser.parse_bytes(data):
                result["cue_names"] = parser.get_all_cue_names()
                result["wave_to_cue"] = parser.get_wave_to_cue_map()
                return result
            # 前部解析失败，回退完整读取
            need_full = True

        data = acb.read_bytes()
        if len(data) < 8:
            return result
        # 定位 @UTF 头
        if data[0:4] != b'@UTF':
            utf_pos = data.find(b'@UTF')
            if utf_pos < 0:
                return result
            data = data[utf_pos:]

        # 检查内嵌 AWB（non-streaming 音频）
        if need_inner:
            try:
                main_table = UTFTable(data)
                if main_table.rows:
                    row0 = main_table.rows[0]
                    awb_data = row0.get('AwbFile')
                    if awb_data and len(awb_data) > 8 and awb_data[:4] == b'AFS2':
                        result["has_inner"] = True
                        result["inner_awb_data"] = awb_data
            except Exception:
                pass

        # 解析 Cue 名称和 Wave→Cue 映射（用内存 bytes，不再重复读磁盘）
        parser = ACBParser(acb_path)
        if parser.parse_bytes(data):
            result["cue_names"] = parser.get_all_cue_names()
            result["wave_to_cue"] = parser.get_wave_to_cue_map()
    except Exception:
        pass
    return result


def extract_inner_awb_from_acb(acb_path: str, output_awb_path: str) -> bool:
    """
    从 non-streaming ACB 文件中提取内嵌的 AWB 文件数据并保存
    :param acb_path: ACB 文件路径
    :param output_awb_path: 输出的 AWB 文件路径
    :return: 是否成功提取
    """
    try:
        data = Path(acb_path).read_bytes()
        if len(data) < 8 or data[0:4] != b'@UTF':
            utf_pos = data.find(b'@UTF')
            if utf_pos < 0:
                return False
            data = data[utf_pos:]

        main_table = UTFTable(data)
        if not main_table.rows:
            return False

        row0 = main_table.rows[0]
        awb_data = row0.get('AwbFile')
        if not awb_data or len(awb_data) < 8:
            return False

        # 验证是否是 AFS2 (AWB) 头部
        if awb_data[:4] != b'AFS2':
            return False

        Path(output_awb_path).write_bytes(awb_data)
        return True
    except Exception:
        return False


def has_inner_awb(acb_path: str) -> bool:
    """检查 ACB 文件是否包含内嵌的 AWB（non-streaming 音频）"""
    try:
        data = Path(acb_path).read_bytes()
        if len(data) < 8 or data[0:4] != b'@UTF':
            utf_pos = data.find(b'@UTF')
            if utf_pos < 0:
                return False
            data = data[utf_pos:]

        main_table = UTFTable(data)
        if not main_table.rows:
            return False

        row0 = main_table.rows[0]
        awb_data = row0.get('AwbFile')
        return bool(awb_data and len(awb_data) > 8 and awb_data[:4] == b'AFS2')
    except Exception:
        return False

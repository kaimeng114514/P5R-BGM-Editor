# P5R BGM Editor

女神异闻录5皇家版（Persona 5 Royal）音频替换工具。支持 **BGM / 音效 / 角色语音** 三类音频的一键导入、识别、试听与替换，自动完成 ADX 编码、P5R 加密与多维音频对齐，并生成 Reloaded-II（AWB Emulator + Ryo Framework）兼容的 Mod。

> 📖 **技术文档**
> - **[VOICE_TEXT_RESEARCH.md](./VOICE_TEXT_RESEARCH.md)**：实机流程语音字幕溯源调查（如开场第一句台词为何静态文件中找不到、运行时获取方法）
> - **[AI_RESEARCH.md](./AI_RESEARCH.md)**：AI 语音识别与翻译研究报告
> - **[SFX_REPLACE_RESEARCH.md](./SFX_REPLACE_RESEARCH.md)**：音效替换调查报告（炸音成因、对齐参数、实测数据、排查表）

## 功能特性

- **三类音频支持**：BGM（主BGM + 额外BGM BGM_01~16）、音效（E*_SE/SYSTEM/TITLE 等）、角色语音（BP01~BP10、VOICE_*.AWB、EVENT 等）
- **一键替换**：任意音频（MP3/WAV/OGG/FLAC/M4A）→ 自动 转WAV → ADX编码 → P5R加密 → 多维对齐 → 生成 Mod
- **角色语音替换**：走 Ryo Framework 路径，可完整播放超长音频（不受原时长限制），无需强制等长
- **9 项音频对齐**（音效/语音界面可选，BGM 自动隐藏）：
  等长匹配 · 响度匹配(RMS) · 频谱对齐 · 带宽对齐 · 底噪对齐 · 立体声宽度 · 包络对齐 · 感知响度(LUFS) · 动态限幅
- **Ryo 播放层控音量**：volume=0.5 防止游戏内音量被自动放大（社区调研结论：P5R 有硬编码通道增益）
- **批量替换**：支持范围批量替换（如 `232000-232003`），自动补齐全部 Ryo Cue
- **AI 语音识别翻译**：Whisper medium 微调模型（日文识别）+ NLLB-200 int8（日中翻译）
- **台词标注与校准映射**：角色语音标注随工具发布
- **重复音效检测折叠**：相同音频自动分组，▶ 展开查看
- **工具完整性管理**：自动校验 / 备份 / 恢复 tools 目录

## 系统要求

- Windows 10/11
- Python 3.8+（运行源码版）
- **Reloaded-II + P5R Essentials + CRI FileSystem V2 Hook**（加载 Mod 用）
- **Ryo Framework**（非流式音频 / 角色语音替换用，Reloaded-II Mod Browser 搜索安装）

## 快速开始

### 1. 启动

双击根目录 **`启动.bat`**（自动查找 py/python/python3 并运行 `main.py`）。

### 2. 导入游戏音频

- **文件 → 导入 BASE.CPK 所在的文件夹**：选择游戏 CPK 目录，自动解包并识别 BGM、音效、角色语音三类音频（需要 `tools/CriFsV2Lib/`）
- 或 **导入 BGM.AWB** / **导入 ADX 文件夹**：直接导入已解包的数据

### 3. 选择音频并替换

1. 顶部切换「BGM / 音效 / 角色语音」选项卡
2. 列表中选择曲目，右侧查看详情
3. 「选择音乐文件」选择音频
4. 按需调整高级选项（对齐 / 循环点 / 音量 / Ryo音量 / 批量范围）
5. 「执行替换」→ 自动完成编码、加密、对齐
6. 替换多首后「导出 Mod」→ 放入 Reloaded-II 的 Mods 目录并启用

### 4. 使用建议

- **BGM**：建议设置合适循环点，否则播放完会静音；对齐选项已自动隐藏
- **音效**：保持「等长匹配原版」开启（防止无声/偏移）
- **角色语音**：等长匹配默认关闭，Ryo 路径下可超长完整播放
- **游戏内音量偏大**：调低「Ryo 播放层控音量」（默认 0.5）

## 所需工具（tools/ 目录）

| 工具 | 用途 | 必需 |
|------|------|------|
| `VGAudioCli.exe` | ADX 编码/加密/解密 | 是 |
| `adxencd.exe` | ADX 编码备选（CRI 官方） | 备选 |
| `ffmpeg.exe` | 任意音频格式 → WAV | 是 |
| `CriFsV2Lib/` | CPK 解包 .NET 库 | 导入 CPK 时 |
| `CriPakTools / vgmstream` | CPK 解包 / 音频解码备选 | 备选 |

> 可通过 **工具 → 设置工具目录** 指定路径；**工具 → 工具完整性管理** 自动校验/备份/恢复。

## AI 模型（models/ 目录，可选）

| 模型 | 用途 |
|------|------|
| `faster-whisper-medium-p5r-v4-local/` | 日文语音识别（默认） |
| `faster-whisper-small-p5r-v2/` | 轻量备用 |
| `nllb-200-distilled-600M-ct2-int8/` | 日中翻译（加载用） |
| `nllb-200-distilled-600M-p5r-v2-ct2-int8/` | 翻译可用性检测 |

模型缺失时自动下载；首次加载约 10-30 秒。

## 技术原理

### 替换流程

```
用户音频(MP3/OGG/etc.)
   │  ffmpeg / pydub
   ▼
 WAV → 多维对齐（等长/响度/频谱/带宽/底噪/立体声/包络/LUFS/动态）
   │  VGAudioCli 编码（GcAdpcm, ADX v4）
   ▼
 未加密 ADX
   │  VGAudioCli --keycode 9923540143823782
   ▼
 加密 ADX
   │  偏移19字节改为 0x09
   ▼
 P5R 兼容加密 ADX
   ├─ 流式（BGM/音效）→ FEmulator/AWB/
   └─ 非流式（TITLE等/语音）→ Ryo Framework（volume=0.5 控音量）
```

### 关键参数

- **加密密钥**：`9923540143823782`
- **加密标识字节**：偏移 19（0-indexed）设为 `0x09`
- **ADX 编码**：标准 CRI ADX v4（GcAdpcm）

### Mod 加载机制

- **BGM/音效**：Reloaded-II + P5R Essentials 的 FEmulator 文件重定向，ADX 放 `FEmulator/AWB/{AWB名}.AWB/` 下
- **非流式音频 / 角色语音**：Ryo Framework（自动配置为依赖项），音量由 Ryo 播放层控制

## 目录结构

```
P5R_BGM_Editor/
├── 启动.bat              # 一键启动
├── main.py               # 主程序（GUI）
├── adx_utils.py          # ADX 编码/加密/解密 + 9项对齐
├── awb_utils.py          # AWB 归档解包 / Mod 结构构建
├── acb_utils.py          # ACB 解析（Ryo Cue）
├── cpk_utils.py          # CPK 解包
├── voice_ai.py           # Whisper 语音识别
├── p5r_terms.py          # NLLB 日中翻译
├── voice_text_matcher.py # 台词匹配
├── bgm_names.py          # 曲名数据库
├── protect_tools.py      # 工具完整性管理
├── tools/                # 外部工具
├── models/               # AI 模型
├── replaced/             # 替换产物
├── config.json           # 运行时配置
└── README.md
```

## 常见问题

### Q: 替换后游戏没有声音？
A: 检查：① Mod 已在 Reloaded-II 启用；② P5R Essentials 已启用且为依赖；③ ADX 已正确加密（密钥+偏移字节）；④ Wave ID 正确；⑤ 音效是否开启等长匹配（不等长会导致无声）。

### Q: 游戏内声音太大 / 有爆音？
A: 音效替换请保持「响度匹配 + 频谱对齐 + 动态限幅」开启；游戏内仍偏大时调低「Ryo 播放层控音量」（默认 0.5）。P5R 存在硬编码通道增益，会放大替换音频，Ryo 播放层是社区推荐的彻底解决方案。

### Q: 提示缺少工具？
A: 将对应工具放入 `tools/` 目录，或「工具 → 设置工具目录」指定路径；「工具 → 工具完整性管理」可从备份自动恢复。

### Q: 角色语音替换需要等长吗？
A: 不需要。角色语音走 Ryo 路径，可完整播放超长音频，等长匹配默认关闭（仅音效需要强制等长）。

### Q: 曲名显示"未知曲目"？
A: 该 Wave ID 不在内置数据库，可通过「工具 → 编辑曲名数据库」手动添加。

## 致谢

本工具使用并致敬以下开源项目（详见工具内 **作者 → 参考工具**，点击可跳转）：

- **VGAudio / VGAudioCli** — Thealexbarney (Alex Barney)：ADX 编码/加密/解密
- **vgmstream** — bnnm 等：游戏音频解码
- **FFmpeg** — FFmpeg 开源团队：音频格式转换
- **CriFsV2Lib** — Sewer56：CPK 解包
- **CriPakTools** — esperknight：CPK 解包备选
- **Atlus-Script-Tools / AtlusMSGEditor** — tge-was-taken：剧情脚本/文本处理
- **PersonaVCE** — ShrineFox：Persona 语音剪辑
- **Reloaded-II** — Sewer56：Mod 加载器
- **FileEmulationFramework** — Sewer56：AWB Emulator
- **Ryo Framework** — RyoTune：非流式音频替换
- **faster-whisper** — SYSTRAN：语音识别
- **Whisper** — OpenAI：语音识别模型
- **ctranslate2** — OpenNMT：模型推理引擎
- **sentencepiece** — Google：分词
- **NLLB** — Meta AI (FAIR)：多语言翻译模型
- **PyTorch / numpy / scipy / pydub / pygame / Pillow / pythonnet** — 各开源社区

## 免责声明

本工具仅供学习和个人使用。请尊重游戏版权，不要将替换后的音乐用于商业用途或非法分发。

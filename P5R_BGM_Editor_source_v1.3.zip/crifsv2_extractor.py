# -*- coding: utf-8 -*-
"""
CriFsV2Lib 提取器（通过 pythonnet 调用 .NET 库）
专为 P5R 大 CPK（25GB+）设计，使用流式读取，无内存溢出问题
依赖: pythonnet, .NET 7+ 运行时, CriFsV2Lib.dll + CriFsV2Lib.Definitions.dll
"""

import os
import time
import threading
from pathlib import Path
from typing import Dict, List, Optional, Callable

# 进度回调类型: (percent: int, message: str, phase: str)
ProgressCallback = Callable[[int, str, str], None]

# 模块级状态
_dotnet_loaded = False
_dotnet_error = None
_cpk_helper_type = None
_p5r_crypto_type = None
_get_files_method = None
_extract_file_method = None
_decrypt_func = None


def is_available(tools_dir: str = "tools") -> bool:
    """检查 CriFsV2Lib 是否可用（pythonnet + DLL + .NET 运行时）"""
    global _dotnet_loaded, _dotnet_error

    if _dotnet_loaded:
        return True
    if _dotnet_error:
        return False

    # 检查 pythonnet
    try:
        import pythonnet
    except ImportError:
        _dotnet_error = "pythonnet 未安装"
        return False

    # 检查 DLL（转为绝对路径）
    dll_dir = Path(tools_dir).resolve() / "CriFsV2Lib"
    main_dll = dll_dir / "CriFsV2Lib.dll"
    def_dll = dll_dir / "CriFsV2Lib.Definitions.dll"
    if not main_dll.exists():
        _dotnet_error = f"缺少 {main_dll}"
        return False
    if not def_dll.exists():
        _dotnet_error = f"缺少 {def_dll}"
        return False

    # 尝试加载
    try:
        _load_dotnet(str(dll_dir))
        return True
    except Exception as e:
        _dotnet_error = str(e)
        return False


def get_error() -> Optional[str]:
    """获取上次加载失败的错误信息"""
    return _dotnet_error


def _load_dotnet(dll_dir: str):
    """加载 .NET Core 运行时和 CriFsV2Lib 程序集（只执行一次）"""
    global _dotnet_loaded, _cpk_helper_type, _p5r_crypto_type
    global _get_files_method, _extract_file_method, _decrypt_func

    if _dotnet_loaded:
        return

    # 转为绝对路径，避免相对路径在 chdir 后重复拼接
    dll_dir = str(Path(dll_dir).resolve())
    def_dll_path = os.path.join(dll_dir, "CriFsV2Lib.Definitions.dll")
    main_dll_path = os.path.join(dll_dir, "CriFsV2Lib.dll")

    # 配置 pythonnet 使用 .NET Core
    os.environ.setdefault("PYTHONNET_RUNTIME", "coreclr")
    # 尝试常见的 .NET 安装路径
    dotnet_paths = [
        r"C:\Program Files\dotnet",
        r"C:\Program Files (x86)\dotnet",
        os.environ.get("DOTNET_ROOT", ""),
    ]
    for dp in dotnet_paths:
        if dp and os.path.exists(os.path.join(dp, "dotnet.exe")):
            os.environ["DOTNET_ROOT"] = dp
            break

    from pythonnet import load
    load("coreclr")

    import clr
    from System import Reflection, IO

    # 切换到 DLL 目录，确保 .NET 能解析依赖
    old_cwd = os.getcwd()
    os.chdir(dll_dir)
    try:
        # 用绝对路径加载程序集（避免相对路径被二次解析）
        Reflection.Assembly.LoadFrom(def_dll_path)
        asm = Reflection.Assembly.LoadFrom(main_dll_path)

        # 获取关键类型
        _cpk_helper_type = asm.GetType("CriFsV2Lib.Utilities.Parsing.CpkHelper")
        _p5r_crypto_type = asm.GetType("CriFsV2Lib.Encryption.Game.P5RCrypto")

        if _cpk_helper_type is None:
            raise RuntimeError("无法找到 CpkHelper 类型")
        if _p5r_crypto_type is None:
            raise RuntimeError("无法找到 P5RCrypto 类型")

        # 获取 GetFilesFromStream 静态方法
        _get_files_method = _cpk_helper_type.GetMethod(
            "GetFilesFromStream",
            Reflection.BindingFlags.Public | Reflection.BindingFlags.Static
        )

        # 获取 ExtractFile 静态方法（3参数版本: CpkFile, Stream, InPlaceDecryptionFunction）
        for m in _cpk_helper_type.GetMethods(
            Reflection.BindingFlags.Public | Reflection.BindingFlags.Static
        ):
            if m.Name == "ExtractFile" and len(m.GetParameters()) == 3:
                _extract_file_method = m
                break

        if _get_files_method is None:
            raise RuntimeError("无法找到 GetFilesFromStream 方法")
        if _extract_file_method is None:
            raise RuntimeError("无法找到 ExtractFile 方法")

        # 获取 P5R 解密函数
        decrypt_prop = _p5r_crypto_type.GetProperty(
            "DecryptionFunction",
            Reflection.BindingFlags.Public | Reflection.BindingFlags.Static
        )
        if decrypt_prop is None:
            raise RuntimeError("无法找到 P5RCrypto.DecryptionFunction 属性")
        _decrypt_func = decrypt_prop.GetValue(None)

        _dotnet_loaded = True
    finally:
        os.chdir(old_cwd)


def extract_bgm(cpk_path: str, output_dir: str,
                 tools_dir: str = "tools",
                 progress: Optional[ProgressCallback] = None,
                 cancel_event: Optional[threading.Event] = None) -> Dict[str, str]:
    """
    使用 CriFsV2Lib 从 CPK 中提取 BGM.AWB 和 BGM.ACB

    :param cpk_path: CPK 文件路径
    :param output_dir: 输出目录
    :param tools_dir: 工具目录（含 CriFsV2Lib 子目录）
    :param progress: 进度回调 (percent, message, phase)
    :param cancel_event: 取消事件
    :return: {文件名: 输出路径} 字典
    :raises RuntimeError: 提取失败时抛出
    """
    global _dotnet_loaded, _dotnet_error

    dll_dir = str(Path(tools_dir).resolve() / "CriFsV2Lib")

    # 确保已加载
    if not _dotnet_loaded:
        if not is_available(tools_dir):
            raise RuntimeError(f"CriFsV2Lib 不可用: {_dotnet_error}")

    from System import IO

    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    cpk_path = str(cpk_path)

    if progress:
        progress(2, f"打开 CPK: {Path(cpk_path).name}", "init")

    # 打开文件流
    stream = IO.FileStream(
        cpk_path, IO.FileMode.Open, IO.FileAccess.Read, IO.FileShare.Read
    )

    try:
        # 阶段1: 读取文件表
        if progress:
            progress(5, "读取文件表（流式解析，大文件也很快）...", "parse")

        parse_start = time.time()
        files = _get_files_method.Invoke(None, [stream])
        file_count = files.Length
        parse_time = time.time() - parse_start

        if progress:
            progress(15, f"文件表读取完成: {file_count} 个文件 ({parse_time:.1f}秒)", "parse")

        # 检查取消
        if cancel_event and cancel_event.is_set():
            return {}

        # 阶段2: 搜索所有 BGM 文件（BGM.AWB + BGM_01.AWB...BGM_16.AWB 等额外BGM）
        if progress:
            progress(18, "搜索 BGM 和音效 AWB 文件...", "search")

        found = {}
        for i in range(file_count):
            if cancel_event and cancel_event.is_set():
                return {}
            f = files[i]
            fname_prop = f.GetType().GetProperty("FileName")
            if fname_prop:
                fname = str(fname_prop.GetValue(f))
                fname_upper = fname.upper().replace('\\', '/').split('/')[-1]
                # 匹配所有音频 AWB/ACB：
                #  - BGM*.AWB/ACB（背景音乐）
                #  - E*_SE.AWB/ACB（过场音效）
                #  - BP01*.AWB/ACB（战斗语音）
                #  - VOICE_*.AWB/ACB（角色语音）
                if not (fname_upper.endswith(".AWB") or fname_upper.endswith(".ACB")):
                    continue
                # 提取所有 AWB/ACB 文件（BGM/音效/BP战斗语音/VOICE剧情语音/BE_BOSS Boss语音/BE战斗事件语音/E过场语音等）
                found[fname_upper] = (i, f)

        if not found:
            raise RuntimeError(
                f"在 CPK 中未找到任何 BGM 或音效 AWB 文件（共搜索 {file_count} 个文件）"
            )

        if progress:
            progress(20, f"找到 {len(found)} 个音频文件，开始提取...", "extract")

        # 阶段3: 提取文件（跳过已存在且大小一致的缓存文件，大幅加速二次启动）
        result = {}
        total_size = 0          # 需要实际提取的文件总大小（已缓存的不计）
        cached_count = 0
        skipped_size = 0

        # 先计算"需要实际提取"的文件（已存在且大小一致 -> 跳过）
        need_extract = {}       # name -> (idx, cpk_file, file_size)
        for name, (idx, cpk_file) in found.items():
            size_prop = cpk_file.GetType().GetProperty("ExtractSize")
            file_size = int(size_prop.GetValue(cpk_file)) or 0 if size_prop else 0
            out_path = output_dir / name
            # 已存在且大小一致：视为已提取缓存，直接复用
            if out_path.exists() and file_size > 0 and out_path.stat().st_size == file_size:
                cached_count += 1
                skipped_size += file_size
                result[name] = str(out_path)
                continue
            need_extract[name] = (idx, cpk_file, file_size)
            total_size += file_size

        if cached_count > 0 and progress:
            progress(20, f"已缓存 {cached_count} 个文件（跳过），需提取 {len(need_extract)} 个...", "extract")

        current_pct = 20
        extracted_size = 0
        for name, (idx, cpk_file, file_size) in need_extract.items():
            if cancel_event and cancel_event.is_set():
                return result

            if progress:
                mb = file_size / (1024 * 1024)
                progress(current_pct, f"提取 {name} ({mb:.1f} MB)...", "extract")

            extract_start = time.time()

            # 重置流位置（ExtractFile 内部会 seek）
            stream.Position = 0

            # 调用 ExtractFile，返回 ArrayRental
            rental = _extract_file_method.Invoke(None, [cpk_file, stream, _decrypt_func])

            # 从 ArrayRental 获取数据
            raw_array = rental.RawArray
            count = int(rental.Count)

            # 写入文件（用 FileStream 分块写，避免大数组转换）
            out_path = output_dir / name
            fs = IO.FileStream(str(out_path), IO.FileMode.Create, IO.FileAccess.Write)
            try:
                # 分块写入（每块 16MB）
                chunk_size = 16 * 1024 * 1024
                written = 0
                while written < count:
                    if cancel_event and cancel_event.is_set():
                        fs.Dispose()
                        return result
                    to_write = min(chunk_size, count - written)
                    fs.Write(raw_array, written, to_write)
                    written += to_write

                    # 进度报告（只按需要提取的文件计算）
                    if total_size > 0:
                        overall = int(20 + (extracted_size + written) / total_size * 75)
                        overall = min(overall, 95)
                        if progress and overall > current_pct:
                            current_pct = overall
                            mb_written = written / (1024 * 1024)
                            mb_total = count / (1024 * 1024)
                            progress(
                                overall,
                                f"提取 {name}: {mb_written:.1f}/{mb_total:.1f} MB",
                                "extract"
                            )
            finally:
                fs.Dispose()

            # 释放 ArrayRental
            if hasattr(rental, 'Dispose'):
                rental.Dispose()

            extract_time = time.time() - extract_start
            extracted_size += file_size

            if os.path.exists(out_path):
                result[name] = str(out_path)
                if progress:
                    mb = os.path.getsize(out_path) / (1024 * 1024)
                    progress(
                        current_pct,
                        f"{name} 提取完成 ({mb:.1f} MB, 用时 {extract_time:.1f}秒)",
                        "extract"
                    )

        if progress:
            msg = f"CriFsV2Lib 提取完成: {len(result)} 个文件"
            if cached_count > 0:
                msg += f"（其中 {cached_count} 个来自缓存跳过）"
            progress(100, msg, "done")

        return result

    finally:
        stream.Dispose()


def list_awb_files(cpk_path: str, tools_dir: str = "tools",
                    progress: Optional[ProgressCallback] = None,
                    cancel_event: Optional[threading.Event] = None) -> List[str]:
    """
    列出 CPK 中所有 .AWB 文件（用于让用户选择要解包的语音/音乐 AWB）

    :param cpk_path: CPK 文件路径
    :param tools_dir: 工具目录
    :param progress: 进度回调
    :param cancel_event: 取消事件
    :return: AWB 文件名列表（大写）
    """
    global _dotnet_loaded, _dotnet_error

    if not _dotnet_loaded:
        if not is_available(tools_dir):
            raise RuntimeError(f"CriFsV2Lib 不可用: {_dotnet_error}")

    from System import IO

    cpk_path = str(cpk_path)
    if progress:
        progress(5, f"打开 CPK: {Path(cpk_path).name}", "init")

    stream = IO.FileStream(
        cpk_path, IO.FileMode.Open, IO.FileAccess.Read, IO.FileShare.Read
    )
    try:
        if progress:
            progress(10, "读取文件表...", "parse")
        files = _get_files_method.Invoke(None, [stream])
        file_count = files.Length

        awb_names = []
        for i in range(file_count):
            if cancel_event and cancel_event.is_set():
                return []
            f = files[i]
            fname_prop = f.GetType().GetProperty("FileName")
            if fname_prop:
                fname = str(fname_prop.GetValue(f))
                if fname.upper().endswith(".AWB"):
                    awb_names.append(fname)

        if progress:
            progress(100, f"找到 {len(awb_names)} 个 AWB 文件", "done")
        return sorted(awb_names)
    finally:
        stream.Dispose()


def extract_files(cpk_path: str, output_dir: str, target_filenames: List[str],
                  tools_dir: str = "tools",
                  progress: Optional[ProgressCallback] = None,
                  cancel_event: Optional[threading.Event] = None) -> Dict[str, str]:
    """
    使用 CriFsV2Lib 从 CPK 中提取指定文件名的文件（泛化版本，支持任意 ACB/AWB/其他文件）

    :param cpk_path: CPK 文件路径
    :param output_dir: 输出目录
    :param target_filenames: 要提取的文件名列表（不区分大小写）
    :param tools_dir: 工具目录
    :param progress: 进度回调
    :param cancel_event: 取消事件
    :return: {文件名: 输出路径} 字典
    """
    global _dotnet_loaded, _dotnet_error

    if not _dotnet_loaded:
        if not is_available(tools_dir):
            raise RuntimeError(f"CriFsV2Lib 不可用: {_dotnet_error}")

    from System import IO

    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    cpk_path = str(cpk_path)

    # 目标文件名转大写用于匹配
    targets_upper = {name.upper(): name for name in target_filenames}

    if progress:
        progress(2, f"打开 CPK: {Path(cpk_path).name}", "init")

    stream = IO.FileStream(
        cpk_path, IO.FileMode.Open, IO.FileAccess.Read, IO.FileShare.Read
    )
    try:
        if progress:
            progress(5, "读取文件表...", "parse")
        files = _get_files_method.Invoke(None, [stream])
        file_count = files.Length

        if cancel_event and cancel_event.is_set():
            return {}

        if progress:
            progress(15, f"搜索目标文件（共 {file_count} 个文件）...", "search")

        found = {}
        for i in range(file_count):
            if cancel_event and cancel_event.is_set():
                return {}
            f = files[i]
            fname_prop = f.GetType().GetProperty("FileName")
            if fname_prop:
                fname = str(fname_prop.GetValue(f))
                if fname.upper() in targets_upper:
                    found[fname] = (i, f)

        if not found:
            raise RuntimeError(
                f"在 CPK 中未找到目标文件: {', '.join(target_filenames)}（共搜索 {file_count} 个文件）"
            )

        if progress:
            progress(20, f"找到 {len(found)} 个文件，开始提取...", "extract")

        result = {}
        total_size = 0
        extracted_size = 0
        cached_count = 0

        # 跳过已存在且大小一致的文件（加速二次提取）
        need_extract = {}
        for name, (idx, cpk_file) in found.items():
            size_prop = cpk_file.GetType().GetProperty("ExtractSize")
            file_size = int(size_prop.GetValue(cpk_file)) or 0 if size_prop else 0
            out_path = output_dir / name
            if out_path.exists() and file_size > 0 and out_path.stat().st_size == file_size:
                cached_count += 1
                result[name] = str(out_path)
                continue
            need_extract[name] = (idx, cpk_file, file_size)
            total_size += file_size

        if cached_count > 0 and progress:
            progress(20, f"已缓存 {cached_count} 个文件（跳过），需提取 {len(need_extract)} 个...", "extract")

        current_pct = 20
        for name, (idx, cpk_file, file_size) in need_extract.items():
            if cancel_event and cancel_event.is_set():
                return result

            if progress:
                mb = file_size / (1024 * 1024)
                progress(current_pct, f"提取 {name} ({mb:.1f} MB)...", "extract")

            stream.Position = 0
            rental = _extract_file_method.Invoke(None, [cpk_file, stream, _decrypt_func])
            raw_array = rental.RawArray
            count = int(rental.Count)

            out_path = output_dir / name
            fs = IO.FileStream(str(out_path), IO.FileMode.Create, IO.FileAccess.Write)
            try:
                chunk_size = 16 * 1024 * 1024
                written = 0
                while written < count:
                    if cancel_event and cancel_event.is_set():
                        fs.Dispose()
                        return result
                    to_write = min(chunk_size, count - written)
                    fs.Write(raw_array, written, to_write)
                    written += to_write
                    if total_size > 0:
                        overall = int(20 + (extracted_size + written) / total_size * 75)
                        overall = min(overall, 95)
                        if progress and overall > current_pct:
                            current_pct = overall
                            progress(overall, f"提取 {name}: {written/(1024*1024):.1f}/{count/(1024*1024):.1f} MB", "extract")
            finally:
                fs.Dispose()

            if hasattr(rental, 'Dispose'):
                rental.Dispose()

            extracted_size += file_size
            if os.path.exists(out_path):
                result[name] = str(out_path)

        if progress:
            msg = f"提取完成: {len(result)} 个文件"
            if cached_count > 0:
                msg += f"（其中 {cached_count} 个来自缓存跳过）"
            progress(100, msg, "done")
        return result
    finally:
        stream.Dispose()

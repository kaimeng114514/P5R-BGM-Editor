# -*- coding: utf-8 -*-
"""
P5R_BGM_Editor 工具目录保护程序
================================
功能：
1. 校验 tools 目录完整性（检查必需工具是否存在、文件大小是否合理）
2. 备份：将完整 tools 目录打包为 tools_backup.zip（备份到项目外，防止 tools 自身被清理）
3. 恢复：从 tools_backup.zip 或各 release zip 恢复缺失/损坏的工具
4. 提供命令行接口：protect_tools.py check / backup / restore / list

用法：
  python protect_tools.py check          # 校验 tools 完整性
  python protect_tools.py backup         # 备份 tools 到 tools_backup.zip
  python protect_tools.py restore        # 从备份恢复缺失工具
  python protect_tools.py restore --force # 强制恢复（覆盖现有文件）
  python protect_tools.py list           # 列出 manifest 中的工具

集成到 main.py：from protect_tools import verify_tools, restore_missing
"""
import io
import json
import os
import shutil
import sys
import zipfile
from pathlib import Path

# 确保中文输出正常
if sys.stdout and hasattr(sys.stdout, "buffer"):
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")

PROJECT_ROOT = Path(__file__).resolve().parent
MANIFEST_PATH = PROJECT_ROOT / "tools_manifest.json"
TOOLS_DIR = PROJECT_ROOT / "tools"
# 备份文件放在项目根目录（而非 tools 内部，防止 tools 被清理时备份也丢失）
BACKUP_PATH = PROJECT_ROOT / "tools_backup.zip"


def load_manifest() -> dict:
    """加载工具清单"""
    if not MANIFEST_PATH.exists():
        raise RuntimeError(f"缺少工具清单文件: {MANIFEST_PATH}")
    with open(MANIFEST_PATH, "r", encoding="utf-8") as f:
        return json.load(f)


def check_file(path: Path, min_size: int) -> bool:
    """检查单个文件是否存在且大小合理"""
    if not path.exists():
        return False
    if not path.is_file():
        return False
    if path.stat().st_size < min_size:
        return False
    return True


def verify_tools(tools_dir=None) -> dict:
    """
    校验 tools 目录完整性
    返回: {"ok": bool, "missing": [缺失清单], "corrupt": [损坏清单], "report": 文本报告}
    """
    tools_dir = Path(tools_dir) if tools_dir else TOOLS_DIR
    manifest = load_manifest()
    required = manifest.get("required", {})
    optional = manifest.get("optional", {})

    missing = []
    corrupt = []
    all_ok = True

    for rel, info in required.items():
        path = tools_dir / rel
        min_size = info.get("min_size", 0)
        if not check_file(path, min_size):
            missing.append(f"{rel}（{info.get('desc','')}）")
            all_ok = False
        else:
            # 抽查大小
            actual = path.stat().st_size
            expected = info.get("min_size", 0)
            if actual < expected:
                corrupt.append(f"{rel}（大小异常: {actual} < {expected}）")
                all_ok = False

    # 可选工具：只报告缺失，不影响 ok
    opt_missing = []
    for rel, info in optional.items():
        path = tools_dir / rel
        if not check_file(path, info.get("min_size", 0)):
            opt_missing.append(f"{rel}（{info.get('desc','')}）")

    lines = []
    if all_ok:
        lines.append(f"✓ 所有必需工具就绪（{tools_dir}）")
    else:
        lines.append(f"✗ 发现 {len(missing)} 个缺失工具、{len(corrupt)} 个异常工具")
        if missing:
            lines.append("\n缺失:")
            for m in missing:
                lines.append(f"  - {m}")
        if corrupt:
            lines.append("\n大小异常:")
            for c in corrupt:
                lines.append(f"  - {c}")
    if opt_missing:
        lines.append("\n可选工具缺失（不影响核心功能）:")
        for m in opt_missing:
            lines.append(f"  - {m}")

    return {
        "ok": all_ok,
        "missing": missing,
        "corrupt": corrupt,
        "opt_missing": opt_missing,
        "report": "\n".join(lines),
    }


def backup_tools(tools_dir=None, backup_path=None) -> str:
    """备份 tools 目录到 zip"""
    tools_dir = Path(tools_dir) if tools_dir else TOOLS_DIR
    backup_path = Path(backup_path) if backup_path else BACKUP_PATH

    if not tools_dir.exists():
        raise RuntimeError(f"tools 目录不存在: {tools_dir}")

    # 排除 zip 备份源自身，避免备份体积膨胀（保留 exe/dll 和已解压子目录）
    exclude_exts = {".zip"}
    count = 0
    total_size = 0

    with zipfile.ZipFile(backup_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for root, dirs, files in os.walk(tools_dir):
            for name in files:
                ext = Path(name).suffix.lower()
                if ext in exclude_exts:
                    continue
                full = Path(root) / name
                rel = full.relative_to(tools_dir.parent)  # 保留 tools/ 前缀
                zf.write(full, rel.as_posix())
                count += 1
                total_size += full.stat().st_size

    return f"备份完成: {backup_path}（{count} 个文件，{total_size/1024/1024:.1f} MB）"


def restore_missing(tools_dir=None, backup_path=None, force=False) -> str:
    """
    从备份 zip 恢复缺失/损坏的工具。
    只恢复缺失或损坏的文件，不覆盖已有且正常的文件（除非 force=True）。
    """
    tools_dir = Path(tools_dir) if tools_dir else TOOLS_DIR
    backup_path = Path(backup_path) if backup_path else BACKUP_PATH

    if not backup_path.exists():
        raise RuntimeError(f"备份文件不存在: {backup_path}，请先运行 protect_tools.py backup")

    manifest = load_manifest()
    all_reqs = {**manifest.get("required", {}), **manifest.get("optional", {})}

    tools_dir.mkdir(parents=True, exist_ok=True)

    restored = []
    with zipfile.ZipFile(backup_path, "r") as zf:
        # 建立备份内文件索引（去 tools/ 前缀）
        backup_map = {}
        for info in zf.infolist():
            name = info.filename
            # 统一为相对 tools/ 的路径
            if name.startswith("tools/"):
                name = name[len("tools/"):]
            elif name.startswith("tools\\"):
                name = name[len("tools\\"):]
            backup_map[name] = info

        for rel, info in all_reqs.items():
            target = tools_dir / rel
            needs_restore = force or not check_file(target, info.get("min_size", 0))
            if not needs_restore:
                continue
            # 在备份中查找（兼容大小写差异）
            found_name = None
            for bname in backup_map:
                if bname.lower() == rel.lower():
                    found_name = bname
                    break
            if not found_name:
                continue
            target.parent.mkdir(parents=True, exist_ok=True)
            with zf.open(backup_map[found_name]) as src, open(target, "wb") as dst:
                shutil.copyfileobj(src, dst)
            restored.append(rel)

    if restored:
        return f"已恢复 {len(restored)} 个文件:\n  " + "\n  ".join(restored)
    return "无需恢复：所有工具均完好（或备份中未找到缺失项）"


def list_tools() -> str:
    """列出 manifest 中的工具及当前状态"""
    manifest = load_manifest()
    lines = ["工具清单："]

    for section, label in [("required", "必需"), ("optional", "可选")]:
        items = manifest.get(section, {})
        if not items:
            continue
        lines.append(f"\n[{label}]")
        for rel, info in items.items():
            path = TOOLS_DIR / rel
            status = "✓" if check_file(path, info.get("min_size", 0)) else "✗"
            actual = path.stat().st_size if path.exists() else 0
            lines.append(f"  {status} {rel} ({actual} bytes) - {info.get('desc','')}")

    return "\n".join(lines)


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        return

    cmd = sys.argv[1].lower()
    force = "--force" in sys.argv

    try:
        if cmd == "check":
            result = verify_tools()
            print(result["report"])
            sys.exit(0 if result["ok"] else 1)
        elif cmd == "backup":
            print(backup_tools())
        elif cmd == "restore":
            print(restore_missing(force=force))
        elif cmd == "list":
            print(list_tools())
        else:
            print(f"未知命令: {cmd}")
            print(__doc__)
    except Exception as e:
        print(f"错误: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()

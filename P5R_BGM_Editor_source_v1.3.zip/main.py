# -*- coding: utf-8 -*-
"""
P5R BGM Editor - 女神异闻录5皇家版 音乐替换工具
主 GUI 应用程序

功能：
- 导入 BGM.AWB 或 ADX 文件夹
- 自动识别曲目名称
- 试听预览
- 一键替换音乐（自动完成 WAV->ADX->加密 全流程）
- 导出 Reloaded-II Mod
"""

import os
import sys
import json
import time
import wave
import threading
import tempfile
import subprocess
from pathlib import Path
from tkinter import (
    Tk, ttk, filedialog, messagebox, Listbox, Scrollbar,
    Frame, Label, Button, StringVar, BooleanVar, Checkbutton,
    Canvas, Menu, Toplevel, Entry, Text, LabelFrame, END, BOTH, LEFT, RIGHT,
    TOP, BOTTOM, X, Y, W, E, N, S, VERTICAL, HORIZONTAL, DISABLED,
    NORMAL, SUNKEN, RAISED, RIDGE, GROOVE, FLAT, WORD
)
from tkinter import ttk
import tkinter.font as tkfont

# 尝试导入音频播放库
try:
    import pygame
    HAS_PYGAME = True
except ImportError:
    HAS_PYGAME = False

try:
    import winsound
    HAS_WINSOUND = True
except ImportError:
    HAS_WINSOUND = False

# 尝试导入 PIL（用于图片显示）
try:
    from PIL import Image, ImageTk
    HAS_PIL = True
except ImportError:
    HAS_PIL = False

# 导入项目模块
from bgm_names import BGM_NAMES, BGM_CATEGORIES, get_bgm_name, is_known_track

# BP编号 -> 角色名映射（P5R 战斗语音，参考 spriters-resource 日文语音分类）
BP_CHARACTER_MAP = {
    "BP01": "Joker",
    "BP02": "Skull",
    "BP03": "Mona",
    "BP04": "Panther",
    "BP05": "Fox",
    "BP06": "Queen",
    "BP07": "Noir",
    "BP08": "Crow (Robin Hood)",
    "BP09": "Crow (Loki)",
    "BP09_01": "Crow (Robin Hood)",
    "BP10": "Violet",
}

# 特定 wave_id 的单条标注（列表显示时追加到曲名后）
SPECIAL_TRACK_NOTES = {
    2418003: "(joker:伊邪那岐大神)",
}
from adx_utils import ADXProcessor, ADXToolError, get_adx_info, is_adx_encrypted
from awb_utils import AWBExtractor, find_bgm_awb
from cpk_utils import CPKExtractor, find_base_cpk, list_cpk_files
from acb_utils import extract_cue_names_from_acb, extract_inner_awb_from_acb, has_inner_awb, parse_acb_bundle

# 角色语音 → 中文台词 匹配器（SC.CPK 反编译台词库）
try:
    from voice_text_matcher import VoiceTextMatcher
    HAS_TEXT_MATCHER = True
except ImportError:
    HAS_TEXT_MATCHER = False


APP_VERSION = "1.3.0"
APP_TITLE = f"P5R BGM Editor v{APP_VERSION} - 女神异闻录5皇家版 音乐替换工具"
CONFIG_FILE = "config.json"
# 替换文件持久化目录（相对项目根目录）
REPLACED_DIR = "replaced"
# 替换记录保存的文件
REPLACEMENTS_FILE = "replacements.json"
# 用户自定义曲目标注保存的文件（随工具一起发布，别人下载解包后也能看到）
TRACK_NOTES_FILE = "track_notes.json"
# AI 语音识别结果保存的文件（wave_id -> 翻译文本）
AI_TRANSCRIPTS_FILE = "ai_transcripts.json"
# 有语音但无 BMD 台词文本的「流程语音」AI 识别数据（供官方台词库为空时参考显示）
EXTRA_FLOW_TEXT_FILE = "voice_extra_flow_text.json"


class P5RBGMEditor:
    """主应用类"""

    def __init__(self, root: Tk):
        self.root = root
        self.root.title(APP_TITLE)
        self.root.geometry("1100x700")
        self.root.minsize(900, 600)

        # 数据
        self.tracks = []  # [{wave_id, name, path, filename, size, replaced, replaced_path}]
        self.bgm_tracks = []  # BGM 列表（主BGM + 额外BGM）
        self.sfx_tracks = []  # 音效列表（E*_SE 等过场音效）
        self.voice_tracks = []  # 角色语音列表（BP01, VOICE_*）
        self.current_audio_type = "bgm"  # 当前显示类型: "bgm" / "sfx" / "voice"
        self.show_placeholder_sfx = False  # 音效列表是否显示空槽位占位符（默认隐藏）
        self.voice_filter_var = StringVar(value="全部角色")  # 角色语音筛选（按角色/BP编号）
        self.current_track = None
        self.search_var = StringVar()
        self.category_var = StringVar(value="全部")
        self.status_var = StringVar(value="就绪")
        self.tools_dir = StringVar(value="tools")
        self.playing = False
        self._paused = False
        self.preview_wav = None
        self.preview_duration = 0.0
        self._progress_seeking = False
        self._last_seek_time = 0.0
        self._progress_after_id = None
        self._play_start_time = 0.0
        self._play_offset = 0.0

        # 替换记录 {wave_id: {"source_file": 原文件路径, "replaced_file": 生成的ADX路径, "track_name": 曲名}}
        self.replacements = {}
        self._replaced_dir = Path(REPLACED_DIR)
        self._replaced_dir.mkdir(parents=True, exist_ok=True)
        # 用户自定义曲目标注（从 track_notes.json 加载，覆盖内置 SPECIAL_TRACK_NOTES）
        self.track_notes = {}
        self._load_track_notes()
        # 台词校准缓存：awb_stem -> {local_wave_id: bmd_index}（用户标注变化时清空）
        self._calib_cache = {}
        # 语音标注索引：awb_upper -> [(local_wave, note), ...]（惰性构建，避免每次全量遍历）
        self._voice_notes_index = None
        self._voice_notes_sig = None
        # AI 语音识别结果 {wave_id: 翻译文本}
        self.ai_transcripts = {}
        self._load_ai_transcripts()
        # AI 识别+模糊匹配绿色标记缓存：{ (awb_upper, wave_id): matched_idx }，-1=无匹配（避免重复识别）
        self._ai_match_cache = {}
        self._ai_match_busy = False       # 是否正在识别（防止并发）
        self._ai_match_waiting = None     # 待识别的目标 (t, awb_upper, wave_id, all_texts)
        # 角色语音 → 中文台词匹配器（延迟加载）
        if HAS_TEXT_MATCHER:
            self.text_matcher = VoiceTextMatcher(".")
            # 加载用户校准映射（从标注建立的 wave_id->文本索引映射，不修改标注数据）
            try:
                self.text_matcher.load_calibration()
            except Exception:
                pass
        else:
            self.text_matcher = None
        # 有语音但无 BMD 台词文本的「流程语音」识别数据（voice_extra_flow_text.json）
        # 供官方台词库为空时显示 AI 识别文本作为参考（不污染官方中文台词库）
        self._extra_flow_text = {}
        try:
            _ef_path = Path(EXTRA_FLOW_TEXT_FILE)
            if _ef_path.exists():
                with open(_ef_path, "r", encoding="utf-8") as _ef:
                    _ef_data = json.load(_ef)
                self._extra_flow_text = _ef_data.get("awb_extra_flow", {}) or {}
        except Exception as _efe:
            print(f"[流程语音] 加载 {EXTRA_FLOW_TEXT_FILE} 失败: {_efe}")
        # 基于用户标注自动计算 wave_id -> 台词索引 偏移量并注入匹配器
        try:
            self._build_wave_offsets_from_notes()
        except Exception as e:
            print(f"[偏移量构建] 异常: {e}")
        # 上次导入来源（用于重启后自动恢复会话）
        self.last_import = None
        # 手动分类覆盖 {original_path: "voice"|"sfx"}，试听后用户手动修正的分类
        self.class_overrides = {}
        self._load_class_overrides()
        # 音效重复检测/折叠状态
        self.sfx_hash_ready = False          # 哈希是否已计算
        self.sfx_dup_groups = {}             # {hash: [tracks]}，仅含重复(>1)组
        self.sfx_collapsed = set()           # 处于折叠态的 hash 集合
        self.sfx_dedup_enabled = True        # 是否启用重复折叠
        self._display_rows = []              # 显示行映射 [(kind, hash_or_None, track)]，与Listbox行一一对应

        # 处理器
        self.adx = ADXProcessor(self.tools_dir.get())
        self.awb = AWBExtractor(self.tools_dir.get())
        self.cpk = CPKExtractor(self.tools_dir.get())

        # 初始化 pygame mixer
        if HAS_PYGAME:
            try:
                pygame.mixer.init()
            except Exception:
                pass

        # 加载配置
        self.load_config()
        # 加载替换记录
        self.load_replacements()

        # 构建 UI
        self._build_menu()
        self._build_ui()
        self._update_status("就绪。请通过 文件菜单 导入 BGM.AWB 或 ADX 文件夹。")

        # 检查工具
        self.root.after(500, self._check_tools_async)

        # AI 模型后台预加载（后台线程预热，首次点击识别时零等待）
        # 延迟启动，避免与工具检查/会话恢复抢资源；本地模型存在时才预热
        self.root.after(1200, self._preload_ai_model_async)

        # 自动恢复上次会话（延迟到 UI 构建完成后）
        if getattr(self, "last_import", None):
            self.root.after(800, self.restore_last_session)
        # 初始化替换面板可见性（BGM 默认隐藏对齐勾选项）
        self._update_replace_panel_visibility()

    # ==================== 配置 ====================

    def load_config(self):
        """加载配置"""
        try:
            if os.path.exists(CONFIG_FILE):
                with open(CONFIG_FILE, 'r', encoding='utf-8') as f:
                    cfg = json.load(f)
                    self.tools_dir.set(cfg.get("tools_dir", "tools"))
                    self.adx = ADXProcessor(self.tools_dir.get())
                    self.awb = AWBExtractor(self.tools_dir.get())
                    self.cpk = CPKExtractor(self.tools_dir.get())
                    # 加载上次导入来源（用于会话恢复）
                    self.last_import = cfg.get("last_import")
        except Exception:
            pass

    def save_config(self):
        """保存配置"""
        try:
            cfg = {
                "tools_dir": self.tools_dir.get(),
                "last_import": getattr(self, "last_import", None),
            }
            with open(CONFIG_FILE, 'w', encoding='utf-8') as f:
                json.dump(cfg, f, ensure_ascii=False, indent=2)
        except Exception:
            pass

    def _load_class_overrides(self):
        """加载手动分类覆盖记录"""
        try:
            p = "class_overrides.json"
            if os.path.exists(p):
                with open(p, 'r', encoding='utf-8') as f:
                    self.class_overrides = json.load(f)
        except Exception:
            self.class_overrides = {}

    def _save_class_overrides(self):
        """保存手动分类覆盖记录"""
        try:
            with open("class_overrides.json", 'w', encoding='utf-8') as f:
                json.dump(self.class_overrides, f, ensure_ascii=False, indent=2)
        except Exception:
            pass

    def toggle_track_class(self):
        """切换当前选中曲目的分类（音效<->语音），手动修正误分类"""
        t = self.current_track
        if not t:
            return
        orig_path = t.get("original_path", "")
        if not orig_path:
            return
        cur_type = t.get("type", "bgm")
        if cur_type == "bgm":
            messagebox.showinfo("提示", "BGM 类型不支持手动切换分类。")
            return
        new_type = "voice" if cur_type == "sfx" else "sfx"
        src_list = self.sfx_tracks if cur_type == "sfx" else self.voice_tracks
        dst_list = self.voice_tracks if new_type == "voice" else self.sfx_tracks
        if t in src_list:
            src_list.remove(t)
        t["type"] = new_type
        if t not in dst_list:
            dst_list.append(t)
        self.class_overrides[orig_path] = new_type
        self._save_class_overrides()
        # 若移入音效，即时计算该 track 的哈希并重建分组
        if new_type == "sfx":
            import hashlib
            p = t.get("original_path") or t.get("path")
            if p and os.path.exists(p):
                try:
                    h = hashlib.sha256()
                    with open(p, 'rb') as f:
                        for chunk in iter(lambda: f.read(65536), b''):
                            h.update(chunk)
                    t["dup_hash"] = h.hexdigest()
                except Exception:
                    t["dup_hash"] = None
            self.sfx_hash_ready = True
            self._build_sfx_groups_and_refresh()
        else:
            self.refresh_track_list()
            self._update_audio_tabs()
        target_name = "角色语音" if new_type == "voice" else "音效"
        self._update_status(f"已将「{t.get('name','')}」移到{target_name}列表（手动标记已保存）")

    def _save_last_import(self, import_type: str, path: str):
        """保存上次导入的来源（供下次启动自动恢复）"""
        self.last_import = {"type": import_type, "path": path}
        self.save_config()

    def restore_last_session(self):
        """重启后自动恢复上次的导入和替换"""
        last = getattr(self, "last_import", None)
        if not last:
            return
        import_type = last.get("type")
        path = last.get("path")
        if not path or not os.path.exists(path):
            return

        self._update_status(f"正在恢复上次会话: {path}")

        def do_restore():
            try:
                if import_type == "awb":
                    # 重新解包 AWB 到持久化目录
                    output_dir = Path("extracted_bgm")
                    if output_dir.exists():
                        import shutil
                        shutil.rmtree(output_dir)
                    output_dir.mkdir(parents=True, exist_ok=True)
                    tracks = self.awb.extract_awb(path, str(output_dir))
                    self.tracks = [{**t, "replaced": False, "replaced_path": None,
                                    "original_path": t["path"], "awb_stem": Path(path).stem,
                                    "real_index": t["wave_id"]} for t in tracks]
                    self.bgm_tracks = self.tracks
                    self.sfx_tracks = []
                    self.voice_tracks = []
                    self.current_audio_type = "bgm"
                    self.root.after(0, lambda: self._after_import(tracks))
                    self.root.after(0, lambda: self._update_status(
                        f"已自动恢复上次会话: {len(tracks)} 首曲目，{len(self.replacements)} 首替换"))
                elif import_type == "adx_folder":
                    tracks = self.awb.scan_adx_folder(path)
                    self.tracks = [{**t, "replaced": False, "replaced_path": None,
                                    "original_path": t["path"], "awb_stem": "BGM",
                                    "real_index": t["wave_id"]} for t in tracks]
                    self.bgm_tracks = self.tracks
                    self.sfx_tracks = []
                    self.voice_tracks = []
                    self.current_audio_type = "bgm"
                    self.root.after(0, lambda: self._after_import(tracks))
                    self.root.after(0, lambda: self._update_status(
                        f"已自动恢复上次会话: {len(tracks)} 首曲目，{len(self.replacements)} 首替换"))
                elif import_type == "cpk_folder":
                    # 重新从 BASE.CPK 解包（包括主BGM和额外BGM）
                    self.root.after(0, lambda: self.import_cpk_folder(folder_path=path))
                else:
                    return
            except Exception as e:
                self.root.after(0, lambda msg=str(e): self._update_status(f"自动恢复失败: {msg}"))

        threading.Thread(target=do_restore, daemon=True).start()

    # ==================== 替换记录持久化 ====================

    def save_replacements(self):
        """保存替换记录到磁盘（JSON）"""
        try:
            with open(REPLACEMENTS_FILE, 'w', encoding='utf-8') as f:
                json.dump(self.replacements, f, ensure_ascii=False, indent=2)
        except Exception as e:
            self._update_status(f"保存替换记录失败: {e}")

    def load_replacements(self):
        """加载替换记录，并验证替换文件是否存在"""
        try:
            if os.path.exists(REPLACEMENTS_FILE):
                with open(REPLACEMENTS_FILE, 'r', encoding='utf-8') as f:
                    loaded = json.load(f)
                # 过滤掉文件不存在的记录
                self.replacements = {}
                for wid_str, info in loaded.items():
                    replaced_file = info.get("replaced_file", "")
                    if os.path.exists(replaced_file):
                        self.replacements[int(wid_str)] = info
                    else:
                        # 尝试在 replaced 目录中查找
                        alt_path = self._replaced_dir / f"{int(wid_str)}.adx"
                        if alt_path.exists():
                            info["replaced_file"] = str(alt_path)
                            self.replacements[int(wid_str)] = info
        except Exception:
            self.replacements = {}

    def apply_replacements_to_tracks(self, refresh=True):
        """将已保存的替换记录应用到当前曲目列表（导入后调用）
        refresh: 是否自动刷新列表（默认为 True；批量导入时由调用方统一刷新一次）"""
        if not self.replacements:
            return
        # 磁盘 IO 缓存：同一替换文件只 stat 一次（避免大量 track 重复调用 exists/getsize）
        _exists_cache = {}
        _size_cache = {}

        def _exists(p):
            if p not in _exists_cache:
                _exists_cache[p] = os.path.exists(p)
            return _exists_cache[p]

        def _getsize(p):
            if p not in _size_cache:
                _size_cache[p] = os.path.getsize(p) if _exists(p) else 0
            return _size_cache[p]

        for tr in self.tracks:
            try:
                wid = tr["wave_id"]
                if wid in self.replacements:
                    info = self.replacements[wid]
                    # 用来源 AWB 归档名匹配，避免 BGM 替换记录误用到同 wave_id 的语音/音效
                    rec_awb = info.get("awb_stem", "BGM")
                    cur_awb = tr.get("awb_stem", "BGM")
                    if rec_awb != cur_awb:
                        continue
                    replaced_file = info.get("replaced_file", "")
                    if _exists(replaced_file):
                        tr["replaced"] = True
                        tr["replaced_path"] = replaced_file
                        tr["replaced_name"] = info.get("replaced_name", "") or Path(info.get("source_file", "")).stem
                        tr["path"] = replaced_file
                        tr["size"] = _getsize(replaced_file)
            except Exception:
                continue
        if refresh:
            self.refresh_track_list()

    # ==================== UI 构建 ====================

    def _build_menu(self):
        """构建菜单栏"""
        # 使用中文字体渲染菜单，避免中文长文本被截断显示省略号
        menu_font = ("Microsoft YaHei", 9)
        menubar = Menu(self.root, font=menu_font)

        # 文件菜单
        file_menu = Menu(menubar, tearoff=0, font=menu_font)
        file_menu.add_command(label="导入 BASE.CPK 所在的文件夹...", command=self.import_cpk_folder, accelerator="Ctrl+I")
        file_menu.add_command(label="导入 BGM.AWB...", command=self.import_awb, accelerator="Ctrl+O")
        file_menu.add_command(label="导入 ADX 文件夹...", command=self.import_adx_folder)
        file_menu.add_separator()
        file_menu.add_command(label="导出 Mod...", command=self.export_mod, accelerator="Ctrl+E")
        file_menu.add_separator()
        file_menu.add_command(label="查看替换记录...", command=self.show_replacements)
        file_menu.add_command(label="清空全部替换", command=self.clear_all_replacements)
        file_menu.add_separator()
        file_menu.add_command(label="退出", command=self.root.quit, accelerator="Ctrl+Q")
        menubar.add_cascade(label="文件", menu=file_menu)

        # 工具菜单
        tools_menu = Menu(menubar, tearoff=0, font=menu_font)
        tools_menu.add_command(label="设置工具目录...", command=self.set_tools_dir)
        tools_menu.add_command(label="检查工具", command=self._check_tools_async)
        tools_menu.add_command(label="工具完整性管理", command=self._tools_integrity)
        tools_menu.add_separator()
        tools_menu.add_command(label="编辑曲名数据库...", command=self.edit_bgm_names)
        tools_menu.add_command(label="刷新曲目列表", command=self.refresh_track_list)
        menubar.add_cascade(label="工具", menu=tools_menu)

        # 帮助菜单
        help_menu = Menu(menubar, tearoff=0, font=menu_font)
        help_menu.add_command(label="使用说明", command=self.show_help)
        help_menu.add_command(label="实机语音字幕研究报告", command=self.show_voice_text_research)
        help_menu.add_command(label="AI识别翻译研究报告", command=self.show_ai_research)
        help_menu.add_command(label="音效替换调查报告", command=self.show_sfx_replace_research)
        help_menu.add_command(label="关于", command=self.show_about)
        menubar.add_cascade(label="帮助", menu=help_menu)

        # 作者（点击直接弹出作者信息窗口）
        menubar.add_command(label="作者", command=self.show_author_info)

        # 魔罗（点击弹出魔罗图片展示窗口）
        menubar.add_command(label="魔罗", command=self.show_moro)

        self.root.config(menu=menubar)

        # 快捷键
        self.root.bind('<Control-i>', lambda e: self.import_cpk_folder())
        self.root.bind('<Control-o>', lambda e: self.import_awb())
        self.root.bind('<Control-e>', lambda e: self.export_mod())
        self.root.bind('<Control-q>', lambda e: self.root.quit())

    def _build_ui(self):
        """构建主界面"""
        # 顶部工具栏
        toolbar = Frame(self.root, height=40, relief=RIDGE, bd=1)
        toolbar.pack(side=TOP, fill=X, padx=2, pady=2)

        Label(toolbar, text="搜索:").pack(side=LEFT, padx=(10, 2))
        search_entry = Entry(toolbar, textvariable=self.search_var, width=25)
        search_entry.pack(side=LEFT, padx=2)
        search_entry.bind('<KeyRelease>', lambda e: self.refresh_track_list())

        Label(toolbar, text="分类:").pack(side=LEFT, padx=(15, 2))
        categories = ["全部"] + list(BGM_CATEGORIES.keys()) + ["已替换", "未知"]
        category_combo = ttk.Combobox(toolbar, textvariable=self.category_var,
                                        values=categories, width=12, state="readonly")
        category_combo.pack(side=LEFT, padx=2)
        category_combo.bind('<<ComboboxSelected>>', lambda e: self.refresh_track_list())

        Button(toolbar, text="导入BASE.CPK", command=self.import_cpk_folder, width=12).pack(side=RIGHT, padx=5)
        Button(toolbar, text="导入 AWB", command=self.import_awb, width=10).pack(side=RIGHT, padx=5)
        Button(toolbar, text="导出 Mod", command=self.export_mod, width=10).pack(side=RIGHT, padx=5)

        # 主内容区
        main_frame = Frame(self.root)
        main_frame.pack(side=TOP, fill=BOTH, expand=True, padx=2, pady=2)

        # 左侧：曲目列表
        left_frame = Frame(main_frame, width=450)
        left_frame.pack(side=LEFT, fill=BOTH, expand=True, padx=(0, 2))

        # 列表标题
        list_header = Frame(left_frame, relief=RIDGE, bd=1)
        list_header.pack(side=TOP, fill=X)
        Label(list_header, text="ID", width=8, anchor=W, font=("Arial", 9, "bold")).pack(side=LEFT, padx=5)
        Label(list_header, text="曲名", width=30, anchor=W, font=("Arial", 9, "bold")).pack(side=LEFT, padx=5)
        Label(list_header, text="状态", width=8, anchor=W, font=("Arial", 9, "bold")).pack(side=LEFT, padx=5)

        # 颜色图例说明
        legend_frame = Frame(left_frame, relief=RIDGE, bd=1, bg="#F5F5F5")
        legend_frame.pack(side=TOP, fill=X)
        Label(legend_frame, text="■", fg="black", bg="#F5F5F5", font=("Arial", 10, "bold")).pack(side=LEFT, padx=(8, 1))
        Label(legend_frame, text="主BGM", bg="#F5F5F5", font=("Arial", 8)).pack(side=LEFT, padx=(0, 10))
        Label(legend_frame, text="■", fg="#E65100", bg="#F5F5F5", font=("Arial", 10, "bold")).pack(side=LEFT, padx=(2, 1))
        Label(legend_frame, text="额外BGM", bg="#F5F5F5", font=("Arial", 8)).pack(side=LEFT, padx=(0, 10))
        Label(legend_frame, text="■", fg="#7B1FA2", bg="#F5F5F5", font=("Arial", 10, "bold")).pack(side=LEFT, padx=(2, 1))
        Label(legend_frame, text="角色语音", bg="#F5F5F5", font=("Arial", 8)).pack(side=LEFT, padx=(0, 10))
        Label(legend_frame, text="■", fg="#2E7D32", bg="#F5F5F5", font=("Arial", 10, "bold")).pack(side=LEFT, padx=(2, 1))
        Label(legend_frame, text="已替换", bg="#F5F5F5", font=("Arial", 8)).pack(side=LEFT, padx=(0, 8))

        # BGM/音效/角色语音 选项卡
        tab_frame = Frame(left_frame, relief=RIDGE, bd=1)
        tab_frame.pack(side=TOP, fill=X)
        self.bgm_tab_btn = Button(tab_frame, text="🎵 BGM", command=lambda: self.switch_audio_type("bgm"),
                                   width=10, font=("Arial", 9, "bold"), relief=SUNKEN, bg="#4CAF50", fg="white")
        self.bgm_tab_btn.pack(side=LEFT, padx=2, pady=2)
        self.sfx_tab_btn = Button(tab_frame, text="🔊 音效", command=lambda: self.switch_audio_type("sfx"),
                                   width=10, font=("Arial", 9, "bold"), relief=RAISED, bg="#E0E0E0", fg="black")
        self.sfx_tab_btn.pack(side=LEFT, padx=2, pady=2)
        # 音效重复折叠按钮（点击切换全部折叠/展开）
        self.sfx_dedup_btn = Button(tab_frame, text="⤵ 折叠重复", command=self._toggle_sfx_dedup,
                                     width=10, font=("Arial", 8), relief=RAISED)
        self.sfx_dedup_btn.pack(side=LEFT, padx=2, pady=2)
        self.voice_tab_btn = Button(tab_frame, text="🎤 角色语音", command=lambda: self.switch_audio_type("voice"),
                                     width=12, font=("Arial", 9, "bold"), relief=RAISED, bg="#E0E0E0", fg="black")
        self.voice_tab_btn.pack(side=LEFT, padx=2, pady=2)
        # 角色语音筛选下拉菜单（默认隐藏，切换到角色语音 tab 时显示）
        self.voice_filter_combo = ttk.Combobox(
            tab_frame, textvariable=self.voice_filter_var, width=22,
            values=["全部角色", "Joker (BP01)", "Skull (BP02)", "Mona (BP03)",
                    "Panther (BP04)", "Fox (BP05)", "Queen (BP06)", "Noire (BP07)",
                    "Crow - Robin Hood (BP08)", "Crow - Loki (BP09)", "Violet (BP10)",
                    "其他语音 (VOICE_*)"],
            state="readonly", font=("Arial", 9))
        self.voice_filter_combo.bind("<<ComboboxSelected>>", lambda e: self.refresh_track_list())
        self.tab_info_label = Label(tab_frame, text="", font=("Arial", 8), fg="gray")
        self.tab_info_label.pack(side=RIGHT, padx=8)
        # 音效空槽位显示切换（默认隐藏，仅在音效 tab 可见）
        self.show_placeholder_var = BooleanVar(value=False)
        self.show_placeholder_check = Checkbutton(
            tab_frame, text="显示空槽位", variable=self.show_placeholder_var,
            font=("Arial", 8), command=self._toggle_placeholder)
        # 默认不显示，切换到音效 tab 时再 pack

        # 列表
        list_frame = Frame(left_frame)
        list_frame.pack(side=TOP, fill=BOTH, expand=True)

        scrollbar = Scrollbar(list_frame)
        scrollbar.pack(side=RIGHT, fill=Y)

        h_scrollbar = Scrollbar(list_frame, orient=HORIZONTAL)
        h_scrollbar.pack(side=BOTTOM, fill=X)

        self.track_listbox = Listbox(list_frame, yscrollcommand=scrollbar.set,
                                       xscrollcommand=h_scrollbar.set,
                                       font=("Consolas", 10), selectmode="single")
        self.track_listbox.pack(side=LEFT, fill=BOTH, expand=True)
        scrollbar.config(command=self.track_listbox.yview)
        h_scrollbar.config(command=self.track_listbox.xview)
        self.track_listbox.bind('<<ListboxSelect>>', self.on_track_select)
        self.track_listbox.bind('<Button-1>', self.on_track_click)
        self.track_listbox.bind('<Double-Button-1>', lambda e: self.play_preview())

        # 右侧：详情和操作（可滚动，内容多时鼠标滚轮上下翻）
        right_frame = Frame(main_frame, width=500)
        right_frame.pack(side=RIGHT, fill=BOTH, expand=True, padx=(2, 0))

        right_canvas = Canvas(right_frame, highlightthickness=0, bd=0)
        right_scroll = Scrollbar(right_frame, orient="vertical", command=right_canvas.yview)
        right_inner = Frame(right_canvas)
        right_inner.bind("<Configure>",
                         lambda e: right_canvas.configure(scrollregion=right_canvas.bbox("all")))
        _inner_win = right_canvas.create_window((0, 0), window=right_inner, anchor="nw")
        right_canvas.configure(yscrollcommand=right_scroll.set)
        right_canvas.bind("<Configure>",
                          lambda e: right_canvas.itemconfigure(_inner_win, width=e.width))
        right_canvas.pack(side=LEFT, fill=BOTH, expand=True)
        right_scroll.pack(side=RIGHT, fill=Y)

        def _right_mousewheel(event):
            right_canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")
        right_canvas.bind("<MouseWheel>", _right_mousewheel)
        right_inner.bind("<MouseWheel>", _right_mousewheel)

        # 曲目详情
        detail_frame = LabelFrame(right_inner, text="曲目详情", padx=10, pady=10)
        detail_frame.pack(side=TOP, fill=X, padx=5, pady=5)

        self.detail_id = StringVar(value="-")
        self.detail_name = StringVar(value="-")
        self.detail_size = StringVar(value="-")
        self.detail_encrypted = StringVar(value="-")
        self.detail_duration = StringVar(value="-")
        self.detail_replaced_name = StringVar(value="-")
        self.detail_path = StringVar(value="-")

        details = [
            ("Wave ID:", self.detail_id),
            ("曲名:", self.detail_name),
            ("替换为:", self.detail_replaced_name),
            ("文件大小:", self.detail_size),
            ("加密状态:", self.detail_encrypted),
            ("时长:", self.detail_duration),
            ("文件路径:", self.detail_path),
        ]
        for i, (label, var) in enumerate(details):
            Label(detail_frame, text=label, width=10, anchor=W, font=("Arial", 9, "bold")).grid(row=i, column=0, sticky=W, pady=2)
            Label(detail_frame, textvariable=var, anchor=W, wraplength=350, justify=LEFT).grid(row=i, column=1, sticky=W, pady=2)

        # 手动切换分类按钮（试听后修正误分类）
        class_btn_row = Frame(detail_frame)
        class_btn_row.grid(row=len(details), column=0, columnspan=2, sticky=W, pady=(4, 0))
        self.toggle_class_btn = Button(class_btn_row, text="切换为语音/音效", command=self.toggle_track_class,
                                       width=18, font=("Arial", 8), bg="#FFC107", fg="black", state=DISABLED)
        self.toggle_class_btn.pack(side=LEFT)
        Label(class_btn_row, text="试听后如分类错误，点此修正（自动保存）",
              fg="gray", font=("Arial", 8)).pack(side=LEFT, padx=5)

        # 编辑标注按钮行
        note_btn_row = Frame(detail_frame)
        note_btn_row.grid(row=len(details) + 1, column=0, columnspan=2, sticky=W, pady=(4, 0))
        self.edit_note_btn = Button(note_btn_row, text="编辑标注", command=self.edit_track_note,
                                    width=12, font=("Arial", 8), bg="#8E24AA", fg="white", state=DISABLED)
        self.edit_note_btn.pack(side=LEFT)
        Label(note_btn_row, text="给曲目添加说明（如语音内容）",
              fg="gray", font=("Arial", 8)).pack(side=LEFT, padx=5)

        # 中文台词显示区（角色语音：BMD 文本匹配 + AI 语音识别）
        text_frame = LabelFrame(detail_frame, text="中文台词 (SC.CPK)", padx=6, pady=4)
        text_frame.grid(row=len(details) + 2, column=0, columnspan=2, sticky=E+W, pady=(6, 0))
        self.text_matcher_var = StringVar(value="（选中角色语音后显示对应中文台词）")
        self.subtitle_text = Text(text_frame, height=8, width=44, font=("Microsoft YaHei", 9),
                                  wrap=WORD, relief=FLAT, bg=text_frame.cget("bg"), padx=2, pady=2)
        self.subtitle_text.pack(fill=X)
        self.subtitle_text.insert(END, "（选中角色语音后显示对应中文台词）")
        self.subtitle_text.config(state=DISABLED)

        # 试听控制
        preview_frame = LabelFrame(right_inner, text="试听预览", padx=10, pady=10)
        preview_frame.pack(side=TOP, fill=X, padx=5, pady=5)

        btn_frame = Frame(preview_frame)
        btn_frame.pack(side=TOP, fill=X)

        self.play_btn = Button(btn_frame, text="▶ 播放", command=self.toggle_play, width=10, state=DISABLED)
        self.play_btn.pack(side=LEFT, padx=5)
        self.stop_btn = Button(btn_frame, text="■ 重置", command=self.stop_preview, width=10, state=DISABLED)
        self.stop_btn.pack(side=LEFT, padx=5)
        # 极短音频循环播放5次选项（默认关闭）
        self.loop_short_audio_var = BooleanVar(value=False)
        Checkbutton(btn_frame, text="极短音频循环播放5次", variable=self.loop_short_audio_var,
                    font=("Arial", 9)).pack(side=LEFT, padx=(10, 0))

        # 进度条
        progress_container = Frame(preview_frame)
        progress_container.pack(side=TOP, fill=X, pady=(8, 2))

        self.progress_var = StringVar(value="00:00 / 00:00")
        self.time_label = Label(progress_container, textvariable=self.progress_var, font=("Arial", 9), fg="gray")
        self.time_label.pack(side=TOP, anchor=W)

        self.progress_scale = ttk.Scale(progress_container, from_=0, to=100, orient=HORIZONTAL,
                                          state=DISABLED)
        self.progress_scale.pack(side=TOP, fill=X, pady=(2, 0))
        self.progress_scale.bind("<ButtonPress-1>", self._on_progress_press)
        self.progress_scale.bind("<B1-Motion>", self._on_progress_motion)
        self.progress_scale.bind("<ButtonRelease-1>", self._on_progress_release)

        self.preview_status = StringVar(value="未播放")
        Label(preview_frame, textvariable=self.preview_status, fg="gray").pack(side=TOP, pady=(5, 0))

        # 替换操作
        replace_frame = LabelFrame(right_inner, text="替换音乐", padx=10, pady=10)
        replace_frame.pack(side=TOP, fill=X, padx=5, pady=5)
        self.replace_frame = replace_frame

        self.replace_file_var = StringVar(value="未选择文件")
        self.replace_file_label = Label(replace_frame, textvariable=self.replace_file_var, wraplength=400, fg="blue")
        self.replace_file_label.pack(side=TOP, anchor=W, pady=2)

        # 时长对比标签（选择文件后显示原版 vs 新文件时长，提醒等长要求）
        self.replace_dur_label = Label(replace_frame, text="选择音频文件后将显示时长对比（音效建议等长；语音Ryo下可超长，完整播放）", fg="gray")
        self.replace_dur_label.pack(side=TOP, anchor=W, pady=1)

        btn_row = Frame(replace_frame)
        btn_row.pack(side=TOP, fill=X, pady=5)
        self.replace_btn_row = btn_row

        Button(btn_row, text="选择音乐文件...", command=self.select_replace_file, width=15).pack(side=LEFT, padx=5)
        self.replace_btn = Button(btn_row, text="执行替换", command=self.do_replace, width=12,
                                   bg="#4CAF50", fg="white", state=DISABLED)
        self.replace_btn.pack(side=LEFT, padx=5)
        self.restore_btn = Button(btn_row, text="恢复原始", command=self.restore_track, width=12,
                                    bg="#f44336", fg="white", state=DISABLED)
        self.restore_btn.pack(side=LEFT, padx=5)

        # 高级选项：循环点 + 音量增益
        adv_frame = LabelFrame(replace_frame, text="高级选项（可选）", padx=8, pady=6)
        adv_frame.pack(side=TOP, fill=X, pady=(2, 5))
        self.adv_frame = adv_frame

        # 循环点行
        loop_row = Frame(adv_frame)
        loop_row.pack(side=TOP, fill=X, pady=2)
        Label(loop_row, text="循环起点:", font=("Arial", 9)).pack(side=LEFT, padx=(0, 3))
        self.loop_start_var = StringVar(value="0")
        Entry(loop_row, textvariable=self.loop_start_var, width=10).pack(side=LEFT, padx=(0, 8))
        Label(loop_row, text="循环终点:", font=("Arial", 9)).pack(side=LEFT, padx=(0, 3))
        self.loop_end_var = StringVar(value="-1")
        Entry(loop_row, textvariable=self.loop_end_var, width=10).pack(side=LEFT, padx=(0, 8))
        Label(loop_row, text="样本数（-1=末尾）", fg="gray", font=("Arial", 8)).pack(side=LEFT)

        # 音量增益行
        vol_row = Frame(adv_frame)
        vol_row.pack(side=TOP, fill=X, pady=2)
        Label(vol_row, text="音量增益:", font=("Arial", 9)).pack(side=LEFT, padx=(0, 3))
        self.volume_gain_var = StringVar(value="1.0")
        Entry(vol_row, textvariable=self.volume_gain_var, width=8).pack(side=LEFT, padx=(0, 8))
        Label(vol_row, text="倍（1.0=原音量，P5R播放偏安静建议1.5~2.5）", fg="gray", font=("Arial", 8)).pack(side=LEFT)

        # 对齐勾选项子 frame（BGM 时隐藏，音效/语音显示；循环点+音量增益始终保留）
        self.adv_align_frame = Frame(adv_frame)
        self.adv_align_frame.pack(side=TOP, fill=X)

        # 替换选项：等长匹配 + 响度匹配（保证游戏内正常播放）
        opt_row = Frame(self.adv_align_frame)
        opt_row.pack(side=TOP, fill=X, pady=2)
        self.match_length_var = BooleanVar(value=True)
        self.match_level_var = BooleanVar(value=True)
        Checkbutton(opt_row, text="等长匹配原版（音效默认开，防止无声/偏移；语音Ryo下可关，超长完整播放）",
                    variable=self.match_length_var, font=("Arial", 9),
                    command=self._refresh_replace_duration_hint).pack(side=LEFT, padx=(0, 12))
        Checkbutton(opt_row, text="响度匹配原版（防止游戏内爆音）",
                    variable=self.match_level_var, font=("Arial", 9)).pack(side=LEFT)
        # 频谱对齐（单独一行，避免过长）
        spec_row = Frame(self.adv_align_frame)
        spec_row.pack(side=TOP, fill=X, pady=(0, 2))
        self.match_spectrum_var = BooleanVar(value=True)
        Checkbutton(spec_row, text="频谱对齐原版（自动整形频段能量分布到原版轮廓，防止低频轰头/炸）",
                    variable=self.match_spectrum_var, font=("Arial", 9)).pack(side=LEFT)
        # 进阶对齐（每行2个，避免文字截断）
        adv_row1 = Frame(self.adv_align_frame)
        adv_row1.pack(side=TOP, fill=X, pady=(0, 2))
        self.match_bandwidth_var = BooleanVar(value=True)
        self.match_noisefloor_var = BooleanVar(value=True)
        Checkbutton(adv_row1, text="带宽对齐（限幅到原版频段范围）",
                    variable=self.match_bandwidth_var, font=("Arial", 9)).pack(side=LEFT, padx=(0, 16))
        Checkbutton(adv_row1, text="底噪对齐（压掉过高底噪）",
                    variable=self.match_noisefloor_var, font=("Arial", 9)).pack(side=LEFT)
        adv_row2 = Frame(self.adv_align_frame)
        adv_row2.pack(side=TOP, fill=X, pady=(0, 2))
        self.match_stereo_var = BooleanVar(value=True)
        self.match_envelope_var = BooleanVar(value=True)
        Checkbutton(adv_row2, text="立体声宽度（声场对齐原版）",
                    variable=self.match_stereo_var, font=("Arial", 9)).pack(side=LEFT, padx=(0, 16))
        Checkbutton(adv_row2, text="包络对齐（attack形状贴原版）",
                    variable=self.match_envelope_var, font=("Arial", 9)).pack(side=LEFT)
        adv_row3 = Frame(self.adv_align_frame)
        adv_row3.pack(side=TOP, fill=X, pady=(0, 2))
        self.match_lufs_var = BooleanVar(value=True)
        self.match_dynamics_var = BooleanVar(value=True)
        Checkbutton(adv_row3, text="感知响度LUFS（人耳等响度）",
                    variable=self.match_lufs_var, font=("Arial", 9)).pack(side=LEFT, padx=(0, 16))
        Checkbutton(adv_row3, text="动态限幅（压瞬态过冲兜底）",
                    variable=self.match_dynamics_var, font=("Arial", 9)).pack(side=LEFT)

        # Ryo Framework 播放层控音量（彻底解决游戏内音量被自动放大）
        ryo_row = Frame(self.adv_align_frame)
        ryo_row.pack(side=TOP, fill=X, pady=(0, 2))
        self.ryo_export_var = BooleanVar(value=True)
        self.ryo_volume_var = StringVar(value="0.5")
        Checkbutton(ryo_row, text="Ryo播放层控音量（防游戏自动放大，需装Ryo Framework）",
                    variable=self.ryo_export_var, font=("Arial", 9)).pack(side=LEFT, padx=(0, 12))
        Label(ryo_row, text="音量:", font=("Arial", 9)).pack(side=LEFT, padx=(0, 3))
        Entry(ryo_row, textvariable=self.ryo_volume_var, width=6).pack(side=LEFT, padx=(0, 4))
        Label(ryo_row, text="（0.5=原版一半）", fg="gray", font=("Arial", 8)).pack(side=LEFT)

        # 批量替换范围（可选）：一次替换多个 wave，并自动补齐所有对应 Ryo Cue
        batch_row = Frame(self.adv_align_frame)
        batch_row.pack(side=TOP, fill=X, pady=(0, 2))
        self.batch_range_var = StringVar(value="")
        Label(batch_row, text="批量替换范围:", font=("Arial", 9)).pack(side=LEFT, padx=(0, 6))
        Entry(batch_row, textvariable=self.batch_range_var, width=14).pack(side=LEFT, padx=(0, 6))
        Label(batch_row, text="如 232000-232003；留空=仅当前曲目（自动补齐全部Cue）",
              fg="gray", font=("Arial", 8)).pack(side=LEFT)

        # 重置高级选项按钮
        adv_btn_row = Frame(self.adv_align_frame)
        adv_btn_row.pack(side=TOP, fill=X, pady=(4, 0))
        Button(adv_btn_row, text="重置为默认", command=self._reset_adv_options,
               width=12, font=("Arial", 8)).pack(side=LEFT, padx=(0, 8))
        Label(adv_btn_row, text="提示：循环点用样本数表示，44100Hz下1秒=44100样本",
              fg="gray", font=("Arial", 8)).pack(side=LEFT)

        # 导出原曲 WAV 按钮行
        export_row = Frame(replace_frame)
        export_row.pack(side=TOP, fill=X, pady=(2, 5))
        self.export_row = export_row
        self.export_wav_btn = Button(export_row, text="导出原曲 WAV", command=self.export_original_wav,
                                      width=15, bg="#5DADE2", fg="white")
        self.export_wav_btn.pack(side=LEFT, padx=5)
        Label(export_row, text="将当前选中的原曲导出为 WAV（解密后保存到自定义文件夹）",
              fg="gray", font=("Arial", 8)).pack(side=LEFT, padx=5)

        # 替换说明
        help_text = ("支持格式: MP3, WAV, OGG, FLAC, M4A 等\n"
                     "流程: 自动转WAV -> ADX编码 -> P5R加密 -> 生成Mod文件\n"
                     "替换后可在列表中看到 [已替换] 标记")
        self.replace_help_label = Label(replace_frame, text=help_text, fg="gray", justify=LEFT, font=("Arial", 8))
        self.replace_help_label.pack(side=TOP, anchor=W, pady=5)

        # 底部状态栏
        status_bar = Frame(self.root, relief=SUNKEN, bd=1)
        status_bar.pack(side=BOTTOM, fill=X)
        Label(status_bar, textvariable=self.status_var, anchor=W).pack(side=LEFT, padx=10, pady=2)
        self.track_count_var = StringVar(value="曲目: 0")
        Label(status_bar, textvariable=self.track_count_var, anchor=E).pack(side=RIGHT, padx=10, pady=2)

    # ==================== 状态更新 ====================

    def _update_status(self, msg: str):
        self.status_var.set(msg)
        self.root.update_idletasks()

    def _tools_integrity(self):
        """工具完整性管理：校验 / 备份 / 恢复 tools 目录"""
        try:
            import protect_tools
        except ImportError:
            messagebox.showwarning("工具保护", "缺少 protect_tools.py（工具保护模块），请确认文件存在。")
            return

        # 后台执行校验，避免卡界面
        def do():
            try:
                result = protect_tools.verify_tools()
                report = result["report"]

                def ask():
                    if result["ok"]:
                        messagebox.showinfo("工具完整性", report + "\n\n已创建备份：tools_backup.zip")
                        return
                    ret = messagebox.askyesnocancel(
                        "工具完整性问题",
                        report + "\n\n是否从备份自动恢复缺失/损坏的工具？\n"
                        "（点“是”恢复缺失项，点“否”仅备份，点“取消”关闭）"
                    )
                    if ret is True:
                        try:
                            restore_msg = protect_tools.restore_missing()
                            # 恢复后再校验
                            r2 = protect_tools.verify_tools()
                            messagebox.showinfo(
                                "恢复结果",
                                restore_msg + "\n\n" + r2["report"]
                            )
                        except Exception as e:
                            messagebox.showerror("恢复失败", str(e))
                    elif ret is False:
                        # 备份当前（可能损坏的）状态到独立文件
                        try:
                            bak = protect_tools.backup_tools(
                                backup_path=str(Path(__file__).resolve().parent / "tools_backup_current.zip")
                            )
                            messagebox.showinfo("已备份", bak)
                        except Exception as e:
                            messagebox.showerror("备份失败", str(e))
                self.root.after(0, ask)
            except Exception as e:
                self.root.after(0, lambda: messagebox.showerror("工具完整性检查失败", str(e)))
        threading.Thread(target=do, daemon=True).start()

    def _check_tools_async(self):
        """异步检查工具"""
        def check():
            ok, msg = self.adx.check_tools()
            self.root.after(0, lambda: self._update_status(f"工具检查: {msg}"))
            if not ok:
                # 尝试从备份自动恢复缺失工具
                restore_msg = ""
                try:
                    import protect_tools
                    restore_msg = protect_tools.restore_missing()
                except Exception as e:
                    restore_msg = f"（自动恢复失败: {e}）"
                # 恢复后再查一次
                ok2, msg2 = self.adx.check_tools()
                if ok2:
                    self.root.after(0, lambda: self._update_status("工具检查: 已自动恢复缺失工具 ✓"))
                    return
                self.root.after(0, lambda: messagebox.showwarning(
                    "工具未就绪",
                    f"{msg}\n\n"
                    "已尝试自动恢复：\n"
                    f"{restore_msg}\n\n"
                    "如果仍未解决，请手动下载以下工具并放入 tools 目录:\n"
                    "1. adxencd.exe - CRI ADX 编码器（必需）\n"
                    "2. vgaudiocli.exe - ADX 加密/解密工具（必需）\n"
                    "3. CriFsV2Lib/ - CPK 解包 .NET 库（导入BASE.CPK所在文件夹时需要）\n"
                    "4. (可选) ffmpeg.exe - 音频格式转换\n\n"
                    "可通过 工具->设置工具目录 指定路径。\n"
                    "提示: 运行 protect_tools.py backup 可备份 tools 目录，损坏时可自动恢复。"
                ))
        threading.Thread(target=check, daemon=True).start()

    def _preload_ai_model_async(self):
        """后台预热 AI 识别模型，避免首次点击识别时长时间等待。

        仅当本地模型存在时预热；加载完成后更新状态栏提示。
        模型加载在后台线程进行，不阻塞界面。
        """
        def do():
            try:
                import voice_ai
                if not voice_ai.is_available():
                    return
                # 本地模型不存在则跳过（避免启动时触发网络下载）
                model_size = voice_ai.get_model_size()
                local_dir = getattr(voice_ai, "LOCAL_MODEL_DIRS", {}).get(model_size)
                if not (local_dir and local_dir.exists() and (local_dir / "model.bin").exists()):
                    return
                self.root.after(0, lambda: self._update_status(
                    f"AI 模型（{model_size}）后台预加载中...（不影响其他操作）"))
                voice_ai.preload_model()
                # 轮询等待预加载完成，然后更新状态
                def poll():
                    if voice_ai.is_preloaded():
                        err = voice_ai.preload_error()
                        if err:
                            self._update_status(f"AI 模型预加载完成（首次识别时自动加载）")
                        else:
                            self._update_status("AI 模型已就绪，识别无需等待")
                    else:
                        self.root.after(500, poll)
                poll()
            except Exception as e:
                print(f"[AI] 预加载启动失败: {e}")

        threading.Thread(target=do, daemon=True).start()

    # ==================== 导入 ====================

    def import_awb(self):
        """导入 BGM.AWB 文件"""
        filepath = filedialog.askopenfilename(
            title="选择 BGM.AWB 文件",
            filetypes=[("AWB 文件", "*.awb"), ("所有文件", "*.*")]
        )
        if not filepath:
            return

        self._update_status(f"正在解包 AWB: {filepath}")

        def do_extract():
            try:
                # 使用项目下的持久化提取目录（重启后文件保留，便于会话恢复）
                output_dir = Path("extracted_bgm")
                if output_dir.exists():
                    import shutil
                    shutil.rmtree(output_dir)
                output_dir.mkdir(parents=True, exist_ok=True)

                tracks = self.awb.extract_awb(filepath, str(output_dir))
                self.tracks = [{**t, "replaced": False, "replaced_path": None, "original_path": t["path"],
                                "awb_stem": Path(filepath).stem, "real_index": t["wave_id"]} for t in tracks]
                # 单个 AWB 导入默认归为 BGM 列表
                self.bgm_tracks = self.tracks
                self.sfx_tracks = []
                self.voice_tracks = []
                self.current_audio_type = "bgm"
                # 保存导入来源，供下次启动自动恢复
                self._save_last_import("awb", filepath)
                self.root.after(0, lambda: self._after_import(tracks))
            except Exception as e:
                err_msg = str(e)
                self.root.after(0, lambda msg=err_msg: self._import_error(msg))

        threading.Thread(target=do_extract, daemon=True).start()

    def import_adx_folder(self):
        """导入已解包的 ADX 文件夹"""
        folder = filedialog.askdirectory(title="选择包含 ADX 文件的文件夹")
        if not folder:
            return

        self._update_status(f"正在扫描 ADX 文件夹: {folder}")

        def do_scan():
            try:
                tracks = self.awb.scan_adx_folder(folder)
                self.tracks = [{**t, "replaced": False, "replaced_path": None, "original_path": t["path"],
                                "awb_stem": "BGM", "real_index": t["wave_id"]} for t in tracks]
                # ADX 文件夹导入默认归为 BGM 列表
                self.bgm_tracks = self.tracks
                self.sfx_tracks = []
                self.voice_tracks = []
                self.current_audio_type = "bgm"
                # 保存导入来源，供下次启动自动恢复
                self._save_last_import("adx_folder", folder)
                self.root.after(0, lambda: self._after_import(tracks))
            except Exception as e:
                err_msg = str(e)
                self.root.after(0, lambda msg=err_msg: self._import_error(msg))

        threading.Thread(target=do_scan, daemon=True).start()

    def import_voice(self):
        cpk_folder = filedialog.askdirectory(title="选择 BASE.CPK 所在的文件夹（如游戏的 CPK 目录）")
        if not cpk_folder:
            return

        base_cpk = find_base_cpk(cpk_folder)
        if not base_cpk:
            messagebox.showerror("未找到 BASE.CPK", f"在文件夹中未找到 BASE.CPK:\n{cpk_folder}")
            return

        self._update_status("正在扫描 CPK 中的 AWB 文件...")

        def do_list():
            try:
                awb_list = self.cpk.list_awb_files(base_cpk)
                # 只排除主 BGM.AWB（已由"导入BASE.CPK"功能处理），保留 BGM_01~BGM_16 等额外BGM
                voice_awbs = [a for a in awb_list if a.upper() != "BGM.AWB"]
                self.root.after(0, lambda: self._show_voice_awb_selector(base_cpk, voice_awbs))
            except Exception as e:
                err_msg = str(e)
                self.root.after(0, lambda msg=err_msg: self._import_error(msg))

        threading.Thread(target=do_list, daemon=True).start()

    def _show_voice_awb_selector(self, base_cpk: str, awb_list: list):
        """显示语音 AWB 选择对话框"""
        if not awb_list:
            messagebox.showinfo("提示", "在 BASE.CPK 中未找到语音 AWB 文件（已排除 BGM.AWB）")
            return

        sel_win = Toplevel(self.root)
        sel_win.title("选择语音 AWB")
        sel_win.geometry("420x520")
        sel_win.resizable(False, False)
        sel_win.transient(self.root)
        sel_win.grab_set()

        # 常见 AWB 的中文说明（排在前面，方便用户选择）
        VOICE_LABELS = {
            "TITLE.AWB": "标题界面音效",
            "SYSTEM.AWB": "系统音效/语音",
            "BP01.AWB": "战斗语音（主角+同伴）",
            "BP02.AWB": "战斗语音2",
            "BP03.AWB": "战斗语音3",
            "VOICE_SINGLEWORD.AWB": "单字语音（菜单/确认等，文件较大）",
            "VOICE_SINGLEWORD_EN.AWB": "单字语音（英文）",
        }

        def get_awb_label(name: str) -> str:
            """获取 AWB 的中文标注，动态识别额外BGM"""
            upper = name.upper()
            if upper in VOICE_LABELS:
                return VOICE_LABELS[upper]
            if upper.startswith("BGM_"):
                return "额外BGM（主导入功能未提取）"
            return ""

        def is_known_awb(name: str) -> bool:
            """判断是否为已知类型AWB（有标注的）"""
            return bool(get_awb_label(name))

        # 排序：已知AWB（含额外BGM）在前，其他在后；每组内按字母序
        known = sorted([a for a in awb_list if is_known_awb(a)])
        others = sorted([a for a in awb_list if not is_known_awb(a)])
        sorted_awbs = known + others

        Label(sel_win, text=f"共找到 {len(awb_list)} 个 AWB，选择要解包的文件：",
              font=("Microsoft YaHei", 10, "bold")).pack(pady=(12, 6))
        Label(sel_win, text="BGM_01~16 为额外BGM，主导入功能未提取，可在此解包预览",
              fg="#6A1B9A", font=("Microsoft YaHei", 8)).pack()
        Label(sel_win, text="E0xx_xxx_SE 为过场音效，通常只有1个极短片段(0.2秒)",
              fg="gray", font=("Arial", 8)).pack()
        Label(sel_win, text="E0xx_xxx（无_SE）为过场语音，片段较多可预览",
              fg="#1565C0", font=("Arial", 8)).pack()
        Label(sel_win, text="注：BP01/VOICE_SINGLEWORD 等战斗语音可能在 ps4R.cpk 中",
              fg="#E65100", font=("Microsoft YaHei", 8)).pack()

        list_frame = Frame(sel_win)
        list_frame.pack(fill=BOTH, expand=True, padx=12, pady=8)
        scrollbar = Scrollbar(list_frame)
        scrollbar.pack(side=RIGHT, fill=Y)
        lb = Listbox(list_frame, yscrollcommand=scrollbar.set, font=("Consolas", 10))
        lb.pack(side=LEFT, fill=BOTH, expand=True)
        scrollbar.config(command=lb.yview)
        for awb in sorted_awbs:
            label = get_awb_label(awb)
            display = f"{awb}  ← {label}" if label else awb
            lb.insert(END, display)
        if sorted_awbs:
            lb.selection_set(0)
            lb.activate(0)
            lb.see(0)

        def on_ok():
            sel = lb.curselection()
            if not sel:
                messagebox.showwarning("提示", "请选择一个 AWB 文件")
                return
            selected_awb = sorted_awbs[sel[0]]
            sel_win.destroy()
            self._extract_and_load_voice(base_cpk, selected_awb)

        btn_frame = Frame(sel_win)
        btn_frame.pack(pady=10)
        Button(btn_frame, text="解包并预览", command=on_ok, width=12,
               bg="#4CAF50", fg="white", font=("Microsoft YaHei", 10)).pack(side=LEFT, padx=5)
        Button(btn_frame, text="取消", command=sel_win.destroy, width=10).pack(side=LEFT, padx=5)

        sel_win.bind('<Escape>', lambda e: sel_win.destroy())
        sel_win.bind('<Double-Button-1>', lambda e: on_ok())

    def _extract_and_load_voice(self, base_cpk: str, awb_name: str):
        """从 CPK 提取语音 AWB（+对应 ACB），解包后加载到列表预览"""
        awb_stem = Path(awb_name).stem
        output_dir = Path("extracted_voice") / awb_stem
        if output_dir.exists():
            import shutil
            shutil.rmtree(output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)

        acb_name = awb_name[:-4] + ".ACB" if awb_name.upper().endswith(".AWB") else awb_name + ".ACB"
        targets = [awb_name, acb_name]

        self._update_status(f"正在提取 {awb_name}...")

        def do_extract():
            try:
                extracted = self.cpk.extract_files(base_cpk, str(output_dir), targets)
                awb_path = None
                for name, path in extracted.items():
                    if name.upper().endswith(".AWB"):
                        awb_path = path
                        break
                if not awb_path:
                    raise RuntimeError(f"未提取到 {awb_name}")

                tracks = self.awb.extract_awb(awb_path, str(output_dir))
                self.tracks = [{**t, "replaced": False, "replaced_path": None,
                                "original_path": t["path"], "awb_stem": awb_stem,
                                "real_index": t["wave_id"]} for t in tracks]
                self.root.after(0, lambda: self._after_voice_import(tracks, awb_name))
            except Exception as e:
                err_msg = str(e)
                self.root.after(0, lambda msg=err_msg: self._import_error(msg))

        threading.Thread(target=do_extract, daemon=True).start()

    def _after_voice_import(self, tracks: list, awb_name: str):
        """语音导入完成后刷新列表（按 awb_stem 应用对应的语音替换记录）"""
        # 语音列表归入 voice_tracks，并切换到角色语音 tab 显示
        self.voice_tracks = self.tracks
        self.current_audio_type = "voice"
        self.refresh_track_list()
        self._update_audio_tabs()
        self._update_replace_panel_visibility()
        # 按 awb_stem 匹配，恢复该语音 AWB 自己的替换记录
        self.apply_replacements_to_tracks()
        self.track_count_var.set(f"语音片段: {len(tracks)}")
        self._update_status(f"语音导入完成: {awb_name}, 共 {len(tracks)} 个片段，可点击播放试听")
        # 自动选中第一项并刷新详情面板
        if self.tracks:
            self.track_listbox.selection_clear(0, END)
            self.track_listbox.selection_set(0)
            self.track_listbox.activate(0)
            # 手动触发选中事件，刷新详情面板
            self.current_track = self.tracks[0]
            self._refresh_detail_panel()

    def import_cpk_folder(self, folder_path: str = ""):
        """导入 CPK 文件夹，自动解包 BASE.CPK 和 SOUND_J.CPK 中的音频文件（带真实进度条和预计时间）
        folder_path: 可选，直接指定文件夹路径（用于自动恢复），不弹出对话框
        """
        if folder_path and os.path.isdir(folder_path):
            cpk_folder = folder_path
        else:
            cpk_folder = filedialog.askdirectory(title="选择 BASE.CPK 所在的文件夹（如游戏的 CPK 目录）")
            if not cpk_folder:
                return

        # 查找 BASE.CPK
        base_cpk = find_base_cpk(cpk_folder)
        if not base_cpk:
            cpk_files = list_cpk_files(cpk_folder)
            if not cpk_files:
                messagebox.showerror("未找到 CPK", f"在文件夹中未找到任何 .CPK 文件:\n{cpk_folder}")
                return
            names = "\n".join(Path(f).name for f in cpk_files[:10])
            messagebox.showwarning(
                "未找到 BASE.CPK",
                f"未找到 BASE.CPK，但发现以下 CPK 文件:\n{names}\n\n"
                f"音乐文件通常在 BASE.CPK 中。请确认文件夹路径是否正确。"
            )
            return

        # 查找 SOUND_J.CPK（日文语音/音效包，包含系统音效和 non-streaming 短音效）
        sound_j_cpk = None
        for f in list_cpk_files(cpk_folder):
            if Path(f).name.upper() == "SOUND_J.CPK":
                sound_j_cpk = f
                break

        # 输出目录：在 CPK 文件夹下创建 extracted_bgm 子目录
        output_dir = str(Path(cpk_folder) / "extracted_bgm")

        # 统计文件夹内其他 CPK 数量（仅用于明确提示：只处理 BASE.CPK 和 SOUND_J.CPK）
        all_cpks = list(dict.fromkeys(list_cpk_files(cpk_folder)))  # 去重（Windows 大小写不敏感）
        processed_names = {"BASE.CPK", "SOUND_J.CPK"}
        other_cpks = [f for f in all_cpks if Path(f).name.upper() not in processed_names]

        # 取消事件
        cancel_event = threading.Event()
        start_time = time.time()

        # 显示进度窗口
        progress_win = Toplevel(self.root)
        progress_win.title("正在解包 CPK...")
        progress_win.geometry("560x310")
        progress_win.resizable(False, False)
        progress_win.transient(self.root)
        progress_win.grab_set()

        # 标题
        cpk_names = "BASE.CPK"
        if sound_j_cpk:
            cpk_names += " + SOUND_J.CPK"
        Label(progress_win, text=f"正在从 {cpk_names} 提取音频文件...",
              font=("Arial", 11, "bold")).pack(pady=(12, 4))
        Label(progress_win, text=f"CPK: {Path(base_cpk).name}", wraplength=520, fg="gray").pack()
        if sound_j_cpk:
            Label(progress_win, text=f"CPK: {Path(sound_j_cpk).name}（系统音效/短音效）",
                  wraplength=520, fg="gray").pack()
        Label(progress_win, text=f"输出: {output_dir}", wraplength=520, fg="gray").pack()
        # 明确提示：仅解包 BASE.CPK 和 SOUND_J.CPK，其他 CPK 不受影响
        if other_cpks:
            Label(progress_win,
                  text=f"仅解包 {cpk_names}（文件夹内另有 {len(other_cpks)} 个 CPK 不会被处理）",
                  wraplength=520, fg="#E67E22", font=("Arial", 9, "bold")).pack(pady=(4, 0))
        else:
            Label(progress_win, text=f"仅解包 {cpk_names}",
                  wraplength=520, fg="#E67E22", font=("Arial", 9, "bold")).pack(pady=(4, 0))

        # 进度信息行（百分比 + 阶段）
        info_frame = Frame(progress_win)
        info_frame.pack(fill=X, padx=20, pady=(8, 2))

        percent_var = StringVar(value="0%")
        phase_var = StringVar(value="准备中")
        Label(info_frame, textvariable=phase_var, anchor=W, fg="blue").pack(side=LEFT)
        Label(info_frame, textvariable=percent_var, anchor=E, font=("Arial", 10, "bold")).pack(side=RIGHT)

        # 进度条（确定模式）
        progress_bar = ttk.Progressbar(progress_win, mode='determinate', maximum=100, length=500)
        progress_bar.pack(pady=(2, 4), padx=20)

        # 时间信息行
        time_frame = Frame(progress_win)
        time_frame.pack(fill=X, padx=20, pady=(0, 4))

        elapsed_var = StringVar(value="已用时间: 00:00")
        eta_var = StringVar(value="预计剩余: --:--")
        Label(time_frame, textvariable=elapsed_var, anchor=W).pack(side=LEFT)
        Label(time_frame, textvariable=eta_var, anchor=E).pack(side=RIGHT)

        # 当前操作消息
        message_var = StringVar(value="准备中...")
        Label(progress_win, textvariable=message_var, wraplength=520, fg="gray",
              font=("Arial", 9)).pack(pady=(0, 4))

        # 取消按钮
        def on_cancel():
            cancel_event.set()
            self.cpk.cancel()
            message_var.set("正在取消...")
            cancel_btn.config(state=DISABLED, text="取消中...")

        cancel_btn = Button(progress_win, text="取消", command=on_cancel, width=12)
        cancel_btn.pack(pady=(4, 8))

        # 禁止通过关闭按钮取消（避免状态不一致）
        progress_win.protocol("WM_DELETE_WINDOW", on_cancel)

        self._update_status(f"正在解包 CPK: {base_cpk}")

        # 进度更新状态（用于 ETA 计算平滑）
        last_percent = [0]
        last_eta_time = [time.time()]
        smoothed_eta = [None]
        # 节流状态：记录"已提交"的百分比与消息，避免同一进度重复排队 after 回调
        _cb_submit_pct = [-1]
        _cb_submit_msg = [""]

        def progress_cb(percent, message, phase):
            """进度回调：更新进度条、百分比、时间信息（节流：重复进度跳过）"""
            if percent == _cb_submit_pct[0] and message == _cb_submit_msg[0]:
                return
            _cb_submit_pct[0] = percent
            if message:
                _cb_submit_msg[0] = message
            def update():
                # 更新进度条和百分比
                progress_bar['value'] = percent
                percent_var.set(f"{percent}%")

                # 更新阶段和消息
                phase_names = {
                    "init": "初始化",
                    "parse": "解析文件表",
                    "extract": "提取文件",
                    "cripaktools": "CriPakTools 解包",
                    "fallback": "回退到内置解析器",
                    "done": "完成",
                }
                phase_var.set(phase_names.get(phase, phase))
                if message:
                    message_var.set(message)

                # 计算已用时间
                elapsed = time.time() - start_time
                mins = int(elapsed // 60)
                secs = int(elapsed % 60)
                elapsed_var.set(f"已用时间: {mins:02d}:{secs:02d}")

                # 计算预计剩余时间（平滑处理）
                if percent > 2 and percent < 100:
                    raw_eta = elapsed * (100 - percent) / percent
                    # 平滑：加权平均
                    if smoothed_eta[0] is None:
                        smoothed_eta[0] = raw_eta
                    else:
                        smoothed_eta[0] = smoothed_eta[0] * 0.7 + raw_eta * 0.3
                    eta = smoothed_eta[0]
                    if eta > 0:
                        emins = int(eta // 60)
                        esecs = int(eta % 60)
                        eta_var.set(f"预计剩余: {emins:02d}:{esecs:02d}")
                    else:
                        eta_var.set("预计剩余: 即将完成")
                elif percent >= 100:
                    eta_var.set("预计剩余: 完成")
                else:
                    eta_var.set("预计剩余: 计算中...")

                last_percent[0] = percent

            self.root.after(0, update)

        def do_extract():
            try:
                # 解包 BASE.CPK
                extracted = self.cpk.extract_bgm(
                    base_cpk, output_dir, progress_cb, cancel_event
                )

                # 如果取消了，直接返回
                if cancel_event.is_set():
                    self.root.after(0, lambda: self._cpk_extract_cancelled(progress_win))
                    return

                # 解包 SOUND_J.CPK（如果存在），合并到 extracted 中
                if sound_j_cpk:
                    progress_cb(50, "正在解包 SOUND_J.CPK（系统音效/短音效）...", "extract")
                    sound_j_extracted = self.cpk.extract_bgm(
                        sound_j_cpk, output_dir, progress_cb, cancel_event
                    )
                    # 合并（SOUND_J 的文件加前缀避免冲突）
                    for name, path in sound_j_extracted.items():
                        # 用完整路径作为 key，避免同名冲突
                        full_key = f"SOUND_J/{name}"
                        extracted[full_key] = path

                if cancel_event.is_set():
                    self.root.after(0, lambda: self._cpk_extract_cancelled(progress_win))
                    return

                self.root.after(0, lambda: self._cpk_extract_done(
                    extracted, output_dir, progress_win, cpk_folder))
            except Exception as e:
                err_msg = str(e)
                self.root.after(0, lambda msg=err_msg: self._cpk_extract_error(msg, progress_win))

        threading.Thread(target=do_extract, daemon=True).start()

    def _cpk_extract_cancelled(self, progress_win):
        """CPK 解包被用户取消"""
        progress_win.destroy()
        self._update_status("CPK 解包已取消")

    def _cpk_extract_done(self, extracted: dict, output_dir: str, progress_win, cpk_folder: str = ""):
        """CPK 解包完成，将进度窗口转换为"正在导入音频列表"模式"""
        if not extracted:
            progress_win.destroy()
            messagebox.showwarning(
                "提取完成但未找到 BGM",
                f"CPK 解包完成，但未提取到 BGM.AWB 或 BGM.ACB 文件。\n\n"
                f"输出目录: {output_dir}\n\n"
                f"可能原因:\n"
                f"1. 该 CPK 不是 BASE.CPK\n"
                f"2. 纯 Python 解析器无法处理该 CPK 的压缩格式\n"
                f"3. 建议安装 CriPakTools.exe 放入 tools 目录"
            )
            self._update_status("CPK 解包完成，但未找到 BGM 文件")
            return

        # 找到所有 AWB 文件（主 BGM.AWB + 额外 BGM_01.AWB...BGM_16.AWB + 音效 + 语音）
        awb_files = []
        for name, path in extracted.items():
            if name.lower().endswith('.awb') and os.path.exists(path):
                awb_files.append((name, path))

        if not awb_files:
            progress_win.destroy()
            self._update_status(f"CPK 解包完成，提取了 {len(extracted)} 个文件")
            messagebox.showinfo(
                "提取完成",
                f"成功从 CPK 提取了以下文件:\n\n"
                + "\n".join(f"  - {name}" for name in extracted.keys())
                + f"\n\n输出目录: {output_dir}\n\n"
                f"请通过 文件 -> 导入 BGM.AWB 选择提取的 AWB 文件。"
            )
            return

        # ===== 转换进度窗口为"正在导入音频列表"模式 =====
        # 清空窗口内容，重新填充导入进度 UI
        for child in progress_win.winfo_children():
            child.destroy()
        progress_win.title("正在导入音频列表...")
        progress_win.geometry("560x300")

        Label(progress_win, text="CPK 解包完成，正在导入音频列表...",
              font=("Arial", 11, "bold")).pack(pady=(12, 4))
        Label(progress_win, text=f"共 {len(awb_files)} 个音频包，正在逐个解包并识别曲名",
              wraplength=520, fg="gray").pack()

        # 进度信息行（百分比 + 阶段）
        info_frame = Frame(progress_win)
        info_frame.pack(fill=X, padx=20, pady=(8, 2))
        import_percent_var = StringVar(value="0%")
        import_phase_var = StringVar(value="准备中")
        Label(info_frame, textvariable=import_phase_var, anchor=W, fg="blue").pack(side=LEFT)
        Label(info_frame, textvariable=import_percent_var, anchor=E,
              font=("Arial", 10, "bold")).pack(side=RIGHT)

        import_progress_bar = ttk.Progressbar(progress_win, mode='determinate', maximum=100, length=500)
        import_progress_bar.pack(pady=(2, 4), padx=20)

        # 当前操作消息
        import_message_var = StringVar(value="准备中...")
        Label(progress_win, textvariable=import_message_var, wraplength=520, fg="gray",
              font=("Arial", 9)).pack(pady=(0, 4))

        # 导入进度回调：percent 0-100
        _last_pct = [-1]
        _last_msg = [""]
        def import_progress_cb(percent, message):
            # 节流：百分比与消息都无变化时跳过，避免 after 回调风暴拖慢 UI
            if percent == _last_pct[0] and message == _last_msg[0]:
                return
            _last_pct[0] = percent
            if message:
                _last_msg[0] = message
            def update():
                import_progress_bar['value'] = percent
                import_percent_var.set(f"{percent}%")
                if message:
                    import_message_var.set(message)
                import_phase_var.set("正在导入")
            self.root.after(0, update)

        self._update_status(f"CPK 解包完成，正在导入 {len(awb_files)} 个音频 AWB...")

        def do_import():
            try:
                # 使用项目下的持久化提取目录（重启不丢失，便于替换记录恢复）
                # 已解包的 AWB 通过 marker 复用，避免重复解包（大幅加速启动恢复）
                extract_dir = Path("extracted_bgm")
                extract_dir.mkdir(parents=True, exist_ok=True)

                bgm_list = []
                sfx_list = []
                voice_list = []
                failed_awbs = []

                # 构建 ACB 文件路径映射表（用于提取 Cue 名称）
                acb_paths = {}
                for name, path in extracted.items():
                    if name.upper().endswith(".ACB"):
                        acb_stem = Path(name).stem.upper()
                        acb_paths[acb_stem] = path

                # 已有 AWB 的 stem 集合（用于判断哪些 ACB 是 non-streaming）
                awb_stems = {Path(name).stem.upper() for name, _ in awb_files}

                # ==== ACB 一次性解析缓存（避免对超大 ACB 重复读取磁盘）====
                # 磁盘缓存：ACB 内容不变时（文件名+大小+mtime 一致）直接复用上次解析结果，
                # 避免每次启动都重新解析上千个 ACB（可省 10+ 秒）
                acb_cache = {}  # stem -> parse_acb_bundle 结果
                _acb_disk_cache_path = Path("_acb_cache.json")
                _acb_disk_cache = {}
                _acb_meta = {}  # stem -> (size, mtime) 用于判断缓存是否有效
                try:
                    if _acb_disk_cache_path.exists():
                        _acb_disk_cache = json.loads(_acb_disk_cache_path.read_text(encoding="utf-8"))
                except Exception:
                    _acb_disk_cache = {}

                # 需要解析的 ACB：有对应 AWB 的（用于 Cue 名称/Wave→Cue）+ 无对应 AWB 的（检查内嵌）
                acb_to_parse = {Path(name).stem.upper(): path for name, path in acb_paths.items()}
                acb_keys = [k for k, v in acb_to_parse.items() if os.path.exists(v)]

                # 先按文件大小+mtime 判定哪些命中磁盘缓存（O(1) stat，不解析内容）
                _acb_cache_hit = set()
                for _stem in acb_keys:
                    _ap = acb_to_parse[_stem]
                    # 仅 streaming ACB（有对应 AWB）走磁盘缓存；non-streaming ACB 需实时解析
                    # 以保留 inner_awb_data（内嵌 AWB 提取功能），且其数量少、解析快
                    if _stem not in awb_stems:
                        continue
                    try:
                        _st = os.stat(_ap)
                        _sig = f"{_st.st_size}:{int(_st.st_mtime)}"
                        _acb_meta[_stem] = _sig
                        _ck = _acb_disk_cache.get(_stem)
                        if isinstance(_ck, dict) and _ck.get("_sig") == _sig:
                            # 磁盘缓存命中：直接还原（streaming ACB 无内嵌数据）
                            _b = {k2: v2 for k2, v2 in _ck.items() if k2 != "_sig"}
                            # JSON 序列化后 wave_to_cue/cue_names 的 int key 变成 str，
                            # 还原时转回 int，保证与实时解析返回结构一致（wave_id 为 int 查找）
                            for _km in ("wave_to_cue", "cue_names"):
                                _src = _b.get(_km)
                                if isinstance(_src, dict) and _src:
                                    _converted = {}
                                    for _k3, _v3 in _src.items():
                                        try:
                                            _ik = int(_k3)
                                        except Exception:
                                            _ik = _k3
                                        _converted[_ik] = _v3
                                    _b[_km] = _converted
                            acb_cache[_stem] = _b
                            _acb_cache_hit.add(_stem)
                    except Exception:
                        pass

                _acb_to_parse_keys = [k for k in acb_keys if k not in _acb_cache_hit]

                # 并行解析未命中缓存的 ACB（IO 密集，多线程加速；进度按完成数回调）
                from concurrent.futures import ThreadPoolExecutor as _ACBExec
                _acb_workers = min(12, max(2, len(_acb_to_parse_keys) if len(_acb_to_parse_keys) < 16 else 12))
                _acb_done = [0]
                _acb_total = len(_acb_to_parse_keys)
                _acb_cached_total = len(_acb_cache_hit)

                def _parse_one_acb(acb_stem):
                    acb_path = acb_to_parse[acb_stem]
                    try:
                        # 有对应 AWB 的 streaming ACB 只需 Cue 名称（只读头部，避免读大文件）；
                        # 无对应 AWB 的 ACB 才需要完整读取检测内嵌 AWB
                        need_inner = acb_stem not in awb_stems
                        return acb_stem, parse_acb_bundle(acb_path, need_inner=need_inner)
                    except Exception:
                        return acb_stem, None

                if len(_acb_to_parse_keys) > 1:
                    with _ACBExec(max_workers=_acb_workers) as _ex:
                        _futs = {_ex.submit(_parse_one_acb, k): k for k in _acb_to_parse_keys}
                        for _fut in _futs:
                            try:
                                _stem, _bundle = _fut.result()
                                acb_cache[_stem] = _bundle
                            except Exception:
                                pass
                            _acb_done[0] += 1
                            import_progress_cb(
                                int(_acb_done[0] / max(_acb_total, 1) * 8),
                                f"[{_acb_done[0]}/{_acb_total}] 正在解析音频信息 {_stem}.ACB..."
                            )
                else:
                    for i, acb_stem in enumerate(_acb_to_parse_keys):
                        import_progress_cb(
                            int(i / max(_acb_total, 1) * 8),
                            f"[{i + 1}/{_acb_total}] 正在解析音频信息 {Path(acb_to_parse[acb_stem]).name}..."
                        )
                        _stem, _bundle = _parse_one_acb(acb_stem)
                        acb_cache[_stem] = _bundle

                # 写回磁盘缓存（仅保存可序列化的字段：cue_names / wave_to_cue / has_inner）
                try:
                    _to_save = {}
                    for _stem, _bundle in acb_cache.items():
                        if not isinstance(_bundle, dict):
                            continue
                        _sig = _acb_meta.get(_stem)
                        if _sig is None:
                            try:
                                _ap = acb_to_parse[_stem]
                                _st = os.stat(_ap)
                                _sig = f"{_st.st_size}:{int(_st.st_mtime)}"
                            except Exception:
                                _sig = ""
                        _to_save[_stem] = {
                            "_sig": _sig,
                            "cue_names": _bundle.get("cue_names") or {},
                            "wave_to_cue": _bundle.get("wave_to_cue") or {},
                            "has_inner": bool(_bundle.get("has_inner")),
                        }
                    if _to_save:
                        _acb_disk_cache_path.write_text(
                            json.dumps(_to_save, ensure_ascii=False), encoding="utf-8"
                        )
                except Exception as e:
                    print(f"[ACB缓存] 保存失败: {e}")
                if _acb_cached_total > 0:
                    print(f"[导入] ACB 解析: {_acb_cached_total} 个命中缓存, {len(_acb_to_parse_keys)} 个新解析")

                # 处理 non-streaming ACB（没有对应 AWB，但内嵌了 AWB 数据）
                inner_awb_dir = extract_dir / "_inner_awb"
                inner_awb_dir.mkdir(parents=True, exist_ok=True)
                inner_awb_count = 0
                non_stream_candidates = [s for s in acb_to_parse if s not in awb_stems]
                for i, acb_stem in enumerate(non_stream_candidates):
                    # 内嵌提取阶段进度：8 ~ 10%
                    import_progress_cb(
                        8 + int(i / max(len(non_stream_candidates), 1) * 2),
                        f"正在检查内嵌音频包 {acb_stem}.ACB..."
                    )
                    acb_path = acb_to_parse[acb_stem]
                    bundle = acb_cache.get(acb_stem)
                    if not bundle or not bundle.get("has_inner"):
                        continue
                    awb_data = bundle.get("inner_awb_data")
                    if not awb_data:
                        continue
                    try:
                        inner_awb_path = str(inner_awb_dir / f"{acb_stem}.AWB")
                        if not os.path.exists(inner_awb_path) or os.path.getsize(inner_awb_path) != len(awb_data):
                            with open(inner_awb_path, 'wb') as f:
                                f.write(awb_data)
                        awb_files.append((f"{acb_stem}.AWB", inner_awb_path))
                        inner_awb_count += 1
                    except Exception:
                        pass

                if inner_awb_count > 0:
                    print(f"[导入] 从 non-streaming ACB 中提取了 {inner_awb_count} 个内嵌 AWB")

                # 并行解包 AWB（IO 密集，多线程加速；已解包的直接复用）
                total_awb = len(awb_files)
                from concurrent.futures import ThreadPoolExecutor, as_completed

                def extract_one_awb(awb_name, awb_path, awb_idx):
                    """单个 AWB 解包 + 元数据构建（供线程池调用）"""
                    awb_stem = Path(awb_name).stem
                    awb_file_name = Path(awb_name).name.upper()
                    # 判断来源 CPK：key 带 "SOUND_J/" 前缀 = 来自 SOUND_J.CPK（日文语音包）
                    # 否则来自 BASE.CPK（主数据包，含过场音频/音轨）
                    is_from_lang_cpk = awb_name.replace("\\", "/").startswith("SOUND_J/")
                    source_cpk = "SOUND_J" if is_from_lang_cpk else "BASE"
                    is_bgm = awb_file_name.startswith("BGM")
                    # 音效：带 _SE 后缀（Sound Effect）、SYSTEM 开头、或 BASE.CPK 的 F* 场景环境音效包
                    # BASE.CPK 的 F*（F051/F052 等）是宫殿/场景环境音效（amb_Dungeon、torch、cage、enemy_foot 等），不是语音
                    # SOUND_J.CPK 的 F* 是场景语音，保持语音分类
                    is_sfx = (
                        "_SE" in awb_file_name
                        or awb_file_name.startswith("SYSTEM")
                        or (not is_from_lang_cpk and awb_file_name.startswith("F"))
                        or awb_stem.upper() in ("TITLE", "MY_PALACE")
                    )
                    # 语音：非BGM非音效的都归为语音
                    # 包括：SOUND_J 的 BP/VOICE/BE/E/F（日文配音），BASE 的 E* 无_SE（过场音频/音轨），
                    # 以及带 _SE 但 Cue 名含 drama/eiga/movie 的过场电影音轨（在下方 Cue 解析后重新判断）
                    is_voice = not is_sfx and not is_bgm

                    # 主 BGM.AWB 解包到根目录，其他解包到子目录
                    if awb_stem.upper() == "BGM":
                        awb_extract_dir = extract_dir
                    else:
                        awb_extract_dir = extract_dir / awb_stem
                        awb_extract_dir.mkdir(parents=True, exist_ok=True)

                    # 已解包（marker 匹配）则直接复用，跳过重新写盘
                    # trust_cache=True：marker 确认源 AWB 未变化，直接信任扫描缓存（秒开）
                    if self.awb.is_extracted(awb_path, str(awb_extract_dir)):
                        tracks = self.awb.scan_extracted_awb(str(awb_extract_dir), awb_stem=awb_stem, trust_cache=True)
                    else:
                        tracks = self.awb.extract_awb(awb_path, str(awb_extract_dir), awb_stem=awb_stem)

                    # 尝试解析对应的 ACB 文件，提取 Cue 名称和 Wave→Cue 映射
                    cue_names = {}
                    wave_to_cue = {}
                    is_non_streaming = False
                    bundle = acb_cache.get(awb_stem.upper())
                    if bundle:
                        is_non_streaming = bool(bundle.get("has_inner"))
                        wave_to_cue = bundle.get("wave_to_cue") or {}
                        cue_names = bundle.get("cue_names") or {}

                    # 过场电影音轨检测：带 _SE 后缀但 Cue 名符合电影命名前缀的音轨
                    # 这些是预渲染过场动画的音轨（含人声语音），不是普通音效
                    # 例如 E762_301_SE 的 Cue 名 "p5_eiga_t04"（eiga=映画=电影）
                    # 注意：关键词必须精确匹配电影命名，不能用宽泛子串，否则误伤普通音效：
                    #   - "dramatic"（SYSTEM 的 wire_dramatic 戏剧性音效）≠ 电影，应保持音效
                    #   - "film"（DUNGEON_SE 的 laser_film 激光胶片效果音）≠ 电影，应保持音效
                    #   - "amb_cinema_*"（F010_020 的电影院环境声）≠ 电影音轨，应保持音效
                    is_cutscene_movie = False
                    if cue_names:
                        for cn in cue_names.values():
                            cnl = str(cn).lower()
                            if ("eiga" in cnl or "movie" in cnl
                                    or cnl.startswith("p5_drama_") or cnl.startswith("p5r_drama_")
                                    or cnl.startswith("opening") or cnl.startswith("ending")):
                                is_cutscene_movie = True
                                break
                    if is_cutscene_movie and is_sfx:
                        # 过场电影音轨归为语音（BASE 过场音频），而非音效
                        is_sfx = False
                        is_voice = True

                    # 过场剪辑音效检测：cue 名以 "cut" 开头（cut1/cut3 等）的数字编号 ACB
                    # （如 BASE.CPK 的 0010~0xxx），是过场剪辑音效包（内嵌 AWB，wave_id 为 7 位大数），
                    # 不是角色语音。仅非过场电影音轨时生效（电影音轨优先按语音处理）。
                    if not is_cutscene_movie and cue_names:
                        for _cn in cue_names.values():
                            if str(_cn).lower().startswith("cut"):
                                is_sfx = True
                                is_voice = False
                                break

                    # ★ 分类修正：BASE.CPK 的 non-streaming 内嵌 AWB（has_inner=True）全部是音效包，
                    # 不是角色语音。实测 868 个内嵌包全部为环境/剪辑/战斗音效：
                    #   - 纯数字剪辑包（0010~0xxx，cue=cut1/cut3）
                    #   - F* 场景包（F010_020 等，cue=amb_Dungeon / amb_Cinema / amb_Roomtone）
                    #   - MEMENTOS（cue=amb_voice_tunnel / box_loop）
                    #   - EM*（cue=motion_5_atk / motion_8_mgc 战斗音效）
                    #   - F_ANKOKU__ 等（cue=cut3）
                    #   - E651_*_KF（cue=amb_Velvet）
                    # 此前它们被误归为"角色语音"（如 3922000~4755007 段），
                    # 且 F* 的 amb_Cinema 含 "cinema" 会被上方的过场电影音轨检测误判回语音。
                    # 真语音包（BP*/VOICE*/SOUND_J 配音、BASE 的 E* 过场语音）均为 has_inner=False，
                    # 走独立 AWB 路径，不受此规则影响。
                    if is_non_streaming and not is_from_lang_cpk and not is_bgm:
                        is_sfx = True
                        is_voice = False

                    return (awb_idx, awb_stem, tracks, is_sfx, is_bgm, is_voice, is_non_streaming, cue_names, wave_to_cue, source_cpk)

                # 按顺序收集结果（保持列表顺序稳定）
                ordered_results = {}
                if total_awb <= 1:
                    # 单个 AWB 直接同步执行（避免线程开销）
                    for awb_idx, (awb_name, awb_path) in enumerate(awb_files):
                        ordered_results[awb_idx] = extract_one_awb(awb_name, awb_path, awb_idx)
                else:
                    worker_count = min(12, total_awb)
                    with ThreadPoolExecutor(max_workers=worker_count) as executor:
                        futures = {}
                        for awb_idx, (awb_name, awb_path) in enumerate(awb_files):
                            future = executor.submit(extract_one_awb, awb_name, awb_path, awb_idx)
                            futures[future] = awb_idx
                        done_count = 0
                        for future in as_completed(futures):
                            try:
                                result = future.result()
                                ordered_results[result[0]] = result
                            except Exception:
                                pass
                            done_count += 1
                            # 并行解包阶段进度：10 ~ 85%
                            import_progress_cb(
                                10 + int(done_count / total_awb * 75),
                                f"[{done_count}/{total_awb}] 正在解包音频包..."
                            )

                # 构建最终列表（按 AWB 顺序），进度 85 ~ 98%
                for awb_idx in range(total_awb):
                    import_progress_cb(
                        85 + int(awb_idx / max(total_awb, 1) * 13),
                        f"[{awb_idx + 1}/{total_awb}] 正在整理音频列表..."
                    )
                    result = ordered_results.get(awb_idx)
                    if result is None:
                        continue
                    (awb_idx, awb_stem, tracks, is_sfx, is_bgm, is_voice,
                     is_non_streaming, cue_names, wave_to_cue, source_cpk) = result

                    # 容错：单个 AWB 解包失败时跳过，不影响其他 AWB
                    if tracks is None:
                        failed_awbs.append(awb_files[awb_idx][0])
                        continue

                    for t_idx, t in enumerate(tracks):
                        track = {**t, "replaced": False, "replaced_path": None,
                                 "original_path": t["path"]}
                        # 记录来源 AWB 和真实索引（供替换/导出用，AWB Emulator 需要真实索引）
                        track["awb_stem"] = awb_stem
                        track["real_index"] = t["wave_id"]
                        # 记录来源 CPK（BASE 过场音频 / SOUND_J 日文配音），用于列表颜色区分
                        track["source_cpk"] = source_cpk
                        # 标记 non-streaming ACB（SYSTEM/VOICE_SINGLEWORD/TITLE 等，导出用 Ryo Framework）
                        track["is_non_streaming"] = is_non_streaming
                        track["acb_name"] = awb_stem
                        # 标记类型：bgm / sfx / voice（用于颜色区分，不依赖 wave_id 范围）
                        if is_sfx:
                            track["type"] = "sfx"
                        elif is_voice:
                            track["type"] = "voice"
                        else:
                            track["type"] = "bgm"
                        # 非主BGM的 wave_id 加偏移避免冲突
                        if awb_stem.upper() != "BGM":
                            if is_sfx:
                                track["wave_id"] = 20000 + awb_idx * 1000 + t["wave_id"]
                                # 音效曲名：优先用 Wave→Cue 映射（key 为真实 wave_id/StreamAwbId）
                                # 找不到再回退到 ACB Cue 名称或 AWB 文件名
                                cue_name = None
                                cue_info = wave_to_cue.get(t["wave_id"])
                                if cue_info and cue_info[1]:
                                    cue_name = cue_info[1]
                                if not cue_name:
                                    cue_name = cue_names.get(t["wave_id"]) or cue_names.get(t_idx)
                                if cue_name:
                                    track["name"] = f"{awb_stem} {cue_name}"
                                    track["cue_name"] = cue_name
                                else:
                                    # 没有 Cue 名称时，用 AWB 文件名 + 真实 wave_id
                                    track["name"] = f"{awb_stem} #{t['wave_id']:03d}"
                            elif is_voice:
                                track["wave_id"] = 30000 + awb_idx * 1000 + t["wave_id"]
                                # 角色语音曲名：优先用 Wave→Cue 映射（key 为真实 wave_id/StreamAwbId）
                                # 查不到时显示真实 wave_id（不能 fallback 到 t_idx 会错位）
                                cue_name = None
                                cue_info = wave_to_cue.get(t["wave_id"])
                                if cue_info and cue_info[1]:
                                    cue_name = cue_info[1]
                                if not cue_name:
                                    cue_name = cue_names.get(t["wave_id"])
                                if cue_name:
                                    track["name"] = f"[{awb_stem}] {cue_name}"
                                    track["cue_name"] = cue_name
                                else:
                                    track["name"] = f"[{awb_stem}] wave_{t['wave_id']:03d}"
                            else:
                                track["wave_id"] = 10000 + awb_idx * 1000 + t["wave_id"]
                                track["name"] = f"[{awb_stem}] {t['name']}"
                        # non-streaming ACB 用 Wave→Cue 映射覆盖曲名（SYSTEM/VOICE_SINGLEWORD/TITLE 等）
                        if is_non_streaming and t["wave_id"] in wave_to_cue:
                            cue_id, cue_name = wave_to_cue[t["wave_id"]]
                            if cue_name:
                                track["name"] = f"[{awb_stem}] {cue_name}"
                                track["cue_name"] = cue_name
                                track["cue_id"] = cue_id
                        # 应用手动分类覆盖（用户试听后修正的分类）
                        orig_path = track.get("original_path", "")
                        override = self.class_overrides.get(orig_path)
                        if override in ("sfx", "voice"):
                            track["type"] = override
                            if override == "sfx":
                                sfx_list.append(track)
                            else:
                                voice_list.append(track)
                        elif is_sfx:
                            sfx_list.append(track)
                        elif is_voice:
                            voice_list.append(track)
                        else:
                            bgm_list.append(track)

                self.bgm_tracks = bgm_list
                self.sfx_tracks = sfx_list
                self.voice_tracks = voice_list

                # ===== 注册 .msg 语音段对齐（自动分割"一条台词对应多条语音"）=====
                # 对每个角色语音 AWB：若其语音 wave 数 == 对应 .msg 文件的语音段数，
                # 则标记为 msg 顺序对齐，之后 match_wave_texts 会按 .msg 段精确分割。
                try:
                    self._register_msg_aligned_voices(voice_list)
                except Exception as e:
                    print(f"[msg对齐] 注册失败: {e}")

                # 本次 CPK 若不含 BGM.AWB（如 SOUND_J.CPK 等语音包），自动复用已有主 BGM 解包，
                # 避免 BGM 列表为空（extracted_bgm 根目录保存了主 BGM.AWB 的解包结果）
                if not bgm_list:
                    try:
                        scanned_bgm = self.awb.scan_extracted_awb(str(extract_dir), awb_stem="BGM")
                        for t in scanned_bgm:
                            bgm_list.append({
                                **t,
                                "replaced": False,
                                "replaced_path": None,
                                "original_path": t["path"],
                                "awb_stem": "BGM",
                                "real_index": t["wave_id"],
                                "type": "bgm",
                            })
                        if scanned_bgm:
                            print(f"[导入] 当前 CPK 不含 BGM.AWB，已复用已有主 BGM 解包 {len(scanned_bgm)} 首")
                    except Exception:
                        pass
                # 根据当前类型显示对应列表
                if self.current_audio_type == "sfx" and sfx_list:
                    self.tracks = sfx_list
                elif self.current_audio_type == "voice" and voice_list:
                    self.tracks = voice_list
                else:
                    self.tracks = bgm_list
                    self.current_audio_type = "bgm"

                # 保存导入来源，供下次启动自动恢复（包括主BGM和额外BGM和音效）
                if cpk_folder:
                    self._save_last_import("cpk_folder", cpk_folder)
                all_count = len(bgm_list) + len(sfx_list) + len(voice_list)
                print(f"[导入完成] BGM: {len(bgm_list)} 首, 音效: {len(sfx_list)} 首, 角色语音: {len(voice_list)} 首, 总计: {all_count} 首")
                if voice_list:
                    print(f"[导入] 语音 AWB 列表: {sorted(set(t['name'].split(']')[0].strip('[]') for t in voice_list))}")
                import_progress_cb(100, "导入完成，正在刷新列表...")
                self.root.after(0, lambda: self._after_import(self.tracks, all_count))
                # 导入完成，关闭进度窗口
                self.root.after(400, progress_win.destroy)
                # 如果有解包失败的 AWB，提示用户
                if failed_awbs:
                    fail_msg = f"以下 {len(failed_awbs)} 个 AWB 文件解包失败，已自动跳过：\n\n"
                    fail_msg += "\n".join(f"  - {name}" for name in failed_awbs[:10])
                    if len(failed_awbs) > 10:
                        fail_msg += f"\n  ... 还有 {len(failed_awbs) - 10} 个"
                    fail_msg += "\n\n这些文件可能需要 AcbEditor.exe 才能解包。"
                    self.root.after(600, lambda: messagebox.showwarning("部分 AWB 解包失败", fail_msg))
            except Exception as e:
                err_msg = str(e)
                try:
                    progress_win.destroy()
                except Exception:
                    pass
                self.root.after(0, lambda msg=err_msg: self._import_error(msg))

        threading.Thread(target=do_import, daemon=True).start()

    def _cpk_extract_error(self, err: str, progress_win):
        """CPK 解包出错"""
        progress_win.destroy()
        self._update_status(f"CPK 解包失败: {err}")
        messagebox.showwarning(
            "CPK 自动解包失败",
            f"自动解包未能提取 BGM 文件。\n\n"
            f"错误详情: {err}\n\n"
            f"=== 解决方案 ===\n\n"
            f"1. 安装 pythonnet: py -m pip install pythonnet\n"
            f"2. 确认 tools/CriFsV2Lib/ 目录下有 CriFsV2Lib.dll\n"
            f"3. 或手动用 CriFsV2Lib.GUI 提取:\n"
            f"   https://github.com/blueskythlikesclouds/CriFsV2Lib/releases\n"
            f"   拖拽 BASE.CPK 到程序中，提取 BASE/SOUND/BGM.AWB 和 BGM.ACB\n\n"
            f"提取后，将 BGM.AWB 和 BGM.ACB 放到一个文件夹，\n"
            f"然后在本软件中使用「文件 → 导入 BGM.AWB」即可。"
        )

    def _after_import(self, tracks, total_count: int = 0):
        """导入完成后刷新列表"""
        # 应用已保存的替换记录（不自动刷新，统一由下方刷新一次，避免双倍开销）
        self.apply_replacements_to_tracks(refresh=False)
        self.refresh_track_list()
        # 更新选项卡按钮显示
        self._update_audio_tabs()
        if total_count > 0:
            self.track_count_var.set(f"曲目: {len(tracks)} / 共 {total_count}")
        else:
            self.track_count_var.set(f"曲目: {len(tracks)}")
        known = sum(1 for t in tracks if is_known_track(t["wave_id"]))
        replaced_count = len(self.replacements)
        if replaced_count > 0:
            self._update_status(f"导入完成: 共 {len(tracks)} 首，已识别 {known} 首，已恢复 {replaced_count} 首替换")
        else:
            self._update_status(f"导入完成: 共 {len(tracks)} 首，已识别 {known} 首")
        # 若当前在音效 tab 且未检测过，后台计算重复哈希
        if (self.current_audio_type == "sfx" and hasattr(self, 'sfx_dedup_btn')
                and not self.sfx_hash_ready and self.sfx_tracks):
            self.sfx_dedup_btn.config(text="检测中...")
            self._compute_sfx_hashes_async()

    def _import_error(self, err):
        self._update_status(f"导入失败: {err}")
        messagebox.showerror("导入失败", err)

    def _toggle_placeholder(self):
        """切换音效空槽位显示"""
        self.show_placeholder_sfx = self.show_placeholder_var.get()
        self.refresh_track_list()

    def switch_audio_type(self, audio_type: str):
        """切换 BGM/音效/角色语音 选项卡"""
        if audio_type == self.current_audio_type:
            return
        if audio_type == "sfx" and not self.sfx_tracks:
            messagebox.showinfo("提示", "当前没有音效数据。\n\n请先通过「文件 → 导入BASE.CPK所在的文件夹」解包，音效文件（E*_SE.AWB）会自动提取。")
            return
        if audio_type == "voice" and not self.voice_tracks:
            messagebox.showinfo("提示", "当前没有角色语音数据。\n\n请先通过「文件 → 导入BASE.CPK所在的文件夹」解包，角色语音文件（BP01.AWB、VOICE_*.AWB）会自动提取。")
            return
        if audio_type == "bgm" and not self.bgm_tracks:
            messagebox.showinfo("提示", "当前没有 BGM 数据。")
            return

        self.current_audio_type = audio_type
        # 等长匹配默认按界面：音效必须开（防无声），语音 Ryo 下无需等长（超长完整播放）
        if hasattr(self, 'match_length_var'):
            if audio_type == "sfx":
                self.match_length_var.set(True)
            elif audio_type == "voice":
                self.match_length_var.set(False)
        if audio_type == "bgm":
            self.tracks = self.bgm_tracks
        elif audio_type == "sfx":
            self.tracks = self.sfx_tracks
        else:
            self.tracks = self.voice_tracks

        # 音效 tab 显示"空槽位"切换复选框 + 重复折叠按钮，其他 tab 隐藏
        if hasattr(self, 'show_placeholder_check'):
            if audio_type == "sfx":
                self.show_placeholder_check.pack(side=RIGHT, padx=4)
                # 切到音效 tab 时显示折叠按钮（已检测过则直接显示，未检测过则触发后台检测）
                # 使用 before=voice_tab_btn 确保按钮始终在音效tab和角色语音tab之间
                if hasattr(self, 'sfx_dedup_btn') and self.sfx_tracks:
                    self.sfx_dedup_btn.pack(side=LEFT, padx=2, pady=2, before=self.voice_tab_btn)
                    if self.sfx_hash_ready:
                        self.sfx_dedup_btn.config(text="⤴ 展开重复" if self.sfx_collapsed else "⤵ 折叠重复")
                    else:
                        self.sfx_dedup_btn.config(text="检测中...")
                        self._compute_sfx_hashes_async()
            else:
                self.show_placeholder_check.pack_forget()
                if hasattr(self, 'sfx_dedup_btn'):
                    self.sfx_dedup_btn.pack_forget()
        # 角色语音 tab 显示角色筛选下拉菜单，其他 tab 隐藏
        if hasattr(self, 'voice_filter_combo'):
            if audio_type == "voice":
                # 动态生成选项：只显示实际有数据的角色 + 其他语音
                self._update_voice_filter_options()
                self.voice_filter_combo.pack(side=LEFT, padx=(8, 2), pady=2)
            else:
                self.voice_filter_combo.pack_forget()

        self.current_track = None
        self._clear_detail_panel()
        self.refresh_track_list()
        self._update_audio_tabs()
        self._update_replace_panel_visibility()
        type_names = {"bgm": "BGM", "sfx": "音效", "voice": "角色语音"}
        self._update_status(f"已切换到 {type_names.get(audio_type, audio_type)} 列表（{len(self.tracks)} 首）")


    def _update_voice_filter_options(self):
        """根据 voice_tracks 实际存在的 awb_stem 动态生成角色语音分类下拉菜单。
        参考 spriters-resource 网站分类：角色战斗语音(BP)、Boss语音(BE_BOSS)、
        战斗事件语音(BE)、宫殿剧情语音(VOICE_DUNGEON)、单词语音(VOICE_SINGLEWORD)、
        过场语音(E)、场景语音(F) 等。
        """
        if not hasattr(self, 'voice_filter_combo'):
            return
        # 收集所有 awb_stem
        all_stems = {t.get("awb_stem", "").upper() for t in self.voice_tracks if t.get("awb_stem")}
        # 判断各类别是否存在
        def has(prefixes):
            return any(any(s.startswith(p) for p in prefixes) for s in all_stems)

        bp_stems = sorted({s for s in all_stems if s.startswith("BP")})
        has_boss = has(("BE_BOSS",))
        has_battle = has(("BE_",)) and not has(("BE_BOSS",))
        # BE_ 开头的（排除 BE_BOSS 和 BE_01~11 之外的）
        has_battle = any(s.startswith("BE_") and not s.startswith("BE_BOSS") for s in all_stems)
        has_dungeon = has(("VOICE_DUNGEON",))
        has_singleword = has(("VOICE_SINGLEWORD",))
        has_event = has(("E",)) and not has(("BE",)) and not has(("BP",))
        has_field = has(("F",))
        # 构建选项列表：先按角色(BP)，再按语音类别
        options = ["全部语音"]
        # 角色战斗语音（BP01~BP10）
        if bp_stems:
            for stem in bp_stems:
                char_name = BP_CHARACTER_MAP.get(stem, stem)
                options.append(f"{char_name} ({stem})")
        # 语音类别
        if has_boss:
            options.append("Boss 战斗语音 (BE_BOSS_*)")
        if has_battle:
            options.append("战斗事件语音 (BE_*)")
        if has_dungeon:
            options.append("宫殿剧情语音 (VOICE_DUNGEON_*)")
        if has_singleword:
            options.append("单词语音 (VOICE_SINGLEWORD)")
        if has_event:
            options.append("过场剧情语音 (E*)")
        if has_field:
            options.append("场景语音 (F*)")
        options.append("其他语音")
        # 更新下拉菜单
        self.voice_filter_combo['values'] = options
        # 如果当前选择不在新选项里，重置为"全部语音"
        if self.voice_filter_var.get() not in options:
            self.voice_filter_var.set("全部语音")

    def _voice_matches_filter(self, awb: str, voice_filter: str) -> bool:
        """判断某个语音 awb_stem 是否匹配下拉菜单筛选项。
        支持：全部语音、角色(BP编号)、Boss语音(BE_BOSS)、战斗事件语音(BE)、
        宫殿剧情语音(VOICE_DUNGEON)、单词语音(VOICE_SINGLEWORD)、
        过场语音(E)、场景语音(F)、其他语音。
        """
        import re
        awb = awb.upper()
        # 角色筛选：匹配 (BPxx) 或 (BPxx_yy)
        m = re.search(r'\(BP([^)]+)\)', voice_filter)
        if m:
            bp_prefix = "BP" + m.group(1)
            return awb.startswith(bp_prefix)
        # 语音类别筛选
        if voice_filter == "Boss 战斗语音 (BE_BOSS_*)":
            return awb.startswith("BE_BOSS")
        if voice_filter == "战斗事件语音 (BE_*)":
            return awb.startswith("BE_") and not awb.startswith("BE_BOSS")
        if voice_filter == "宫殿剧情语音 (VOICE_DUNGEON_*)":
            return awb.startswith("VOICE_DUNGEON")
        if voice_filter == "单词语音 (VOICE_SINGLEWORD)":
            return awb.startswith("VOICE_SINGLEWORD")
        if voice_filter == "过场剧情语音 (E*)":
            return awb.startswith("E") and not awb.startswith("BE") and not awb.startswith("BP") and not awb.endswith("_SE")
        if voice_filter == "场景语音 (F*)":
            return awb.startswith("F") and not awb.endswith("_SE")
        if voice_filter == "其他语音":
            return not (
                awb.startswith("BP") or awb.startswith("BE_BOSS") or
                awb.startswith("BE_") or awb.startswith("VOICE_DUNGEON") or
                awb.startswith("VOICE_SINGLEWORD") or awb.startswith("E") or
                awb.startswith("F")
            )
        # 兜底：默认不过滤（理论上不会到这）
        return True

    def _update_replace_panel_visibility(self):
        """根据当前音频类型显示替换功能（BGM/音效/角色语音均支持替换）"""
        if not hasattr(self, 'replace_frame'):
            return
        # BGM/音效/角色语音 都显示替换功能（导出时会按来源 AWB 归档到对应 FEmulator/AWB/ 文件夹）
        self.replace_frame.config(text="替换音乐")
        self.export_row.pack_forget()
        self.replace_file_label.pack(side=TOP, anchor=W, pady=2)
        self.replace_btn_row.pack(side=TOP, fill=X, pady=5)
        self.export_row.pack(side=TOP, fill=X, pady=(2, 5))
        self.replace_help_label.pack(side=TOP, anchor=W, pady=5)
        # BGM 不需要高级对齐选项（等长/响度/频谱/Ryo 等），音效/语音显示
        if hasattr(self, 'adv_align_frame'):
            if self.current_audio_type == "bgm":
                self.adv_align_frame.pack_forget()
            else:
                self.adv_align_frame.pack(side=TOP, fill=X)

    def _update_audio_tabs(self):
        """更新选项卡按钮样式和信息"""
        if not hasattr(self, 'bgm_tab_btn'):
            return
        # 重置所有按钮
        self.bgm_tab_btn.config(relief=RAISED, bg="#E0E0E0", fg="black")
        self.sfx_tab_btn.config(relief=RAISED, bg="#E0E0E0", fg="black")
        if hasattr(self, 'voice_tab_btn'):
            self.voice_tab_btn.config(relief=RAISED, bg="#E0E0E0", fg="black")
        # 高亮当前按钮
        if self.current_audio_type == "bgm":
            self.bgm_tab_btn.config(relief=SUNKEN, bg="#4CAF50", fg="white")
        elif self.current_audio_type == "sfx":
            self.sfx_tab_btn.config(relief=SUNKEN, bg="#FF9800", fg="white")
        elif self.current_audio_type == "voice":
            if hasattr(self, 'voice_tab_btn'):
                self.voice_tab_btn.config(relief=SUNKEN, bg="#9C27B0", fg="white")
        # 更新信息标签
        bgm_count = len(self.bgm_tracks)
        sfx_count = len(self.sfx_tracks)
        voice_count = len(self.voice_tracks)
        if bgm_count > 0 or sfx_count > 0 or voice_count > 0:
            self.tab_info_label.config(text=f"BGM: {bgm_count} | 音效: {sfx_count} | 语音: {voice_count}")
        else:
            self.tab_info_label.config(text="")

    def _clear_detail_panel(self):
        """清空详情面板"""
        if not hasattr(self, 'detail_id'):
            return
        self.detail_id.set("-")
        self.detail_name.set("-")
        self.detail_replaced_name.set("-")
        self.detail_size.set("-")
        self.detail_path.set("-")
        self.detail_encrypted.set("-")
        self.detail_duration.set("-")
        if hasattr(self, 'text_matcher_var'):
            self.text_matcher_var.set("（选中角色语音后显示对应中文台词）")
        self.play_btn.config(state=DISABLED)
        self.stop_btn.config(state=DISABLED)
        self.replace_btn.config(state=DISABLED)
        self.restore_btn.config(state=DISABLED)
        if hasattr(self, 'toggle_class_btn'):
            self.toggle_class_btn.config(state=DISABLED, text="切换为语音/音效")
        # 停止播放
        if self.playing:
            self.stop_preview()

    def _resolve_local_wave_id(self, t):
        """从 track 还原 AWB 内的局部 wave_id。

        批量解包时 track['wave_id'] 是全局偏移 ID（voice=30000+, sfx=20000+,
        extra_bgm=10000+，编码为 base + awb_idx*1000 + local），不能直接用作
        台词列表索引。优先用 real_index（保存的原始局部 wave_id），否则对
        全局 ID 取模 1000 还原。
        """
        wid = t.get("real_index")
        if wid is None:
            wid = t.get("wave_id")
        if wid is None:
            return None
        try:
            wid = int(wid)
        except (TypeError, ValueError):
            return None
        if wid >= 10000:
            wid = wid % 1000
        return wid

    def _match_bmd_index(self, note_text, all_texts):
        """在 BMD 台词列表中找到与标注内容最匹配的索引（文本相似度匹配）"""
        try:
            import difflib
        except Exception:
            return -1
        note_clean = note_text.strip()
        if not note_clean or len(note_clean) < 3:
            return -1
        best_idx = -1
        best_score = 0.0
        for i, m in enumerate(all_texts):
            name = (m.get("name", "") or "").replace(" ", "").replace("　", "")
            text = (m.get("text", "") or "").replace(chr(10), " ").strip()
            combined = f"{name}：{text}" if name else text
            # 计算相似度（取标注与组合文本、纯文本的较高值）
            s1 = difflib.SequenceMatcher(None, note_clean, combined).ratio()
            s2 = difflib.SequenceMatcher(None, note_clean, text).ratio()
            score = max(s1, s2)
            if score > best_score:
                best_score = score
                best_idx = i
        return best_idx if best_score >= 0.4 else -1

    def _get_voice_notes_index(self):
        """惰性构建 语音标注索引 {awb_upper: [(local_wave, note), ...]}。
        用 (id, len) 签名检测 voice_tracks 重建，避免每次全量遍历 7 万条 track。"""
        sig = (id(self.voice_tracks), len(self.voice_tracks))
        if self._voice_notes_index is not None and self._voice_notes_sig == sig:
            return self._voice_notes_index
        idx = {}
        for t in self.voice_tracks:
            g_wave = t.get("wave_id")
            if g_wave is None:
                continue
            note = self._get_track_note(t, "")
            if not note:
                continue
            local_wave = self._resolve_local_wave_id(t)
            if local_wave is None:
                continue
            awb_upper = str(t.get("awb_stem", "")).upper()
            if not awb_upper:
                continue
            idx.setdefault(awb_upper, []).append((local_wave, note))
        self._voice_notes_index = idx
        self._voice_notes_sig = sig
        return idx

    def _build_calibration(self, awb, all_texts):
        """构建该 AWB 的 local_wave_id -> bmd_index 校准映射（基于用户标注）。
        返回 (mapping, sorted_points)。加入顺序约束：BMD 索引必须单调不减。"""
        awb_upper = awb.upper()
        cached = self._calib_cache.get(awb_upper)
        if cached is not None:
            return cached
        mapping = {}
        try:
            import difflib
            # 从索引获取该 AWB 的标注候选（O(1)，不再全量遍历）
            candidates = sorted(self._get_voice_notes_index().get(awb_upper, []),
                                key=lambda x: x[0])
            # 带顺序约束的贪心匹配：BMD 索引必须 >= 前一个校准点的 BMD 索引
            prev_bmd = -1
            for local_wave, note in candidates:
                note_clean = note.strip()
                best_idx = -1
                best_score = 0.0
                # 只在 [prev_bmd, len-1] 范围内找最佳匹配
                for i in range(max(0, prev_bmd), len(all_texts)):
                    m = all_texts[i]
                    name = (m.get("name", "") or "").replace(" ", "").replace("\u3000", "")
                    text = (m.get("text", "") or "").replace(chr(10), " ").strip()
                    combined = f"{name}：{text}" if name else text
                    s1 = difflib.SequenceMatcher(None, note_clean, combined).ratio()
                    s2 = difflib.SequenceMatcher(None, note_clean, text).ratio()
                    score = max(s1, s2)
                    if score > best_score:
                        best_score = score
                        best_idx = i
                if best_idx >= 0 and best_score >= 0.4:
                    mapping[local_wave] = best_idx
                    prev_bmd = best_idx
        except Exception as e:
            print(f"[校准构建] 异常: {e}")
        result = (mapping, sorted(mapping.items()))
        self._calib_cache[awb_upper] = result
        return result

    def _infer_bmd_index(self, wave_id, calib, sorted_points=None):
        """根据校准点线性插值推断 wave_id 对应的 bmd_index。
        sorted_points 可传入预排序点，避免重复排序。"""
        if not calib:
            return -1
        if wave_id in calib:
            return calib[wave_id]
        if sorted_points is None:
            sorted_points = sorted(calib.items())
        prev_p = None
        next_p = None
        for w, b in sorted_points:
            if w <= wave_id:
                prev_p = (w, b)
            if w >= wave_id and next_p is None:
                next_p = (w, b)
        if prev_p and next_p and prev_p[0] != next_p[0]:
            ratio = (wave_id - prev_p[0]) / (next_p[0] - prev_p[0])
            return int(round(prev_p[1] + ratio * (next_p[1] - prev_p[1])))
        elif prev_p:
            return prev_p[1] + (wave_id - prev_p[0])
        elif next_p:
            return next_p[1] - (next_p[0] - wave_id)
        return -1

    def _get_calibrated_note(self, t):
        """返回该 voice track 的校准匹配台词（无用户标注时），用于列表显示。
        有用户标注或内置标注时返回 None（不覆盖）。台词截断到 32 字，详情面板看完整。"""
        if t.get("type") != "voice":
            return None
        g_wave = t.get("wave_id")
        if g_wave is not None:
            # 用 in 检查：即使用户清空为""也视为已设置，不显示校准匹配
            if self._has_user_note(t):
                return None
            if SPECIAL_TRACK_NOTES.get(g_wave):
                return None
        awb = str(t.get("awb_stem") or "")
        if not awb or self.text_matcher is None:
            return None
        wave_id = self._resolve_local_wave_id(t)
        if wave_id is None:
            return None
        all_texts = self.text_matcher.get_awb_texts(awb)
        if not all_texts:
            return None
        calib, calib_points = self._build_calibration(awb, all_texts)
        if len(calib) < 2:
            return None
        bmd_idx = self._infer_bmd_index(wave_id, calib, calib_points)
        if 0 <= bmd_idx < len(all_texts):
            m = all_texts[bmd_idx]
            name = (m.get("name", "") or "").strip()
            text = (m.get("text", "") or "").replace(chr(10), " ").strip()
            if text:
                prefix = f"{name}：" if name else ""
                full = f"{prefix}{text}"
                if len(full) > 32:
                    full = full[:32] + "…"
                return full
        return None

    def _get_extra_flow_text(self, awb_stem, wave_id):
        """返回流程语音（有语音但无 BMD 台词）的 AI 识别文本。
        返回 (jp, zh, cue) 或 None。awb_stem 不带扩展名，wave_id 为本地 wave 号。
        """
        if not self._extra_flow_text:
            return None
        awb = str(awb_stem or "").strip().upper()
        try:
            entry = self._extra_flow_text.get(awb, {})
            w = entry.get(f"wave{int(wave_id)}")
            if w:
                return w.get("jp", ""), w.get("zh", ""), w.get("cue", "")
        except Exception:
            pass
        return None

    def _build_jp_text_with_match(self, t):
        """构建日文原文参考文本（voice_text_correlation.json），并返回匹配到的台词行索引。
        复用中文台词的匹配结果（id 一致），定位到日文原文中对应的台词。
        返回 (text, matched_row)：matched_row = 匹配台词在文本中的 1-based 行号，无匹配 = -1
        """
        if self.text_matcher is None:
            return "（未加载日文原文库）", -1
        if t.get("type") != "voice":
            return "（该曲目非角色语音，无台词）", -1
        awb = str(t.get("awb_stem") or "")
        if not awb:
            return "（无法定位台词索引）", -1
        try:
            jp_texts = self.text_matcher.get_awb_jp_texts(awb)
        except Exception:
            jp_texts = []
        if not jp_texts:
            # 流程语音（无 BMD 台词文本）：显示 AI 识别文本作为参考
            try:
                _ef = self._get_extra_flow_text(awb, self._resolve_local_wave_id(t))
            except Exception:
                _ef = None
            if _ef:
                _jp, _zh, _cue = _ef
                _tag = "（流程语音·AI识别，无官方台词）"
                _txt = f"「{_jp}」\n中文参考：{_zh}" if _zh else f"「{_jp}」"
                return f"（{_tag}\n日文原文：{_txt}）", -1
            return "（该场景暂无日文原文库数据，可点击下方「AI 识别台词并翻译」获取日文原文）", -1

        # 优先使用 AI 识别日文原文的匹配结果（通过 id 关联）
        # 注意：用户有精确标注时，优先使用用户标注，不被 AI 匹配覆盖
        _user_has_note = False
        try:
            _user_has_note = self._has_user_note(t) and bool(self._get_track_note(t, "").strip())
        except Exception:
            pass
        matched_id = None
        try:
            wave_id = self._resolve_local_wave_id(t)
            awb_upper = awb.strip().upper()
            jp_cache = getattr(self, "_ai_match_jp_cache", {}) or {}
            if (awb_upper, wave_id) in jp_cache and not _user_has_note:
                _jpidx, jpid = jp_cache[(awb_upper, wave_id)]
                if jpid:
                    matched_id = jpid
            # AI 匹配未命中时，回退到 match_wave_texts
            if not matched_id:
                matched = self.text_matcher.match_wave_texts(awb, wave_id)
                if matched:
                    m0 = matched[0] if isinstance(matched, list) else matched
                    matched_id = m0.get("id")
        except Exception:
            pass

        # 构建日文原文列表，标记匹配的台词
        lines_out = []
        matched_row = -1
        for i, m in enumerate(jp_texts):
            name = m.get("name", "")
            text = (m.get("text", "") or "").replace("\n", " ").strip()
            if matched_id and m.get("id") == matched_id and matched_row == -1:
                matched_row = i + 2  # 第一行是说明行
            if len(text) > 40:
                text = text + "…"
            lines_out.append(f"[{i:02d}] {name}：{text}" if name else f"[{i:02d}] {text}")

        head = "\n".join(lines_out)
        note = "日文原文（绿色=匹配台词，与中文台词 id 对应）"
        total_lines = len(lines_out)
        more = f"\n…共 {total_lines} 段" if total_lines > 8 else ""
        return f"（{note}：\n{head}{more}）", matched_row

    def _build_subtitle_text_with_match(self, t):
        """构建中文台词参考文本（总是显示该场景完整台词列表），并返回匹配到的台词行索引。
        返回 (text, matched_row)：
          - matched_row = 匹配台词在文本中的 1-based 行号（第一行是说明行），无匹配 = -1
          调用方用 f"{row}.0" ~ f"{row+1}.0" 标记整行。
        """
        if self.text_matcher is None:
            return "（未加载中文台词库）", -1
        if t.get("type") != "voice":
            return "（该曲目非角色语音，无台词）", -1
        awb = str(t.get("awb_stem") or "")
        wave_id = self._resolve_local_wave_id(t)
        if not awb or wave_id is None:
            return "（无法定位台词索引）", -1
        try:
            all_texts = self.text_matcher.get_awb_texts(awb)
        except Exception:
            all_texts = []
        if not all_texts:
            # 流程语音（无 BMD 台词文本）：显示 AI 识别文本作为参考
            try:
                _ef = self._get_extra_flow_text(awb, wave_id)
            except Exception:
                _ef = None
            if _ef:
                _jp, _zh, _cue = _ef
                _tag = "（流程语音·AI识别，无官方台词）"
                _body = f"「{_jp}」" if _jp else ""
                if _zh:
                    _body += f"\n中文参考：{_zh}"
                return f"（{_tag}\n{_body}）", -1
            return "（该场景无中文台词）", -1

        # ===== 流程语音优先：该 wave 属无官方 BMD 台词的流程语音，且用户未手动标注 → 直接显示 AI 识别文本 =====
        try:
            _ef_early = self._get_extra_flow_text(awb, wave_id)
        except Exception:
            _ef_early = None
        if _ef_early:
            try:
                _has_note = self._has_user_note(t) and bool(self._get_track_note(t, "").strip())
            except Exception:
                _has_note = False
            if not _has_note:
                _jp, _zh, _cue = _ef_early
                _tag = "（流程语音·无官方台词，AI 识别参考）"
                _body = f"「{_jp}」" if _jp else ""
                if _zh:
                    _body += f"\n中文参考：{_zh}"
                _lines = []
                for _m in all_texts:
                    _n = _m.get("name", "")
                    _tx = _m.get("text", "").replace("\n", " ").strip()
                    if len(_tx) > 40:
                        _tx = _tx + "…"
                    _lines.append(f"[{_n}：{_tx}]" if _n else f"[{_tx}]")
                _ref = "\n".join(_lines) if _lines else "（无）"
                return f"（{_tag}\n{_body}\n\n— 该场景官方台词对照 —\n{_ref}）", -1

        # ===== AI 匹配优先：如果 AI 识别日文原文已匹配到 id，直接用它标记中文台词 =====
        # 注意：用户有精确标注时，优先使用用户标注，不被 AI 匹配覆盖；
        # 但校准匹配（线性插值）不应阻止 AI 匹配，因为一句话多语音时插值可能错误。
        _user_has_exact_note = False
        try:
            _user_has_exact_note = self._has_user_note(t) and bool(self._get_track_note(t, "").strip())
        except Exception:
            pass
        try:
            awb_upper = awb.strip().upper()
            jp_cache = getattr(self, "_ai_match_jp_cache", {}) or {}
            if (awb_upper, wave_id) in jp_cache and not _user_has_exact_note:
                _jpidx, ai_mid = jp_cache[(awb_upper, wave_id)]
                if ai_mid:
                    # 直接构建文本，用 AI 匹配的 id 标记
                    lines_out = []
                    ai_matched_row = -1
                    for i, m in enumerate(all_texts):
                        name = m.get("name", "")
                        text = m.get("text", "").replace("\n", " ").strip()
                        if m.get("id") == ai_mid and ai_matched_row == -1:
                            ai_matched_row = i + 2  # +2 因为第一行是说明行
                        if len(text) > 40:
                            text = text + "…"
                        lines_out.append(f"[{i:02d}] {name}：{text}" if name else f"[{i:02d}] {text}")
                    header = f"该场景共 {len(all_texts)} 句台词（AI日文匹配 id={ai_mid}，绿色=匹配台词）：\n"
                    content = header + "\n".join(lines_out)
                    print(f"[AI中文匹配] 使用AI匹配id={ai_mid}, 标记行={ai_matched_row}")
                    return content, ai_matched_row
        except Exception as _ai_e:
            print(f"[AI中文匹配] 优先匹配异常: {_ai_e}")

        # 用户明确清空了标注（key 存在但值为空字符串）→ 不使用校准匹配
        g_wave = t.get("wave_id")
        user_cleared = self._has_user_note(t) and self._get_track_note(t, "") == ""
        # ===== 校准匹配：利用用户已标注的台词推断当前 wave 的 BMD 台词 =====
        calib_bmd_idx = -1
        calib_count = 0
        is_calibrated_exact = False
        if not user_cleared:
            try:
                calib, calib_points = self._build_calibration(awb, all_texts)
                calib_count = len(calib)
            except Exception:
                calib, calib_points = {}, []
            if len(calib) >= 1:
                bmd_idx = self._infer_bmd_index(wave_id, calib, calib_points)
                if 0 <= bmd_idx < len(all_texts):
                    calib_bmd_idx = bmd_idx
                    is_calibrated_exact = (wave_id in calib)
        # 统计当前 AWB 的实际语音 track 数，判断匹配可靠性
        try:
            awb_track_count = sum(
                1 for v in self.voice_tracks
                if str(v.get("awb_stem", "")).upper() == awb.upper()
            )
        except Exception:
            awb_track_count = 0
        # 延迟注册：第一次查看该 AWB 台词时才解析 .msg（避免导入时批量解析变慢）
        try:
            self._ensure_msg_aligned(awb)
        except Exception:
            pass
        # 判断匹配可靠性：msg 对齐的 AWB（策略A f索引 / 策略B 顺序）均视为可靠
        awb_upper = awb.upper()
        _fidx_map = getattr(self.text_matcher, "msg_fidx_map", {}) or {}
        _seq_set = getattr(self.text_matcher, "msg_aligned_awb", set()) or set()
        is_msg_aligned = awb_upper in _fidx_map or awb_upper in _seq_set
        if is_msg_aligned:
            try:
                segs = self.text_matcher.get_msg_segments(awb)
                msg_seg_count = len(segs) if segs else 0
                # 策略A（f索引）：部分 wave 无语音属正常，只要该 wave 在映射中即可
                if awb_upper in _fidx_map:
                    reliable = (awb_track_count > 0)
                # 策略B（顺序）：语音数 == 段数 才可靠
                else:
                    reliable = (awb_track_count > 0 and awb_track_count == msg_seg_count)
            except Exception:
                reliable = False
        else:
            reliable = (awb_track_count > 0 and awb_track_count == len(all_texts))
        # 推测匹配
        try:
            matched = self.text_matcher.match_wave_texts(awb, wave_id)
        except Exception:
            matched = []
        # ===== 统一列表模式：总是显示该场景全部台词，匹配到的行标绿 =====
        lines_out = []
        matched_row = -1
        matched_text = ""
        # 确定匹配行（自动分割 msg_seg 优先，其次校准匹配 / 推测匹配）
        match_method = ""
        seg_index = -1
        if matched:
            mm = matched[0] if isinstance(matched, list) else matched
            match_method = mm.get("_match_method", "")
            seg_index = mm.get("_seg_index", -1)
        # 确定匹配文本来源（优先级：直接校准映射 > .msg自动分割 > 校准插值/外推 > 顺序对应）
        # 直接校准映射是用户手动确认的，优先于 .msg 自动分割
        use_msg_seg = False
        seg_msg_id = ""
        seg_text = ""
        has_direct_cal = False
        try:
            _cal_map = getattr(self.text_matcher, "calibrated_map", {}) or {}
            _awb_key = awb.strip().upper()
            if _awb_key in _cal_map and wave_id in _cal_map[_awb_key]:
                has_direct_cal = True
        except Exception:
            pass
        # 只有没有直接校准映射、且没有用户标注动态匹配时，才用 .msg 自动分割
        if not has_direct_cal and calib_bmd_idx < 0 and is_msg_aligned:
            use_msg_seg = True
            try:
                segs = self.text_matcher.get_msg_segments(awb)
                _fidx = getattr(self.text_matcher, "msg_fidx_map", {}) or {}
                if segs:
                    if awb.upper() in _fidx and wave_id in _fidx[awb.upper()]:
                        seg_idx = _fidx[awb.upper()][wave_id]
                    else:
                        seg_idx = wave_id
                    if 0 <= seg_idx < len(segs):
                        seg_msg_id = segs[seg_idx].get("msg_id", "")
                        seg_text = (segs[seg_idx].get("text", "") or "").strip()
            except Exception:
                use_msg_seg = False
        # ===== 快速反馈：AI 识别未完成时，避免显示可能错误的插值/推测结果 =====
        # 当无可靠匹配依据（无用户精确标注/直接校准/.msg精确分割/精确校准点），
        # 且 AI 识别尚未完成时，直接显示"AI识别匹配中..."占位，而不是先显示一个
        # 可能错误的台词再跳变，避免普通用户不明所以。
        try:
            _ai_done = False
            try:
                _ai_done = ((awb_upper, wave_id) in (getattr(self, "_ai_match_cache", {}) or {})) or \
                           ((awb_upper, wave_id) in (getattr(self, "_ai_match_jp_cache", {}) or {}))
            except Exception:
                _ai_done = False
            _reliable_now = bool(_user_has_exact_note) or bool(has_direct_cal) or \
                            (calib_bmd_idx >= 0 and is_calibrated_exact) or \
                            (use_msg_seg and bool(seg_text))
            _path_ok = bool(t.get("path"))
            if _path_ok and (not _ai_done) and (not _reliable_now):
                # 触发后台识别（若尚未触发）
                try:
                    pending = getattr(self, "_ai_match_pending", None)
                    if pending is None:
                        pending = set()
                        self._ai_match_pending = pending
                    if (awb_upper, wave_id) not in pending:
                        pending.add((awb_upper, wave_id))
                        self._schedule_ai_match(t, awb_upper, wave_id, all_texts)
                except Exception:
                    pass
                # 显示全部台词 + 识别中提示（不标记绿色，避免误导）
                lines_out = []
                for i, m in enumerate(all_texts):
                    name = m.get("name", "")
                    text = m.get("text", "").replace("\n", " ").strip()
                    if len(text) > 40:
                        text = text + "…"
                    lines_out.append(f"[{i:02d}] {name}：{text}" if name else f"[{i:02d}] {text}")
                head = "\n".join(lines_out)
                total_lines = len(lines_out)
                more = f"\n…共 {total_lines} 段" if total_lines > 8 else ""
                note = "AI识别匹配中...（识别完成后绿色将自动更新）"
                return f"（{note}：\n{head}{more}）", -1
        except Exception as _ae:
            print(f"[台词显示] 快速反馈异常: {_ae}")

        if use_msg_seg and seg_text:
            # 自动分割：把多段文本拆成多行，定位到当前段
            try:
                line_no = 1  # 第一行是说明行
                for m in all_texts:
                    name = m.get("name", "")
                    full = (m.get("text", "") or "").strip()
                    # 按换行拆成多段
                    parts = [p.strip() for p in full.split("\n") if p.strip()]
                    if not parts:
                        parts = [full] if full else []
                    for pi, part in enumerate(parts):
                        line_no += 1
                        if m.get("id") == seg_msg_id and part == seg_text:
                            matched_row = line_no
                        if len(part) > 40:
                            part = part + "…"
                        prefix = f"[{m.get('id','')}] " if len(parts) > 1 else f"[{all_texts.index(m):02d}] "
                        lines_out.append(f"{prefix}{name}：{part}" if name else f"{prefix}{part}")
            except Exception:
                pass
        elif has_direct_cal:
            # 直接校准映射（从 wave_text_calibration.json 加载，用户手动确认，优先于线性插值）
            try:
                _cal_map = getattr(self.text_matcher, "calibrated_map", {}) or {}
                _awb_k = awb.strip().upper()
                cal_idx = _cal_map.get(_awb_k, {}).get(wave_id, -1)
                if 0 <= cal_idx < len(all_texts):
                    matched_row = cal_idx + 2  # 第一行是说明行
                for i, m in enumerate(all_texts):
                    name = m.get("name", "")
                    text = m.get("text", "").replace("\n", " ").strip()
                    if len(text) > 40:
                        text = text + "…"
                    lines_out.append(f"[{i:02d}] {name}：{text}" if name else f"[{i:02d}] {text}")
            except Exception:
                pass
        elif calib_bmd_idx >= 0:
            # 基于用户最新标注的动态匹配（线性插值/外推，仅当无直接校准映射时使用）
            matched_row = calib_bmd_idx + 2  # 第一行是说明行
            for i, m in enumerate(all_texts):
                name = m.get("name", "")
                text = m.get("text", "").replace("\n", " ").strip()
                if len(text) > 40:
                    text = text + "…"
                lines_out.append(f"[{i:02d}] {name}：{text}" if name else f"[{i:02d}] {text}")
        elif matched and reliable:
            m0 = matched[0] if isinstance(matched, list) else matched
            matched_text = (m0.get("text", "") or "").strip()
            matched_mid = m0.get("id")
            # 优先使用 AI 匹配的 id（如果存在）
            try:
                awb_upper = awb.strip().upper()
                jp_cache = getattr(self, "_ai_match_jp_cache", {}) or {}
                if (awb_upper, wave_id) in jp_cache:
                    _jpidx, ai_mid = jp_cache[(awb_upper, wave_id)]
                    if ai_mid:
                        matched_mid = ai_mid
            except Exception:
                pass
            for i, m in enumerate(all_texts):
                name = m.get("name", "")
                text = m.get("text", "").replace("\n", " ").strip()
                # 优先按 id 匹配，其次按文本匹配
                if matched_mid and m.get("id") == matched_mid and matched_row == -1:
                    matched_row = i + 2
                elif matched_text and text == matched_text and matched_row == -1:
                    matched_row = i + 2
                if len(text) > 40:
                    text = text + "…"
                lines_out.append(f"[{i:02d}] {name}：{text}" if name else f"[{i:02d}] {text}")
        else:
            # ===== AI 识别 + 模糊匹配兜底（无用户标注/校准/可靠推测时）=====
            ai_match_idx = -1
            ai_pending = False
            ai_cache_key = (awb_upper, wave_id)
            try:
                if self._ai_match_cache is None:
                    self._ai_match_cache = {}
                if ai_cache_key in self._ai_match_cache:
                    ai_match_idx = self._ai_match_cache[ai_cache_key]
                else:
                    # 未缓存 → 启动后台识别（仅角色语音且路径存在）
                    _p = t.get("path")
                    if _p:
                        ai_pending = True
                        self._schedule_ai_match(t, awb_upper, wave_id, all_texts)
            except Exception as _e:
                print("[AI匹配] 初始化异常: %s" % _e)
            for i, m in enumerate(all_texts):
                name = m.get("name", "")
                text = m.get("text", "").replace("\n", " ").strip()
                if i == ai_match_idx:
                    matched_row = i + 2
                if len(text) > 40:
                    text = text + "…"
                lines_out.append(f"[{i:02d}] {name}：{text}" if name else f"[{i:02d}] {text}")
        head = "\n".join(lines_out)
        # 说明文字根据匹配类型调整
        if user_cleared:
            note = "用户已清空标注"
        elif use_msg_seg:
            note = "自动分割（绿色为当前语音台词，已按 .msg 精确对齐）"
        elif has_direct_cal:
            note = "已校准（绿色为当前语音台词，用户手动确认映射）"
        elif calib_bmd_idx >= 0:
            tag = "已校准" if is_calibrated_exact else "校准匹配"
            note = f"{tag}（绿色为当前语音台词，校准点 {calib_count} 个）"
        elif matched and reliable:
            note = "推测匹配（绿色为当前语音台词）"
        elif ai_pending:
            note = "AI识别匹配中...（识别完成后绿色将自动更新）"
        elif ai_match_idx >= 0:
            note = "AI识别匹配（绿色为AI识别的当前语音台词，仅供参考）"
        elif not reliable:
            note = "音频顺序可能与台词不一致，供对照"
        else:
            note = "未找到匹配，供对照"
        total_lines = len(lines_out)
        more = f"\n…共 {total_lines} 段，点「编辑标注」看全部" if total_lines > 8 else ""
        # 当前 wave 无可靠匹配且属于流程语音（无官方 BMD 台词）时，附加 AI 识别提示
        if matched_row < 0:
            try:
                _ef = self._get_extra_flow_text(awb, wave_id)
            except Exception:
                _ef = None
            if _ef:
                _jp, _zh, _cue = _ef
                _ef_head = "（当前语音为流程语音·无官方台词，AI 识别参考）"
                _ef_body = f"「{_jp}」" if _jp else ""
                if _zh:
                    _ef_body += f"\n中文参考：{_zh}"
                return f"（{_ef_head}\n{_ef_body}\n\n— 该场景官方台词对照 —\n{head}{more}）", -1
        return f"（{note}：\n{head}{more}）", matched_row

    # ==================== AI 识别 + 模糊匹配（绿色标记兜底）====================

    def _fuzzy_match_ai_translation(self, zh_text, all_texts):
        """AI 翻译中文 → 中文台词模糊匹配，返回 (best_idx, best_score)"""
        if not zh_text or not all_texts:
            return -1, 0.0
        try:
            import difflib
        except Exception:
            return -1, 0.0
        best_idx = -1
        best_score = 0.0
        zh_clean = zh_text.replace("\n", " ").strip()
        if not zh_clean:
            return -1, 0.0
        for i, m in enumerate(all_texts):
            t_text = (m.get("text", "") or "").strip()
            if not t_text:
                continue
            # 分段匹配：台词可能含多段（换行），每段单独匹配取最高分
            segments = [s.strip() for s in t_text.split("\n") if s.strip()]
            if not segments:
                segments = [t_text]
            r = 0.0
            for seg in segments:
                r = max(r, difflib.SequenceMatcher(None, zh_clean, seg).ratio())
            if r > best_score:
                best_score = r
                best_idx = i
        return best_idx, best_score

    def _fuzzy_match_jp_text(self, jp_text, jp_texts):
        """AI 识别日文原文 → 日文原文列表模糊匹配，返回 (best_idx, best_score, matched_id)
        改进：预处理文本（去除标点空格）、长度惩罚、多段匹配取最高分、调试输出
        """
        if not jp_text or not jp_texts:
            return -1, 0.0, None
        try:
            import difflib
            import re
        except Exception:
            return -1, 0.0, None

        def _normalize_jp(text):
            """日文文本预处理：去除标点、空格、换行、数字，只保留假名和汉字"""
            if not text:
                return ""
            # 去除常见日文标点和符号
            text = re.sub(r'[\s\n\r\t]', '', text)
            text = re.sub(r'[、。！？!?.,;:：；""''「」『』【】（）()\[\]\-—…·]', '', text)
            return text.strip()

        best_idx = -1
        best_score = 0.0
        best_id = None
        jp_norm = _normalize_jp(jp_text)
        if not jp_norm:
            return -1, 0.0, None
        jp_len = len(jp_norm)

        # 调试：收集所有匹配分数，输出 top3
        all_scores = []
        for i, m in enumerate(jp_texts):
            t_text = (m.get("text", "") or "").strip()
            if not t_text:
                continue
            segments = [s.strip() for s in t_text.split("\n") if s.strip()]
            if not segments:
                segments = [t_text]
            r = 0.0
            for seg in segments:
                seg_norm = _normalize_jp(seg)
                if not seg_norm:
                    continue
                # 基础相似度
                base = difflib.SequenceMatcher(None, jp_norm, seg_norm).ratio()
                # 长度惩罚：长度差异越大，分数越低
                seg_len = len(seg_norm)
                len_ratio = min(jp_len, seg_len) / max(jp_len, seg_len) if max(jp_len, seg_len) > 0 else 0
                # 综合分数：基础相似度 * 长度系数（长度差异超过50%的大幅降权）
                if len_ratio >= 0.7:
                    score = base
                elif len_ratio >= 0.5:
                    score = base * 0.8
                else:
                    score = base * 0.5
                r = max(r, score)
            if r > 0:
                all_scores.append((i, r, m.get("id"), t_text[:30]))
            if r > best_score:
                best_score = r
                best_idx = i
                best_id = m.get("id")

        # 调试输出：top3 匹配
        if all_scores:
            all_scores.sort(key=lambda x: x[1], reverse=True)
            top3 = all_scores[:3]
            debug_str = " | ".join([f"idx={s[0]} score={s[1]:.3f} id={s[2]} text={s[3]}" for s in top3])
            _inp = jp_text[:40]
            print(f"[AI日文匹配] 输入={_inp} 最佳idx={best_idx} score={best_score:.3f} id={best_id}")
            print(f"[AI日文匹配] Top3: {debug_str}")

        return best_idx, best_score, best_id

    def _schedule_ai_match(self, t, awb_upper, wave_id, all_texts):
        """后台线程：AI 识别 + 翻译 + 模糊匹配，结果缓存后刷新绿色标记"""
        try:
            if getattr(self, "_ai_match_busy", False):
                # 正在识别 → 记录等待目标，识别完成后自动续跑
                self._ai_match_waiting = (t, awb_upper, wave_id, all_texts)
                return
            self._ai_match_busy = True
            path = t.get("path")
            if not path:
                self._ai_match_busy = False
                return
            import os
            if not os.path.exists(str(path)):
                self._ai_match_busy = False
                return

            def work():
                try:
                    matched_idx = -1
                    matched_jp_idx = -1
                    matched_id = None
                    try:
                        import voice_ai
                        if voice_ai.is_available():
                            _ctx = {"awb": awb_upper, "wave_id": wave_id}
                            res = voice_ai.transcribe_adx(path, language="ja", context=_ctx)
                            if res.get("ok"):
                                jp_text = (res.get("jp") or "").strip()
                                zh_text = (res.get("zh") or "").strip()
                                # 优先用日文原文匹配日文原文列表，通过 id 关联中文
                                if jp_text and self.text_matcher is not None:
                                    try:
                                        jp_texts = self.text_matcher.get_awb_jp_texts(awb_upper)
                                        if jp_texts:
                                            jp_idx, jp_score, mid = self._fuzzy_match_jp_text(jp_text, jp_texts)
                                            if jp_score >= 0.5 and mid:
                                                matched_jp_idx = jp_idx
                                                matched_id = mid
                                                # 通过 id 在中文台词列表中找到对应索引
                                                for ci, cm in enumerate(all_texts):
                                                    if cm.get("id") == mid:
                                                        matched_idx = ci
                                                        break
                                    except Exception as _je:
                                        print("[AI匹配] 日文匹配异常: %s" % _je)
                                # 日文匹配失败时，回退到中文翻译匹配
                                if matched_idx < 0 and zh_text:
                                    idx, score = self._fuzzy_match_ai_translation(zh_text, all_texts)
                                    if score >= 0.5:
                                        matched_idx = idx
                    except Exception as _e:
                        print("[AI匹配] 识别异常: %s" % _e)
                    # 缓存结果（-1 也缓存，避免重复识别）
                    try:
                        if self._ai_match_cache is None:
                            self._ai_match_cache = {}
                        self._ai_match_cache[(awb_upper, wave_id)] = matched_idx
                        # 同时缓存日文匹配索引和 id，供编辑标注对话框使用
                        if not hasattr(self, "_ai_match_jp_cache") or self._ai_match_jp_cache is None:
                            self._ai_match_jp_cache = {}
                        self._ai_match_jp_cache[(awb_upper, wave_id)] = (matched_jp_idx, matched_id)
                    except Exception:
                        pass
                    # 回调主线程刷新绿色标记
                    try:
                        self.root.after(0, lambda: self._on_ai_match_done(t, awb_upper, wave_id))
                    except Exception:
                        pass
                finally:
                    self._ai_match_busy = False
                    # 若有等待目标，续跑
                    w = self._ai_match_waiting
                    if w is not None:
                        self._ai_match_waiting = None
                        try:
                            self.root.after(0, lambda: self._schedule_ai_match(w[0], w[1], w[2], w[3]))
                        except Exception:
                            pass

            import threading
            threading.Thread(target=work, daemon=True).start()
        except Exception as _e:
            print("[AI匹配] 调度异常: %s" % _e)
            self._ai_match_busy = False

    def _on_ai_match_done(self, t, awb_upper, wave_id):
        """AI 匹配完成后刷新当前曲目的台词显示（仅当仍是当前选中曲目）"""
        try:
            # 清理 pending 标记（无论匹配成功与否）
            try:
                pending = getattr(self, "_ai_match_pending", None)
                if pending is not None:
                    pending.discard((awb_upper, wave_id))
            except Exception:
                pass
            # 用 wave_id + awb 比较当前选中曲目（避免对象引用 is 比较失败）
            cur = getattr(self, "current_track", None)
            if cur is not None:
                cur_awb = str(cur.get("awb_stem", "")).strip().upper()
                cur_wid = self._resolve_local_wave_id(cur)
                if cur_awb == awb_upper and cur_wid == wave_id:
                    self._update_text_matcher_display(cur)
            # 刷新编辑标注对话框的绿色标记（如果对话框还开着）
            refs = getattr(self, "_note_dialog_refs", None)
            if refs and refs.get("awb") == awb_upper and refs.get("wave_id") == wave_id:
                try:
                    win = refs.get("win")
                    jp_text = refs.get("jp_text")
                    sub_text = refs.get("sub_text")
                    if win and win.winfo_exists():
                        # 刷新日文原文绿色标记
                        try:
                            jp_content, jp_matched = self._build_jp_text_with_match(t)
                            jp_text.delete("1.0", END)
                            jp_text.insert(END, jp_content)
                            if jp_matched >= 0:
                                jp_text.tag_add("match", f"{jp_matched}.0", f"{jp_matched + 1}.0")
                                jp_text.tag_config("match", foreground="#2E7D32", font=("MS Gothic", 9, "bold"))
                        except Exception as _je:
                            print("[AI匹配] 刷新日文标记异常: %s" % _je)
                        # 刷新中文台词绿色标记
                        try:
                            sub_content, sub_matched = self._build_subtitle_text_with_match(t)
                            sub_text.delete("1.0", END)
                            sub_text.insert(END, sub_content)
                            if sub_matched >= 0:
                                sub_text.tag_add("match", f"{sub_matched}.0", f"{sub_matched + 1}.0")
                                sub_text.tag_config("match", foreground="#2E7D32", font=("Microsoft YaHei", 9, "bold"))
                        except Exception as _se:
                            print("[AI匹配] 刷新中文标记异常: %s" % _se)
                except Exception as _we:
                    print("[AI匹配] 刷新对话框异常: %s" % _we)
        except Exception as _e:
            print("[AI匹配] 刷新异常: %s" % _e)

    def _register_msg_aligned_voices(self, voice_list):
        """轻量记录每个角色语音 AWB 的 wave_ids 集合（延迟注册，不解析 .msg）。
        实际的 .msg 解析在第一次查看该 AWB 台词时由 _ensure_msg_aligned 触发，
        避免导入时批量解析几百个 .msg 文件导致速度变慢。
        记录实际 wave_id 集合（而非仅数量），用于 f 索引偏移量自动检测。
        """
        if not voice_list:
            return
        try:
            awb_wave_ids = {}
            for t in voice_list:
                awb = str(t.get("awb_stem", "")).upper()
                if not awb:
                    continue
                ri = t.get("real_index")
                if ri is None:
                    ri = t.get("wave_id")
                if ri is not None:
                    try:
                        awb_wave_ids.setdefault(awb, set()).add(int(ri))
                    except (TypeError, ValueError):
                        pass
            self._voice_awb_wave_ids = awb_wave_ids
            self._voice_awb_wave_counts = {awb: len(s) for awb, s in awb_wave_ids.items()}
            print(f"[msg对齐] 已记录 {len(awb_wave_ids)} 个语音 AWB 的 wave_ids（延迟解析 .msg）")
        except Exception as e:
            print(f"[msg对齐] 记录异常: {e}")

    def _ensure_msg_aligned(self, awb):
        """延迟注册：第一次查看某 AWB 台词时才解析 .msg 并注册对齐。
        返回 True 表示该 AWB 已对齐（策略A或B），False 表示未对齐。
        """
        if not hasattr(self, '_voice_awb_wave_counts'):
            self._voice_awb_wave_counts = {}
        awb_upper = awb.upper()
        _fidx = getattr(self.text_matcher, "msg_fidx_map", {}) or {}
        _seq = getattr(self.text_matcher, "msg_aligned_awb", set()) or set()
        if awb_upper in _fidx or awb_upper in _seq:
            return True
        wave_ids = getattr(self, '_voice_awb_wave_ids', {}).get(awb_upper)
        wave_count = self._voice_awb_wave_counts.get(awb_upper)
        if wave_count is None or wave_ids is None:
            # 未记录过，尝试从 voice_tracks 统计
            try:
                wave_ids = set()
                for v in self.voice_tracks:
                    if str(v.get("awb_stem", "")).upper() == awb_upper:
                        ri = v.get("real_index")
                        if ri is None:
                            ri = v.get("wave_id")
                        if ri is not None:
                            try:
                                wave_ids.add(int(ri))
                            except (TypeError, ValueError):
                                pass
                wave_count = len(wave_ids)
            except Exception:
                wave_ids = set()
                wave_count = 0
        if wave_count <= 0:
            return False
        try:
            return self.text_matcher.register_msg_aligned_awb(awb_upper, wave_count, wave_ids=wave_ids)
        except Exception as e:
            print(f"[msg对齐] {awb_upper} 延迟注册异常: {e}")
            return False

    def _build_subtitle_text(self, t) -> str:
        """构建当前曲目的中文台词参考文本（角色语音）。返回纯文本字符串。"""
        text, _ = self._build_subtitle_text_with_match(t)
        return text


    def _update_text_matcher_display(self, t):
        """根据当前曲目更新中文台词显示（角色语音，SC.CPK 台词库），匹配到的台词行标记为绿色"""
        try:
            if not hasattr(self, 'subtitle_text'):
                return
            text, matched_idx = self._build_subtitle_text_with_match(t)
            self.subtitle_text.config(state=NORMAL)
            self.subtitle_text.delete("1.0", END)
            self.subtitle_text.insert(END, text)
            # 清理旧标记
            self.subtitle_text.tag_remove("match", "1.0", END)
            # 标记匹配行为绿色（matched_row 为 1-based 行号）
            if matched_idx >= 0:
                try:
                    start = f"{matched_idx}.0"
                    end = f"{matched_idx + 1}.0"
                    self.subtitle_text.tag_add("match", start, end)
                except Exception:
                    pass
            self.subtitle_text.tag_config("match", foreground="#2E7D32",
                                          font=("Microsoft YaHei", 9, "bold"))
            self.subtitle_text.config(state=DISABLED)
        except Exception as e:
            print(f"[台词显示] 刷新异常: {e}")

        # ---- 主动触发 AI 识别匹配（角色语音，缓存不存在时）----
        try:
            if t.get("type") != "voice":
                return
            awb = str(t.get("awb_stem", "")).strip().upper()
            wave_id = self._resolve_local_wave_id(t)
            if not awb or wave_id is None:
                return
            # 检查缓存是否已存在
            jp_cache = getattr(self, "_ai_match_jp_cache", {}) or {}
            if (awb, wave_id) in jp_cache:
                return
            # 检查是否正在匹配（避免重复触发）
            pending = getattr(self, "_ai_match_pending", None)
            if pending is None:
                pending = set()
                self._ai_match_pending = pending
            if (awb, wave_id) in pending:
                return
            # 获取中文台词列表
            all_texts = []
            if self.text_matcher is not None:
                all_texts = self.text_matcher.get_awb_texts(awb) or []
            if not all_texts:
                return
            # 标记为正在匹配
            pending.add((awb, wave_id))
            # 主动触发 AI 识别匹配（后台线程，匹配完成后 _on_ai_match_done 自动刷新）
            self._schedule_ai_match(t, awb, wave_id, all_texts)
        except Exception as _e:
            print(f"[主界面AI匹配] 触发异常: {_e}")


    def _compute_sfx_hashes_async(self):
        """后台线程计算音效文件 SHA256 哈希，用于识别一模一样的音频。
        优化：先按文件大小分组，只有同大小（可能重复）的文件才计算完整哈希，
        大小唯一的文件不可能重复，直接跳过（大幅减少读盘与哈希计算量）。"""
        def work():
            import hashlib
            try:
                total = len(self.sfx_tracks)
                # 1) 按文件大小分组（含缺失文件处理）
                size_groups = {}
                missing = []
                for t in self.sfx_tracks:
                    p = t.get("original_path") or t.get("path")
                    if p and os.path.exists(p):
                        try:
                            sz = os.path.getsize(p)
                            size_groups.setdefault(sz, []).append(t)
                        except Exception:
                            missing.append(t)
                    else:
                        missing.append(t)
                # 2) 大小唯一的文件直接跳过（不可能重复）
                for t in missing:
                    t["dup_hash"] = None
                candidates = []
                for sz, ts in size_groups.items():
                    if len(ts) > 1:
                        candidates.extend(ts)
                    else:
                        ts[0]["dup_hash"] = None
                # 3) 只对候选文件算完整哈希
                total_cand = len(candidates)
                for i, t in enumerate(candidates):
                    p = t.get("original_path") or t.get("path")
                    try:
                        h = hashlib.sha256()
                        with open(p, 'rb') as f:
                            for chunk in iter(lambda: f.read(65536), b''):
                                h.update(chunk)
                        t["dup_hash"] = h.hexdigest()
                    except Exception:
                        t["dup_hash"] = None
                    if i % 50 == 0:
                        self.root.after(0, lambda v=(i, total_cand): self._update_status(
                            f"正在检测重复音效 {v[0]}/{v[1]}..."))
                self.root.after(0, self._build_sfx_groups_and_refresh)
            except Exception as e:
                print(f"[重复检测] 失败: {e}")
                self.root.after(0, lambda: setattr(self, 'sfx_hash_ready', True))
        threading.Thread(target=work, daemon=True).start()
    def _build_sfx_groups_and_refresh(self):
        """构建重复分组并刷新列表"""
        groups = {}
        for t in self.sfx_tracks:
            h = t.get("dup_hash")
            if h:
                groups.setdefault(h, []).append(t)
        # 只保留重复(>1)的组
        self.sfx_dup_groups = {h: ts for h, ts in groups.items() if len(ts) > 1}
        # 新发现的重复组默认折叠
        if not hasattr(self, 'sfx_collapsed'):
            self.sfx_collapsed = set()
        for h in self.sfx_dup_groups:
            if h not in self.sfx_collapsed:
                self.sfx_collapsed.add(h)
        self.sfx_hash_ready = True
        dup_files = sum(len(ts) - 1 for ts in self.sfx_dup_groups.values())
        if self.sfx_dup_groups:
            self._update_status(f"重复检测完成：{len(self.sfx_dup_groups)} 组重复音效，共折叠 {dup_files} 个")
        else:
            self._update_status("重复检测完成：未发现完全相同的音效")
        # 按钮文字
        if hasattr(self, 'sfx_dedup_btn'):
            self.sfx_dedup_btn.config(text="⤴ 展开重复" if not self.sfx_collapsed else "⤵ 折叠重复")
        self.refresh_track_list()

    def _toggle_sfx_dedup(self):
        """切换音效重复折叠的全局展开/折叠状态"""
        if not self.sfx_hash_ready:
            self._compute_sfx_hashes_async()
            return
        if self.sfx_collapsed:
            self.sfx_collapsed.clear()  # 全部展开
            self.sfx_dedup_btn.config(text="⤵ 折叠重复")
        else:
            self.sfx_collapsed = set(self.sfx_dup_groups.keys())  # 全部折叠
            self.sfx_dedup_btn.config(text="⤴ 展开重复")
        self.refresh_track_list()

    def _filter_tracks(self):
        """按角色筛选/音效空槽位/搜索/分类过滤当前 tracks，返回过滤后的列表。
        refresh_track_list 和 on_track_select 共用，保证列表显示与点击选中的索引一致。
        """
        import re
        search = self.search_var.get().lower()
        category = self.category_var.get()
        voice_filter = self.voice_filter_var.get() if self.current_audio_type == "voice" else "全部语音"
        filtered = []
        for t in self.tracks:
            # 角色语音按角色/类别筛选
            if self.current_audio_type == "voice" and voice_filter != "全部语音":
                awb = t.get("awb_stem", "").upper()
                if not self._voice_matches_filter(awb, voice_filter):
                    continue
            # 音效空槽位过滤：默认隐藏占位符（is_placeholder=True）
            if self.current_audio_type == "sfx" and not self.show_placeholder_sfx:
                if t.get("is_placeholder"):
                    continue
            # 搜索过滤
            if search:
                if search not in t["name"].lower() and search not in str(t["wave_id"]):
                    continue
            # 分类过滤
            if category == "已替换":
                if not t.get("replaced"):
                    continue
            elif category == "未知":
                if is_known_track(t["wave_id"]):
                    continue
            elif category != "全部":
                cat_ids = BGM_CATEGORIES.get(category, [])
                if t["wave_id"] not in cat_ids:
                    continue
            filtered.append(t)
        return filtered

    def _insert_track_row(self, t, indent=False, group_tag=""):
        """向列表插入单条曲目行（供 refresh_track_list 调用）"""
        try:
            self._insert_track_row_inner(t, indent, group_tag)
        except Exception as e:
            # 单个曲目渲染失败不中断整个列表，打印调试信息
            print(f"[列表渲染失败] wave_id={t.get('wave_id')} name={t.get('name')!r} type={t.get('type')} err={e}")
            try:
                safe_name = str(t.get('name', '?'))[:40]
                self.track_listbox.insert(END, f"  {t.get('wave_id','?')}  {safe_name}  [渲染失败]")
                self.track_listbox.itemconfig(END, fg="#FF0000")
            except Exception:
                pass

    def _insert_track_row_inner(self, t, indent=False, group_tag=""):
        """向列表插入单条曲目行（实际渲染逻辑）。group_tag 为重复组号标记如 [组1]"""
        status = " [已替换]" if t.get("replaced") else ""
        # non-streaming ACB（SYSTEM/VOICE_SINGLEWORD/TITLE 等）标记 [Ryo]，导出用 Ryo Framework
        if t.get("is_non_streaming"):
            status += " [Ryo]"
        # 类型：bgm / sfx / voice
        track_type = t.get("type", "bgm")
        # 额外BGM（非主BGM的 bgm 类型）不显示"?"未知标记
        # 音效和语音也不显示"?"
        is_extra = (track_type == "bgm") and t["wave_id"] >= 10000
        is_voice = (track_type == "voice")
        is_placeholder = t.get("is_placeholder", False)
        known_mark = "" if (is_known_track(t["wave_id"]) or is_extra or track_type != "bgm") else " ?"
        # 空槽位前缀标记
        placeholder_mark = "【空槽位】" if is_placeholder else ""
        # 组号标记（如 [组1]）+ 组内成员 └ 前缀
        group_mark = f"{group_tag} " if group_tag else ""
        indent_mark = group_mark + ("  └ " if indent else "")
        if t.get("replaced"):
            # 已替换：原曲名 [已替换] → 新曲名（名称超长可横向滚动查看完整）
            new_name = t.get("replaced_name", "") or Path(t.get("replaced_path", "")).stem
            line = f"{indent_mark}{t['wave_id']:05d}  {placeholder_mark}{t['name'][:40]:<40}{status} → {new_name[:45]}{known_mark}"
            self.track_listbox.insert(END, line)
            self.track_listbox.itemconfig(END, fg="#2E7D32")  # 绿色
        elif is_placeholder:
            line = f"{indent_mark}{t['wave_id']:05d}  {placeholder_mark}{t['name'][:45]:<45}{status}{known_mark}"
            self.track_listbox.insert(END, line)
            self.track_listbox.itemconfig(END, fg="#9E9E9E")  # 灰色
        elif is_voice:
            is_base_cutscene = t.get("source_cpk") == "BASE"
            source_mark = "[过场] " if is_base_cutscene else ""
            # 只显示用户手动标注
            if self._has_user_note(t):
                special_note = self._get_track_note(t, "")
            else:
                special_note = ""
            note_str = f" {special_note}" if special_note else ""
            # 列表只显示手动标注，不显示校准匹配的自动台词参考
            line = f"{indent_mark}{t['wave_id']:05d}  {source_mark}{t['name'][:43]:<43}{status}{note_str}{known_mark}"
            self.track_listbox.insert(END, line)
            if is_base_cutscene:
                self.track_listbox.itemconfig(END, fg="#1565C0")  # 蓝紫色（BASE过场音频）
            else:
                self.track_listbox.itemconfig(END, fg="#7B1FA2")  # 紫色（SOUND_J日文配音）
        elif is_extra:
            line = f"{indent_mark}{t['wave_id']:05d}  {t['name'][:45]:<45}{status}{known_mark}"
            self.track_listbox.insert(END, line)
            self.track_listbox.itemconfig(END, fg="#E65100")  # 橙色
        else:
            line = f"{indent_mark}{t['wave_id']:05d}  {t['name'][:45]:<45}{status}{known_mark}"
            self.track_listbox.insert(END, line)

    def refresh_track_list(self, select_wave_id=None, select_awb=None):
        """刷新曲目列表（根据搜索和筛选），音效支持重复折叠。
        select_wave_id 传入时，刷新后自动选中该 wave_id 并滚动到可见位置；
        同一 wave_id 可能出现在多个 AWB 中，可再传 select_awb 精确定位。"""
        self.track_listbox.delete(0, END)
        filtered = self._filter_tracks()
        # 显示行映射（与 Listbox 行一一对应），供 on_track_select 使用
        self._display_rows = []

        # 音效 tab 且已启用折叠且哈希已计算 → 应用重复折叠
        if (self.current_audio_type == "sfx" and self.sfx_dedup_enabled
                and self.sfx_hash_ready and self.sfx_dup_groups):
            seen_hashes = set()
            group_numbers = {}  # hash -> 组号（按首次出现顺序分配）
            next_group_num = 1
            for t in filtered:
                h = t.get("dup_hash")
                if h and h in self.sfx_dup_groups:
                    # 分配组号（首次出现时分配）
                    if h not in group_numbers:
                        group_numbers[h] = next_group_num
                        next_group_num += 1
                    gtag = f"[组{group_numbers[h]}]"
                    # 重复组的非第一个成员：跳过（展开态聚集在组头后，折叠态隐藏）
                    if h in seen_hashes:
                        continue
                    seen_hashes.add(h)
                    # 组头行：用 group_head 类型（点击可切换折叠）
                    self._display_rows.append(("group_head", h, t))
                    cnt = len(self.sfx_dup_groups[h])
                    rep_cnt = sum(1 for x in self.sfx_dup_groups[h] if x.get("replaced"))
                    extra = f"，含{rep_cnt}已替换" if rep_cnt else ""
                    status = " [已替换]" if t.get("replaced") else ""
                    if t.get("is_non_streaming"):
                        status += " [Ryo]"
                    if h in self.sfx_collapsed:
                        # 折叠态：只显示组头
                        line = f"{gtag} ▶ [×{cnt}{extra}] {t['wave_id']:05d}  {t['name'][:34]:<34}{status}"
                        self.track_listbox.insert(END, line)
                        self.track_listbox.itemconfig(END, fg="#D32F2F")
                    else:
                        # 展开态：显示组头 + 该组所有成员（聚集在一起）
                        line = f"{gtag} ▼ [×{cnt}] {t['wave_id']:05d}  {t['name'][:34]:<34}{status}"
                        self.track_listbox.insert(END, line)
                        self.track_listbox.itemconfig(END, fg="#D32F2F")
                        # 聚集显示该组所有成员（跳过组头本身）
                        for member in self.sfx_dup_groups[h]:
                            if member is t:
                                continue
                            self._display_rows.append(("track", None, member))
                            self._insert_track_row(member, indent=True, group_tag=gtag)
                else:
                    self._display_rows.append(("track", None, t))
                    self._insert_track_row(t)
        else:
            for t in filtered:
                self._display_rows.append(("track", None, t))
                self._insert_track_row(t)

        # 实际插入的 listbox 行数
        actual_rows = self.track_listbox.size()
        # 曲目计数：音效 tab 显示真实音效数/空槽位数
        if self.current_audio_type == "sfx":
            real_count = sum(1 for t in self.tracks if not t.get("is_placeholder"))
            ph_count = sum(1 for t in self.tracks if t.get("is_placeholder"))
            self.track_count_var.set(f"曲目: {len(filtered)}/{len(self.tracks)}（真实音效 {real_count}，空槽位 {ph_count}）")
        else:
            self.track_count_var.set(f"曲目: {len(filtered)}/{len(self.tracks)}")

        # ---- 恢复选中（编辑标注保存/清空后，回到原曲目）----
        if select_wave_id is not None:
            try:
                target_idx = -1
                fallback_idx = -1
                for i, entry in enumerate(self._display_rows):
                    if entry[0] != "track":
                        continue
                    t = entry[2]
                    # 匹配 wave_id（int 比较，兼容 str）
                    tw = t.get("wave_id")
                    try:
                        if int(tw) == int(select_wave_id):
                            # 记录 fallback：仅按 wave_id 匹配的第一个
                            if fallback_idx < 0:
                                fallback_idx = i
                            # 若指定了 AWB，进一步精确匹配（同一 wave_id 可能存在于多个 AWB）
                            if select_awb is not None:
                                ta = str(t.get("awb_stem", "")).upper()
                                if ta == str(select_awb).upper():
                                    target_idx = i
                                    break
                            else:
                                target_idx = i
                                break
                    except (TypeError, ValueError):
                        continue
                # 精确匹配（wave_id+AWB）失败时，回退到仅按 wave_id 匹配
                if target_idx < 0 and fallback_idx >= 0:
                    target_idx = fallback_idx
                    print(f"[列表恢复选中] AWB精确匹配失败，回退到wave_id={select_wave_id} 行{fallback_idx}")
                if target_idx >= 0 and target_idx < self.track_listbox.size():
                    self.track_listbox.selection_clear(0, END)
                    self.track_listbox.selection_set(target_idx)
                    self.track_listbox.see(target_idx)
                    try:
                        self.track_listbox.activate(target_idx)
                    except Exception:
                        pass
                    # 手动刷新详情面板（selection_set 可能不触发 ListboxSelect）
                    kind, h, t = self._display_rows[target_idx]
                    self.current_track = t
                    self._refresh_detail_panel()
            except Exception as e:
                print(f"[列表恢复选中] 异常: {e}")

    def _toggle_group_fold(self, h):
        """切换折叠/展开，并保持列表滚动位置不跳回顶部"""
        # ---- 刷新前记录 ----
        anchor = None          # 视口顶部可见行对应的显示条目
        y_frac = 0.0           # 垂直滚动比例
        x_frac = 0.0           # 水平滚动比例
        try:
            y_frac = self.track_listbox.yview()[0]
            x_frac = self.track_listbox.xview()[0]
            top_row = self.track_listbox.index("@0,0")
            if 0 <= top_row < len(self._display_rows):
                entry = self._display_rows[top_row]
                if entry[0] == "group_head":
                    anchor = ("group_head", entry[1])
                else:
                    anchor = ("track", id(entry[2]))
        except Exception:
            pass

        # ---- 切换折叠并刷新 ----
        if h in self.sfx_collapsed:
            self.sfx_collapsed.discard(h)
        else:
            self.sfx_collapsed.add(h)
        self.refresh_track_list()
        try:
            self.track_listbox.update_idletasks()
        except Exception:
            pass

        # ---- 恢复滚动位置 ----
        try:
            # 1) 先按原比例恢复水平滚动
            self.track_listbox.xview_moveto(x_frac)
            # 2) 垂直：优先定位锚点行
            if anchor is not None:
                new_idx = None
                for i, entry in enumerate(self._display_rows):
                    if anchor[0] == "group_head":
                        if entry[0] == "group_head" and entry[1] == anchor[1]:
                            new_idx = i
                            break
                    else:
                        if entry[0] == "track" and id(entry[2]) == anchor[1]:
                            new_idx = i
                            break
                if new_idx is not None:
                    # 滚动使锚点行成为视口顶部可见行
                    total = self.track_listbox.size()
                    if total > 0:
                        frac = new_idx / total
                        frac = max(0.0, min(1.0, frac))
                        self.track_listbox.yview_moveto(frac)
                        return
            # 3) 锚点定位失败时：按原垂直比例恢复（内容变长会略有偏差但不会跳顶）
            self.track_listbox.yview_moveto(y_frac)
        except Exception:
            pass

    def on_track_click(self, event):
        """鼠标点击列表：
        - 点击组头行的 ▶/▼ 符号区域 → 切换展开/折叠
        - 点击组头行其他区域 → 作为普通行选中（显示该音频详情）
        - 点击普通行 → 默认选中行为
        """
        # 获取点击位置对应的行索引
        idx = self.track_listbox.nearest(event.y)
        if idx < 0 or idx >= len(self._display_rows):
            return
        kind, h, t = self._display_rows[idx]
        if kind == "group_head":
            # 判断点击是否落在 ▶/▼ 符号区域（行首的小范围）
            try:
                text = self.track_listbox.get(idx)
                sym_idx = text.find('▶')
                if sym_idx < 0:
                    sym_idx = text.find('▼')
                if sym_idx >= 0:
                    font = tkfont.Font(font=self.track_listbox.cget("font"))
                    sym_left = font.measure(text[:sym_idx])
                    sym_right = font.measure(text[:sym_idx + 1])
                    # 计算水平滚动偏移（listbox 有水平滚动条时）
                    try:
                        xstart, xend = self.track_listbox.xview()
                        vw = max(self.track_listbox.winfo_width(), 10)
                        content_w = vw / (xend - xstart) if xend > xstart else vw
                        xoff = xstart * content_w
                    except Exception:
                        xoff = 0
                    # 点击落在符号区域 → 切换折叠（保持滚动位置）
                    if sym_left - xoff - 2 <= event.x <= sym_right - xoff + 2:
                        self._toggle_group_fold(h)
                        # 阻止默认选中行为
                        return "break"
            except Exception:
                pass
            # 点击组头非符号区域：允许默认选中（on_track_select 显示详情）
            return
        # 普通行：允许默认选中（由 ListboxSelect 处理）

    def on_track_select(self, event):
        """选中曲目时更新详情"""
        selection = self.track_listbox.curselection()
        if not selection:
            return

        # 使用显示行映射（与 Listbox 行一一对应，折叠时索引不漂移）
        idx = selection[0]
        if idx >= len(self._display_rows):
            return

        kind, h, t = self._display_rows[idx]
        if kind == "group_head":
            # 点击组头非符号区域 → 显示该组第一个音频的详情
            self.current_track = t
            self._refresh_detail_panel()
            return

        self.current_track = t
        self._refresh_detail_panel()

    def _refresh_detail_panel(self):
        """根据 self.current_track 刷新右侧详情面板"""
        if not self.current_track:
            return
        try:
            t = self.current_track
            # 更新详情
            self.detail_id.set(f"{t['wave_id']:05d}")
            self.detail_name.set(str(t.get("name", "")))
            if t.get("replaced"):
                new_name = t.get("replaced_name", "") or Path(t.get("replaced_path", "")).stem
                self.detail_replaced_name.set(f"{new_name} ✓")
            else:
                self.detail_replaced_name.set("-")
            size_kb = t.get("size", 0) / 1024
            self.detail_size.set(f"{size_kb:.1f} KB")
            self.detail_path.set(str(t.get("path", "")))

            # 读取 ADX 信息
            try:
                info = get_adx_info(t["path"])
                self.detail_encrypted.set("是 (P5R加密)" if info["encrypted"] else "否")
                if info["duration"] > 0:
                    if info["duration"] < 1.0:
                        self.detail_duration.set(f"{info['duration']:.1f}秒")
                    else:
                        mins = int(info["duration"] // 60)
                        secs = int(info["duration"] % 60)
                        self.detail_duration.set(f"{mins}:{secs:02d}")
                else:
                    self.detail_duration.set("未知")
            except Exception as e:
                print(f"[详情面板] 读取ADX信息失败: {e}")
                self.detail_encrypted.set("未知")
                self.detail_duration.set("未知")

            # 启用按钮
            self.play_btn.config(state=NORMAL)
            self.stop_btn.config(state=NORMAL)
            self.replace_btn.config(state=NORMAL if self.replace_file_var.get() != "未选择文件" else DISABLED)
            self.restore_btn.config(state=NORMAL if t.get("replaced") else DISABLED)
            # 编辑标注按钮：选中曲目后可用
            if hasattr(self, 'edit_note_btn'):
                self.edit_note_btn.config(state=NORMAL)
            # 切换分类按钮：BGM 禁用，音效/语音可切换
            if hasattr(self, 'toggle_class_btn'):
                ttype = t.get("type", "bgm")
                if ttype == "bgm":
                    self.toggle_class_btn.config(state=DISABLED, text="切换为语音/音效")
                elif ttype == "sfx":
                    self.toggle_class_btn.config(state=NORMAL, text="标记为角色语音")
                else:
                    self.toggle_class_btn.config(state=NORMAL, text="标记为音效")
            # 更新中文台词显示区（角色语音）
            try:
                self._update_text_matcher_display(t)
            except Exception:
                pass
        except Exception as e:
            print(f"[详情面板] 刷新异常: {e}")
            import traceback
            traceback.print_exc()

    # ==================== 曲目标注编辑 ====================

    # ==================== 标注 key 管理（awb:wave_id 组合，避免同 wave_id 跨 AWB 串扰）====================

    def _note_key(self, t):
        """生成标注的唯一 key：awb_stem:wave_id（awb 用大写）。无 AWB 时退回纯 wave_id。"""
        try:
            awb = str(t.get("awb_stem", "")).strip().upper()
            wid = t.get("wave_id")
            if awb and wid is not None:
                return f"{awb}:{wid}"
            return str(wid) if wid is not None else None
        except Exception:
            return None

    def _get_track_note(self, t, default=""):
        """获取该 track 的标注：优先新格式 awb:wave_id，兼容旧格式纯 wave_id。"""
        key = self._note_key(t)
        if key is not None and key in self.track_notes:
            return self.track_notes[key]
        wid = t.get("wave_id")
        if wid is not None and wid in self.track_notes:
            return self.track_notes[wid]
        return default

    def _has_user_note(self, t):
        """判断该 track 是否有用户标注（含空字符串=已清空）。"""
        key = self._note_key(t)
        if key is not None and key in self.track_notes:
            return True
        wid = t.get("wave_id")
        return wid is not None and wid in self.track_notes

    def _set_track_note(self, t, note):
        """设置该 track 的标注（新格式 awb:wave_id），并清理旧格式同 wave_id 的 key 防串扰。"""
        key = self._note_key(t)
        if key is None:
            return
        # 清理旧格式（防止旧数据串扰到其他 AWB）
        wid = t.get("wave_id")
        if wid is not None and wid in self.track_notes:
            self.track_notes.pop(wid, None)
        self.track_notes[key] = note

    def _pop_track_note(self, t):
        """删除该 track 的标注（新格式 + 旧格式）。"""
        key = self._note_key(t)
        if key is not None:
            self.track_notes.pop(key, None)
        wid = t.get("wave_id")
        if wid is not None:
            self.track_notes.pop(wid, None)

    def _load_track_notes(self):
        """从 track_notes.json 加载用户自定义标注"""
        try:
            p = Path(TRACK_NOTES_FILE)
            if p.exists():
                with open(p, "r", encoding="utf-8") as f:
                    data = json.load(f)
                if isinstance(data, dict):
                    for k, v in data.items():
                        s = str(v)
                        # 新格式: "AWB:wave_id"（含冒号）→ 保持字符串 key
                        if isinstance(k, str) and ':' in k:
                            self.track_notes[k] = s
                            continue
                        try:
                            self.track_notes[int(k)] = s
                        except (ValueError, TypeError):
                            self.track_notes[str(k)] = s
        except Exception as e:
            print(f"[标注文件加载失败] {e}")

    def _build_wave_offsets_from_notes(self):
        """基于用户标注（track_notes）自动计算每个 AWB 的 wave_id -> 台词索引偏移量，
        并注入到 voice_text_matcher。同时把精确标注映射注入 awb_wave_text 实现精确匹配。
        原理：P5R 中 wave_id 与台词索引通常呈斜率为1的线性关系（idx = wave_id - base_wave + base_idx），
        用户标注提供了精确锚点，据此推断未标注曲目的台词。"""
        if self.text_matcher is None:
            return
        import difflib
        import re
        from collections import defaultdict
        # 按 AWB 分组用户标注（新格式 awb:wave_id，兼容旧格式纯 wave_id）
        by_awb = defaultdict(dict)
        for k, v in self.track_notes.items():
            note = str(v).strip()
            if not note:
                continue
            if isinstance(k, str) and ':' in k:
                awb, wid = k.split(':', 1)
                try:
                    by_awb[awb.strip().upper()][int(wid)] = note
                except (ValueError, TypeError):
                    continue
            else:
                # 旧格式纯 wave_id：无法确定 AWB，跳过（需用户重新编辑保存以迁移到新格式）
                continue
        total_offset = 0
        total_exact = 0
        for awb_upper, note_map in by_awb.items():
            texts = self.text_matcher.get_awb_texts(awb_upper)
            if not texts:
                continue
            # 用 difflib 把每条标注匹配到台词库，得到 (wave_id, 台词索引) 映射点
            # 支持合并台词拆分：台词库可能把多句诗/对话合并成1条（用空格/换行分隔），
            # 需拆分成子句后再匹配，以获取准确的对应关系
            points = []
            for wid, note in sorted(note_map.items()):
                best_idx = -1
                best_score = 0.0
                for i, t in enumerate(texts):
                    name = (t.get("name", "") or "").replace(" ", "").replace("　", "")
                    raw_text = (t.get("text", "") or "").strip()
                    # 拆分合并台词为子句（按换行、2+连续空格、单空格分隔）
                    sub_clauses = []
                    for line in re.split(r"[\n\r]+", raw_text):
                        line = line.strip()
                        if not line:
                            continue
                        # 按空格拆分（中文台词内部一般无空格，空格即句子分隔）
                        parts = [p.strip() for p in re.split(r"\s{1,}", line) if p.strip()]
                        sub_clauses.extend(parts)
                    if not sub_clauses:
                        sub_clauses = [raw_text]
                    # 用每个子句匹配（优先，因为用户标注通常是单句）
                    for clause in sub_clauses:
                        s = difflib.SequenceMatcher(None, note, clause).ratio()
                        if s > best_score:
                            best_score = s
                            best_idx = i
                    # 也用完整文本+name 匹配（兼容非合并台词）
                    full_text = raw_text.replace("\n", " ")
                    combined = f"{name}：{full_text}" if name else full_text
                    s1 = difflib.SequenceMatcher(None, note, combined).ratio()
                    s2 = difflib.SequenceMatcher(None, note, full_text).ratio()
                    score = max(s1, s2)
                    if score > best_score:
                        best_score = score
                        best_idx = i
                # 相似度 >= 0.5 视为有效映射点
                if best_idx >= 0 and best_score >= 0.5:
                    points.append((wid, best_idx))
                    # 注入精确映射到 awb_wave_text（规则0最高优先级）
                    # 关键：用用户标注的准确文本（而不是台词库的合并文本），
                    # 因为用户手动确认过的标注才是最准确的单句台词
                    if awb_upper not in self.text_matcher.awb_wave_text:
                        self.text_matcher.awb_wave_text[awb_upper] = {}
                    matched = texts[best_idx]
                    matched_name = (matched.get("name", "") or "").strip()
                    # 从用户标注文本中去除 name 前缀（避免显示时重复 "name：name：..."）
                    clean_note = note
                    if matched_name:
                        prefix1 = f"{matched_name}："
                        prefix2 = f"{matched_name}:"
                        if clean_note.startswith(prefix1):
                            clean_note = clean_note[len(prefix1):].strip()
                        elif clean_note.startswith(prefix2):
                            clean_note = clean_note[len(prefix2):].strip()
                    custom_entry = {
                        "id": matched.get("id", ""),
                        "name": matched_name,
                        "text": clean_note,  # 用用户标注的准确文本（已去除 name 前缀）
                        "source": matched.get("source", ""),
                    }
                    self.text_matcher.awb_wave_text[awb_upper][wid] = custom_entry
                    total_exact += 1
            # 计算偏移量：用第一个有效点作为 base（假设斜率为1）
            if points:
                base_wave, base_idx = points[0]
                # 验证线性关系：检查后续点是否符合 idx = wid - base_wave + base_idx
                linear_ok = True
                for wid, idx in points[1:]:
                    pred = wid - base_wave + base_idx
                    if pred != idx:
                        linear_ok = False
                        break
                self.text_matcher.set_wave_offset(awb_upper, base_wave, base_idx)
                total_offset += 1
                if not linear_ok:
                    print(f"[偏移量] {awb_upper}: {len(points)}个锚点，非线性（有空槽位），base=wave{base_wave}->idx{base_idx}")
        print(f"[偏移量构建] 完成：{total_offset} 个 AWB 注入偏移量，{total_exact} 条精确标注映射")

    def _load_ai_transcripts(self):
        """加载 AI 语音识别结果 {wave_id: 翻译文本}"""
        self.ai_transcripts = {}
        try:
            if os.path.exists(AI_TRANSCRIPTS_FILE):
                with open(AI_TRANSCRIPTS_FILE, encoding="utf-8") as f:
                    data = json.load(f)
                if isinstance(data, dict):
                    self.ai_transcripts = {str(k): v for k, v in data.items()}
        except Exception as e:
            print(f"[AI转录] 加载失败: {e}")
            self.ai_transcripts = {}

    def _save_track_notes(self):
        """保存用户自定义标注到 track_notes.json（随工具发布）"""
        try:
            with open(TRACK_NOTES_FILE, "w", encoding="utf-8") as f:
                json.dump({str(k): v for k, v in self.track_notes.items()},
                          f, ensure_ascii=False, indent=2)
            return True
        except Exception as e:
            print(f"[标注文件保存失败] {e}")
            return False

    def edit_track_note(self):
        """编辑当前选中曲目的标注（可添加/修改/删除，支持 AI 识别台词）"""
        if not self.current_track:
            return
        t = self.current_track
        wave_id = t['wave_id']
        if self._has_user_note(t):
            current = self._get_track_note(t, "")
        else:
            current = SPECIAL_TRACK_NOTES.get(wave_id, "")

        win = Toplevel(self.root)
        win.title(f"编辑标注 - {wave_id:05d}")
        win.geometry("560x860")
        win.resizable(False, False)
        win.transient(self.root)
        win.grab_set()

        Label(win, text=f"Wave ID: {wave_id:05d}    曲名: {t.get('name', '')}",
              font=("Arial", 10, "bold")).pack(anchor=W, padx=12, pady=(10, 4))
        Label(win, text="标注内容（显示在曲名后，如：joker:伊邪那岐大神）",
              fg="gray", font=("Arial", 9)).pack(anchor=W, padx=12, pady=2)

        note_var = StringVar(value=current)
        entry = Entry(win, textvariable=note_var, width=55, font=("Arial", 11))
        entry.pack(fill=X, padx=12, pady=6)
        entry.focus_set()
        entry.select_range(0, END)

        # ---- 日文原文（voice_text_correlation.json，可直接复制）----
        jp_label = Label(win, text="日文原文（绿色=匹配台词，可直接复制）：",
                         fg="#B71C1C", font=("Arial", 9, "bold"))
        jp_label.pack(anchor=W, padx=12, pady=(8, 2))
        jp_text = Text(win, height=4, width=60, font=("MS Gothic", 9), wrap=WORD)
        jp_text.pack(fill=X, padx=12, pady=2)
        try:
            jp_content, jp_matched = self._build_jp_text_with_match(t)
            jp_text.insert(END, jp_content)
            if jp_matched >= 0:
                try:
                    jp_text.tag_add("match", f"{jp_matched}.0", f"{jp_matched + 1}.0")
                except Exception:
                    pass
            jp_text.tag_config("match", foreground="#2E7D32",
                               font=("MS Gothic", 9, "bold"))
        except Exception as e:
            jp_text.insert(END, f"（日文原文加载失败: {e}）")
        jp_text.config(state=NORMAL)  # 保持可编辑，方便选中复制

        # ---- AI 识别翻译原句（Whisper 识别 + NLLB 翻译，供对照参考）----
        ai_trans_label = Label(win, text="AI 识别翻译原句（点击下方「AI 识别台词并翻译」生成）：",
                               fg="#6A1B9A", font=("Arial", 9, "bold"))
        ai_trans_label.pack(anchor=W, padx=12, pady=(6, 2))
        ai_trans_text = Text(win, height=4, width=60, font=("Arial", 9), wrap=WORD)
        ai_trans_text.pack(fill=X, padx=12, pady=2)
        ai_trans_text.insert(END, "（点击下方「AI 识别台词并翻译」按钮后，这里会显示 AI 识别的日文原文和中文翻译，供与上方官方台词对照）")
        ai_trans_text.config(state=NORMAL)  # 保持可编辑，方便选中复制

        # ---- 中文台词参考（SC.CPK 台词库，可直接复制）----
        sub_label = Label(win, text="中文台词参考（可直接复制，绿色=匹配台词）：",
                          fg="#0D47A1", font=("Arial", 9, "bold"))
        sub_label.pack(anchor=W, padx=12, pady=(8, 2))
        sub_text = Text(win, height=6, width=60, font=("Microsoft YaHei", 9), wrap=WORD)
        sub_text.pack(fill=X, padx=12, pady=2)
        try:
            sub_content, sub_matched = self._build_subtitle_text_with_match(t)
            sub_text.insert(END, sub_content)
            if sub_matched >= 0:
                try:
                    sub_text.tag_add("match", f"{sub_matched}.0", f"{sub_matched + 1}.0")
                except Exception:
                    pass
            sub_text.tag_config("match", foreground="#2E7D32",
                                font=("Microsoft YaHei", 9, "bold"))
        except Exception as e:
            sub_text.insert(END, f"（台词加载失败: {e}）")
        sub_text.config(state=NORMAL)  # 保持可编辑，方便选中复制

        # ---- 主动触发 AI 识别匹配（无论有没有 match_wave_texts 结果）----
        # 流程：AI识别日文 → 模糊匹配日文原句 → 通过id关联中文台词 → 刷新绿色标记
        try:
            awb = str(t.get("awb_stem", "")).strip().upper()
            wave_id = self._resolve_local_wave_id(t)
            all_texts = []
            if self.text_matcher is not None and awb:
                all_texts = self.text_matcher.get_awb_texts(awb) or []
            # 检查缓存是否存在
            jp_cache = getattr(self, "_ai_match_jp_cache", {}) or {}
            need_ai = (awb, wave_id) not in jp_cache
            if need_ai and all_texts:
                # 主动触发 AI 识别匹配（后台线程，不阻塞UI）
                self._schedule_ai_match(t, awb, wave_id, all_texts)
                # 记录对话框引用，AI 匹配完成后刷新
                self._note_dialog_refs = {
                    "win": win, "jp_text": jp_text, "sub_text": sub_text,
                    "track": t, "awb": awb, "wave_id": wave_id,
                }
        except Exception as _e:
            print("[编辑标注] 主动AI匹配触发异常: %s" % _e)

        # ---- AI 识别区域 ----
        ai_row = Frame(win)
        ai_row.pack(fill=X, padx=12, pady=(4, 0))
        ai_status = StringVar(value="AI 识别：自动识别日文台词并翻译为中文（离线，约1~3秒/条）")
        Label(ai_row, textvariable=ai_status, fg="gray", font=("Arial", 9)).pack(side=LEFT, anchor=W)

        # ---- 模型选择行 ----
        model_row = Frame(win)
        model_row.pack(fill=X, padx=12, pady=(2, 0))
        Label(model_row, text="识别模型：", font=("Arial", 9)).pack(side=LEFT)
        try:
            import voice_ai
            current_model = voice_ai.get_model_size()
        except Exception:
            current_model = "medium"
        model_var = StringVar(value=current_model)
        model_combo = ttk.Combobox(model_row, textvariable=model_var,
                                    values=["small", "medium", "large-v3"],
                                    state="readonly", width=12, font=("Arial", 9))
        model_combo.pack(side=LEFT, padx=(4, 8))

        def on_model_change(event=None):
            selected = model_var.get()
            try:
                import voice_ai
                if voice_ai.set_model_size(selected):
                    voice_ai.reload_model()
                    ai_status.set(f"模型已切换为 {selected}，下次识别时生效（首次需下载模型）")
                else:
                    ai_status.set("模型切换失败")
            except Exception as e:
                ai_status.set(f"模型切换出错: {e}")

        model_combo.bind("<<ComboboxSelected>>", on_model_change)
        Label(model_row, text="small快/准度低  medium均衡  large-v3最慢/最准",
              fg="gray", font=("Arial", 8)).pack(side=LEFT)

        ai_result = Text(win, height=8, width=60, font=("Arial", 10), wrap=WORD)
        ai_result.pack(fill=X, padx=12, pady=4)
        ai_result.insert(END, "点击「AI 识别台词并翻译」识别本条语音\n")
        ai_result.config(state=DISABLED)

        ai_btn_row = Frame(win)
        ai_btn_row.pack(fill=X, padx=12, pady=2)

        def _ai_done(res):
            ai_btn.config(state=NORMAL)
            if not res.get("ok"):
                ai_status.set("识别失败")
                ai_result.config(state=NORMAL)
                ai_result.delete("1.0", END)
                ai_result.insert(END, res.get("error", "未知错误"))
                ai_result.config(state=DISABLED)
                return
            jp = res.get("jp", "")
            zh = res.get("zh", "")
            terms = res.get("terms", [])
            # ===== 翻译来源优先级优化 =====
            # 1. 用户标注（最高优先级，手动确认过的最准确）
            # 2. 官方翻译查表（voice_ai 返回 zh_source，官方原文 100% 一致）
            # 3. AI 翻译（NLLB 翻译 AI 识别日文，兜底）
            #    —— AI 识别翻译栏始终来源于 AI 识别日文：不再用中文台词库匹配覆盖，
            #       因为音文分离时（如 E100_101 wave3）BMD 文本与实际音频不对应，会误导。
            #       中文台词库匹配仍通过台词列表绿色标记显示（见台词列表构建逻辑）。
            zh_source = res.get("zh_source", "AI翻译")
            try:
                user_note = self._get_track_note(t, "")
                if user_note and str(user_note).strip():
                    zh = str(user_note).strip()
                    zh_source = "用户标注"
                elif zh_source not in ("官方翻译", "官方翻译(近似)"):
                    # 官方查表未命中时：AI 中文翻译直接来源于 AI 识别日文（NLLB 翻译）。
                    # 不再用中文台词库匹配覆盖，避免音文分离时 BMD 文本误导用户。
                    if not zh:
                        zh = res.get("zh", "")
            except Exception as e:
                print(f"[AI翻译来源] 回退异常: {e}")
            ai_status.set(f"识别完成（翻译来源：{zh_source}）")
            # 更新 AI 识别翻译原句文本框（日文原文 + 中文翻译）
            try:
                ai_trans_text.config(state=NORMAL)
                ai_trans_text.delete("1.0", END)
                ai_trans_text.insert(END, f"【AI 识别日文原文】\n{jp or '(未识别到清晰语音)'}\n\n")
                ai_trans_text.insert(END, f"【AI 中文翻译（来源：{zh_source}）】\n{zh or '(无)'}\n")
                ai_trans_text.config(state=NORMAL)
            except Exception:
                pass
            ai_result.config(state=NORMAL)
            ai_result.delete("1.0", END)
            ai_result.insert(END, f"【日文原文】\n{jp or '(未识别到清晰语音，可能为音效/BGM)'}\n\n")
            source_color = "#2E7D32" if zh_source != "AI翻译" else "#666666"
            ai_result.insert(END, f"【中文翻译（来源：{zh_source}）】\n", ("source",))
            ai_result.tag_config("source", foreground=source_color, font=("Arial", 9, "bold"))
            ai_result.insert(END, f"{zh or '(无)'}\n\n")
            if terms:
                ai_result.insert(END, "【命中的 P5R 词汇】\n" + "；".join(terms[:8]))
            else:
                ai_result.insert(END, "【命中的 P5R 词汇】(无)")
            ai_result.config(state=DISABLED)
            # 若识别到翻译，自动填入标注框（推测匹配不自动填充，避免误导用户）
            if zh and zh_source != "中文台词库(推测)":
                note_var.set(zh)
                entry.select_range(0, END)

        def _ai_fail(msg):
            ai_btn.config(state=NORMAL)
            ai_status.set("AI 识别不可用")
            ai_result.config(state=NORMAL)
            ai_result.delete("1.0", END)
            ai_result.insert(END, msg)
            ai_result.config(state=DISABLED)

        def do_ai():
            ai_btn.config(state=DISABLED)
            # 根据模型预加载状态给出更准确的提示
            try:
                import voice_ai
                if voice_ai.is_preloaded() and not voice_ai.is_loading():
                    ai_status.set("AI 识别中...")
                elif voice_ai.is_loading() or (not voice_ai.is_preloaded() and _is_model_preloading()):
                    ai_status.set("AI 识别中... 模型正在后台预加载，首次识别稍候")
                else:
                    ai_status.set("AI 识别中... 首次使用需加载模型（稍慢）")
            except Exception:
                ai_status.set("AI 识别中... 首次使用需加载模型（稍慢）")
            ai_result.config(state=NORMAL)
            ai_result.delete("1.0", END)
            ai_result.insert(END, "识别中...\n")
            ai_result.config(state=DISABLED)
            path = t.get("path")

            def work():
                try:
                    import voice_ai
                    if not voice_ai.is_available():
                        self.root.after(0, lambda: _ai_fail(
                            "未安装 faster-whisper 依赖。\n请运行: py -m pip install faster-whisper"))
                        return
                    # 传入 AWB 上下文，动态调整 initial_prompt 提升识别准确率
                    _ctx = {"awb": t.get("awb_stem", ""), "wave_id": t.get("wave_id", 0)}
                    res = voice_ai.transcribe_adx(path, language="ja", context=_ctx)
                    self.root.after(0, lambda: _ai_done(res))
                except Exception as e:
                    self.root.after(0, lambda: _ai_fail(f"识别出错: {e}"))

            threading.Thread(target=work, daemon=True).start()

        ai_btn = Button(ai_btn_row, text="AI 识别台词并翻译", command=do_ai,
                        bg="#2196F3", fg="white", font=("Arial", 9), width=18)
        ai_btn.pack(side=LEFT, padx=(0, 8))
        Button(ai_btn_row, text="填入标注", font=("Arial", 9), width=10,
               command=lambda: (note_var.set(ai_result.get("1.0", END).strip()), None)).pack(side=LEFT)

        def do_calibrate():
            """从所有标注建立校准映射（不修改标注数据，只建立 wave_id->文本索引映射）"""
            try:
                if self.text_matcher is None:
                    return
                # 合并所有曲目列表
                all_tracks = list(self.bgm_tracks or []) + list(self.sfx_tracks or []) + list(self.voice_tracks or [])
                if not all_tracks:
                    all_tracks = list(self.tracks or [])
                added = self.text_matcher.calibrate_from_notes(self.track_notes, all_tracks)
                self.text_matcher.save_calibration()
                # 刷新当前列表
                self.refresh_track_list(select_wave_id=wave_id, select_awb=t.get("awb_stem", ""))
                ai_status.set(f"校准完成：新增 {added} 个校准点，已保存")
            except Exception as e:
                ai_status.set(f"校准失败: {e}")
                print(f"[校准映射] 失败: {e}")

        Button(ai_btn_row, text="校准映射", font=("Arial", 9), width=10,
               bg="#FF9800", fg="white", command=do_calibrate).pack(side=LEFT, padx=(8, 0))

        Label(win, text="提示：清空内容并保存 = 删除该条标注；保存后写入 track_notes.json 随工具发布",
              fg="#8E24AA", font=("Arial", 8)).pack(anchor=W, padx=12, pady=(6, 2))

        btn_row = Frame(win)
        btn_row.pack(fill=X, padx=12, pady=(4, 10))

        def do_save():
            val = note_var.get().strip()
            if val:
                self._set_track_note(t, val)
            else:
                # 清空 = 删除用户标注（若为内置默认标注也一并删除，恢复无标注）
                self._pop_track_note(t)
            ok = self._save_track_notes()
            try:
                self._build_wave_offsets_from_notes()
            except Exception:
                pass
            # 记录当前滚动位置，刷新后恢复（避免列表跳到顶部）
            try:
                _y_frac = self.track_listbox.yview()[0]
            except Exception:
                _y_frac = 0.0
            self.refresh_track_list(select_wave_id=wave_id, select_awb=t.get("awb_stem", ""))
            # 延迟恢复滚动位置（等 Listbox 渲染完成）
            try:
                self.root.after(60, lambda f=_y_frac: self.track_listbox.yview_moveto(f))
            except Exception:
                pass
            if ok:
                self._update_status(f"已保存标注: {wave_id:05d} {val}")
            win.destroy()

        def do_clear():
            # 清除内置+用户标注
            self._set_track_note(t, "")
            self._save_track_notes()
            try:
                self._build_wave_offsets_from_notes()
            except Exception:
                pass
            # 记录当前滚动位置，刷新后恢复（避免列表跳到顶部）
            try:
                _y_frac2 = self.track_listbox.yview()[0]
            except Exception:
                _y_frac2 = 0.0
            self.refresh_track_list(select_wave_id=wave_id, select_awb=t.get("awb_stem", ""))
            try:
                self.root.after(60, lambda f=_y_frac2: self.track_listbox.yview_moveto(f))
            except Exception:
                pass
            self._update_status(f"已清除标注: {wave_id:05d}")
            win.destroy()

        Button(btn_row, text="保存", command=do_save, width=10, bg="#4CAF50", fg="white").pack(side=LEFT, padx=5)
        Button(btn_row, text="清空标注", command=do_clear, width=10, bg="#f44336", fg="white").pack(side=LEFT, padx=5)
        Button(btn_row, text="取消", command=win.destroy, width=10).pack(side=LEFT, padx=5)

    # ==================== 试听 ====================

    def toggle_play(self):
        """播放/暂停切换"""
        if self.playing:
            # 正在播放 → 暂停
            self.pause_preview()
        elif self._paused and self.preview_wav:
            # 已暂停 → 继续播放
            self.resume_preview()
        else:
            # 未播放 → 开始播放
            self.play_preview()

    def pause_preview(self):
        """暂停播放，保持当前进度"""
        if not self.playing:
            return

        # 记录当前播放位置
        elapsed = time.time() - self._play_start_time
        current_pos = self._play_offset + elapsed
        self._play_offset = current_pos

        if HAS_PYGAME:
            pygame.mixer.music.pause()
        if HAS_WINSOUND:
            winsound.PlaySound(None, winsound.SND_PURGE)

        self.playing = False
        self._paused = True
        self._stop_progress_update()
        self.play_btn.config(text="▶ 继续")
        self.preview_status.set(f"已暂停: {self._format_time(current_pos)}")
        self._update_status(f"已暂停在 {self._format_time(current_pos)}")

    def resume_preview(self):
        """从暂停位置继续播放"""
        if not self._paused or not self.preview_wav:
            return

        if HAS_PYGAME:
            pygame.mixer.music.unpause()
            self.playing = True
            self._paused = False
            self._play_start_time = time.time()
            self.play_btn.config(text="⏸ 暂停")
            self._start_progress_update()
            self._check_playback_end()
            self.preview_status.set("正在播放")
            self._update_status("继续播放")
        elif HAS_WINSOUND:
            # winsound 不支持暂停/继续，重新从当前位置播放
            self._play_wav_from_pos(self.preview_wav, self._play_offset)

    def play_preview(self):
        """播放当前曲目的预览（从头开始）"""
        if not self.current_track:
            return

        # 如果有暂停状态，先清除
        self._paused = False

        t = self.current_track
        adx_path = t.get("replaced_path") or t["path"]

        self._update_status(f"正在解码预览: {t['name']}")

        def do_play():
            try:
                wav_path = self.adx.preview_adx(adx_path)
                self.preview_wav = wav_path
                self.root.after(0, lambda: self._play_wav(wav_path, t['name']))
            except ADXToolError as e:
                err_msg = str(e)
                self.root.after(0, lambda msg=err_msg: self._preview_error(msg))
            except Exception as e:
                err_msg = f"预览失败: {e}"
                self.root.after(0, lambda msg=err_msg: self._preview_error(msg))

        threading.Thread(target=do_play, daemon=True).start()

    def export_original_wav(self):
        """将当前选中的原曲导出为 WAV 到用户自定义文件夹"""
        if not self.current_track:
            messagebox.showinfo("提示", "请先在左侧列表选择一首曲目")
            return
        t = self.current_track

        # 选择导出文件夹
        out_dir = filedialog.askdirectory(title="选择导出 WAV 的文件夹")
        if not out_dir:
            return

        # 生成文件名：优先用曲目名，清理非法字符；重名时自动加序号
        raw_name = t["name"].strip() or f"track_{t['wave_id']:05d}"
        safe = "".join(c for c in raw_name if c not in r'\/:*?"<>|').strip() or f"track_{t['wave_id']:05d}"
        out_path = Path(out_dir) / f"{safe}.wav"
        counter = 1
        while out_path.exists():
            out_path = Path(out_dir) / f"{safe}_{counter}.wav"
            counter += 1

        output_wav = str(out_path)
        self._update_status(f"正在导出原曲为 WAV: {safe}")

        def do_export():
            try:
                self.adx.decrypt_adx_to_wav(t["path"], output_wav)
                self.root.after(0, lambda: self._export_wav_done(output_wav))
            except ADXToolError as e:
                err_msg = str(e)
                self.root.after(0, lambda msg=err_msg: self._export_wav_error(msg))
            except Exception as e:
                err_msg = f"导出失败: {e}"
                self.root.after(0, lambda msg=err_msg: self._export_wav_error(msg))

        threading.Thread(target=do_export, daemon=True).start()

    def _export_wav_done(self, wav_path: str):
        """原曲导出 WAV 完成"""
        self._update_status(f"原曲已导出为 WAV: {wav_path}")
        messagebox.showinfo(
            "导出成功",
            f"原曲已导出为 WAV！\n\n"
            f"保存位置: {wav_path}"
        )

    def _export_wav_error(self, msg: str):
        """原曲导出 WAV 失败"""
        self._update_status(f"导出失败: {msg}")
        messagebox.showerror("导出失败", msg)

    def _play_wav(self, wav_path: str, track_name: str):
        """播放 WAV 文件"""
        try:
            # 获取 WAV 总时长
            single_duration = self._get_wav_duration(wav_path)
            # 极短音频（<2秒，如过场音效）循环播放5次（需勾选"极短音频循环播放5次"，默认关闭）
            auto_loops = (4 if single_duration > 0 and single_duration < 2.0 else 0) if self.loop_short_audio_var.get() else 0
            self.preview_duration = single_duration * (auto_loops + 1) if auto_loops > 0 else single_duration

            if HAS_PYGAME:
                pygame.mixer.music.load(wav_path)
                pygame.mixer.music.play(loops=auto_loops)
                self.playing = True
                self._paused = False
                self._play_start_time = time.time()
                self._play_offset = 0.0
                self.play_btn.config(text="⏸ 暂停")
                if auto_loops > 0:
                    self.preview_status.set(f"正在播放(极短音频循环{auto_loops+1}次): {track_name}")
                else:
                    self.preview_status.set(f"正在播放: {track_name}")
                self._update_status(f"播放中: {track_name}")
                # 启用进度条
                self.progress_scale.config(state=NORMAL)
                self.progress_scale.set(0)
                # 启动进度更新
                self._start_progress_update()
                # 检测播放结束
                self._check_playback_end()
            elif HAS_WINSOUND:
                winsound.PlaySound(wav_path, winsound.SND_FILENAME | winsound.SND_ASYNC)
                self.playing = True
                self._paused = False
                self._play_start_time = time.time()
                self._play_offset = 0.0
                self.play_btn.config(text="⏸ 暂停")
                self.preview_status.set(f"正在播放: {track_name}")
                self._update_status(f"播放中: {track_name}")
                self.progress_scale.config(state=NORMAL)
                self._start_progress_update()
            else:
                # 用默认播放器打开
                os.startfile(wav_path)
                self.preview_status.set("已用外部播放器打开")
        except Exception as e:
            self._preview_error(f"播放失败: {e}")

    def _play_wav_from_pos(self, wav_path: str, offset: float):
        """从指定位置（秒）播放 WAV。
        winsound 不支持 seek，通过把 WAV 截断为 offset 之后的临时文件再播放实现。
        """
        try:
            import wave as _wave
            offset = max(0.0, offset)
            total_duration = self._get_wav_duration(wav_path)
            # 读取 WAV 并截断到 offset 之后
            with _wave.open(wav_path, 'rb') as src:
                params = src.getparams()
                framerate = src.getframerate()
                if framerate <= 0:
                    framerate = 44100
                channels = src.getnchannels()
                sampwidth = src.getsampwidth()
                total_frames = src.getnframes()
                start_frame = min(int(offset * framerate), total_frames)
                src.setpos(start_frame)
                data = src.readframes(total_frames - start_frame)
            fd, tmp_path = tempfile.mkstemp(suffix='.wav')
            os.close(fd)
            with _wave.open(tmp_path, 'wb') as dst:
                dst.setparams((channels, sampwidth, framerate, 0, 'NONE', 'not compressed'))
                dst.writeframes(data)
            # 清理旧的临时文件
            old_tmp = getattr(self, 'preview_wav_tmp', None)
            if old_tmp and os.path.exists(old_tmp) and old_tmp != wav_path:
                try:
                    os.remove(old_tmp)
                except Exception:
                    pass
            self.preview_wav_tmp = tmp_path
            self.preview_duration = total_duration  # 保持总时长，进度条按总时长显示
            winsound.PlaySound(tmp_path, winsound.SND_FILENAME | winsound.SND_ASYNC)
            self.playing = True
            self._paused = False
            self._play_start_time = time.time()
            self._play_offset = offset
            self.play_btn.config(text="⏸ 暂停")
            self.preview_status.set("正在播放")
            self._update_status("继续播放")
            if self.preview_duration > 0:
                self.progress_scale.set(min(100, offset / self.preview_duration * 100))
            self.progress_scale.config(state=NORMAL)
            self._start_progress_update()
            self._check_playback_end()
        except Exception as e:
            self._preview_error(f"播放失败: {e}")

    def _get_wav_duration(self, wav_path: str) -> float:
        """获取 WAV 文件时长（秒）"""
        try:
            with wave.open(wav_path, 'rb') as wf:
                frames = wf.getnframes()
                rate = wf.getframerate()
                if rate > 0:
                    return frames / float(rate)
        except Exception:
            pass
        return 0.0

    def _format_time(self, seconds: float) -> str:
        """格式化时间为 MM:SS"""
        if seconds < 0:
            seconds = 0
        mins = int(seconds // 60)
        secs = int(seconds % 60)
        return f"{mins:02d}:{secs:02d}"

    def _start_progress_update(self):
        """启动进度条定时更新"""
        self._stop_progress_update()
        self._update_progress()

    def _stop_progress_update(self):
        """停止进度条定时更新"""
        if self._progress_after_id is not None:
            try:
                self.root.after_cancel(self._progress_after_id)
            except Exception:
                pass
            self._progress_after_id = None

    def _update_progress(self):
        """更新进度条位置（基于系统时间计算，不依赖 get_pos()）"""
        if not self.playing:
            self._progress_after_id = self.root.after(200, self._update_progress)
            return

        # 拖动中不更新
        if self._progress_seeking:
            self._progress_after_id = self.root.after(200, self._update_progress)
            return

        try:
            # 用系统时间计算当前播放位置：偏移量 + 已过时间
            elapsed = time.time() - self._play_start_time
            current_pos = self._play_offset + elapsed

            # 超过总时长则停止播放
            if self.preview_duration > 0 and current_pos >= self.preview_duration:
                self._on_playback_finished()
                self._progress_after_id = self.root.after(200, self._update_progress)
                return

            if self.preview_duration > 0:
                percent = min(100, (current_pos / self.preview_duration) * 100)
                self.progress_scale.set(percent)
                self.progress_var.set(
                    f"{self._format_time(current_pos)} / {self._format_time(self.preview_duration)}"
                )
        except Exception:
            pass

        self._progress_after_id = self.root.after(200, self._update_progress)

    def _on_playback_finished(self):
        """播放自然结束时的处理"""
        if not self.playing:
            return

        self.playing = False
        self._paused = False

        if HAS_PYGAME:
            pygame.mixer.music.stop()
        if HAS_WINSOUND:
            winsound.PlaySound(None, winsound.SND_PURGE)

        self._stop_progress_update()
        self.progress_scale.set(100)
        self.play_btn.config(text="▶ 播放")
        if self.preview_duration > 0:
            self.progress_var.set(
                f"{self._format_time(self.preview_duration)} / {self._format_time(self.preview_duration)}"
            )
        self.preview_status.set("播放结束")
        self._update_status("播放结束")

    def _on_progress_press(self, event):
        """进度条按下：暂停自动更新"""
        if self.playing:
            self._progress_seeking = True

    def _on_progress_motion(self, event):
        """进度条拖动中：更新时间显示"""
        if self.preview_duration > 0 and self._progress_seeking:
            try:
                percent = self.progress_scale.get()
                current_pos = (percent / 100.0) * self.preview_duration
                self.progress_var.set(
                    f"{self._format_time(current_pos)} / {self._format_time(self.preview_duration)}"
                )
            except Exception:
                pass

    def _on_progress_release(self, event):
        """进度条释放：跳转播放位置"""
        if not self.playing or self.preview_duration <= 0:
            self._progress_seeking = False
            return

        try:
            percent = self.progress_scale.get()
            target_pos = (percent / 100.0) * self.preview_duration

            if HAS_PYGAME:
                # 执行音频跳转
                pygame.mixer.music.set_pos(target_pos)
                # 更新计时器：偏移量设为目标位置，起始时间设为当前时间
                self._play_offset = target_pos
                self._play_start_time = time.time()
                # 手动设置进度条到目标位置
                self.progress_scale.set(percent)
                self.progress_var.set(
                    f"{self._format_time(target_pos)} / {self._format_time(self.preview_duration)}"
                )
                self._update_status(f"跳转到 {self._format_time(target_pos)}")
        except Exception as e:
            self._update_status(f"跳转失败: {e}")
        finally:
            self._progress_seeking = False

    def _check_playback_end(self):
        """检测 pygame 播放是否结束"""
        if HAS_PYGAME and self.playing:
            if not pygame.mixer.music.get_busy():
                self.playing = False
                self._paused = False
                self._stop_progress_update()
                self.progress_scale.set(100)
                self.play_btn.config(text="▶ 播放")
                if self.preview_duration > 0:
                    self.progress_var.set(
                        f"{self._format_time(self.preview_duration)} / {self._format_time(self.preview_duration)}"
                    )
                self.preview_status.set("播放结束")
                self._update_status("播放结束")
                return
        self.root.after(500, self._check_playback_end)

    def stop_preview(self):
        """停止播放并重置到开头"""
        if HAS_PYGAME:
            pygame.mixer.music.stop()
        if HAS_WINSOUND:
            winsound.PlaySound(None, winsound.SND_PURGE)
        self.playing = False
        self._paused = False
        self._play_offset = 0.0
        self._play_start_time = 0.0
        self._stop_progress_update()
        self.progress_scale.set(0)
        self.play_btn.config(text="▶ 播放")
        if self.preview_duration > 0:
            self.progress_var.set(f"00:00 / {self._format_time(self.preview_duration)}")
        else:
            self.progress_var.set("00:00 / 00:00")
        self.preview_status.set("已重置")
        self._update_status("播放已重置")

    def _preview_error(self, msg):
        self.preview_status.set("预览失败")
        self._update_status(f"预览失败: {msg}")
        messagebox.showerror("预览失败", msg)

    # ==================== 替换 ====================

    def select_replace_file(self):
        """选择要替换的音乐文件"""
        filepath = filedialog.askopenfilename(
            title="选择音乐文件",
            filetypes=[
                ("音频文件", "*.mp3 *.wav *.ogg *.flac *.m4a *.aac *.wma"),
                ("MP3", "*.mp3"),
                ("WAV", "*.wav"),
                ("所有文件", "*.*")
            ]
        )
        if filepath:
            self.replace_file_var.set(filepath)
            if self.current_track:
                self.replace_btn.config(state=NORMAL)
            self._update_status(f"已选择替换文件: {Path(filepath).name}")
            self._refresh_replace_duration_hint()

    def _reset_adv_options(self):
        """重置高级选项为默认值"""
        self.loop_start_var.set("0")
        self.loop_end_var.set("-1")
        self.volume_gain_var.set("1.0")
        # 等长匹配默认按界面：音效开、语音关（Ryo 下超长完整播放）
        self.match_length_var.set(self.current_audio_type == "sfx")
        self.match_level_var.set(True)
        self.match_spectrum_var.set(True)
        self.ryo_export_var.set(True)
        self.ryo_volume_var.set("0.5")
        self.match_bandwidth_var.set(True)
        self.match_noisefloor_var.set(True)
        self.match_stereo_var.set(True)
        self.match_envelope_var.set(True)
        self.match_lufs_var.set(True)
        self.match_dynamics_var.set(True)
        if hasattr(self, "batch_range_var"):
            self.batch_range_var.set("")
        self._update_status("高级选项已重置为默认值")

    def _probe_audio_duration(self, filepath: str):
        """用 ffmpeg 探测音频时长（秒），失败返回 None"""
        try:
            import re as _re
            ff = getattr(self.adx, "ffmpeg_path", None)
            if ff is None:
                return None
            p = subprocess.run([str(ff), "-i", filepath], capture_output=True,
                               text=True, errors="ignore")
            m = _re.search(r"Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)", p.stderr or "")
            if m:
                h, mm, s = int(m.group(1)), int(m.group(2)), float(m.group(3))
                return h * 3600 + mm * 60 + s
        except Exception:
            pass
        return None

    def _refresh_replace_duration_hint(self):
        """更新时长对比提示（原版 vs 新文件），提醒替换需与原音频等长"""
        if not hasattr(self, "replace_dur_label"):
            return
        if not self.current_track:
            self.replace_dur_label.config(text="请先在列表中选择要替换的曲目", fg="gray")
            return
        t = self.current_track
        orig_path = t.get("original_path", t.get("path"))
        orig_dur = 0.0
        try:
            if orig_path and os.path.exists(orig_path):
                orig_dur = self.adx.get_adx_info(orig_path).get("duration", 0.0) or 0.0
        except Exception:
            pass
        new_file = self.replace_file_var.get()
        if new_file == "未选择文件" or not os.path.exists(new_file):
            if orig_dur > 0:
                self.replace_dur_label.config(
                    text="原版时长: %.1fs（%s） | 请选择替换音频（需等长）" % (orig_dur, t.get("name", "")),
                    fg="gray")
            return
        new_dur = self._probe_audio_duration(new_file)
        if orig_dur > 0 and new_dur:
            diff = abs(new_dur - orig_dur) / max(orig_dur, 0.001)
            if diff > 0.02:
                if self.match_length_var.get():
                    self.replace_dur_label.config(
                        text="时长不同: 原版 %.1fs vs 新 %.1fs（将自动补齐/截断到等长）" % (orig_dur, new_dur),
                        fg="#CC6600")
                else:
                    if self.current_audio_type == "voice":
                        self.replace_dur_label.config(
                            text="时长不同: 原版 %.1fs vs 新 %.1fs（等长已关，语音Ryo下超长完整播放）" % (orig_dur, new_dur),
                            fg="#CC6600")
                    else:
                        self.replace_dur_label.config(
                            text="时长不同: 原版 %.1fs vs 新 %.1fs（已关闭等长，音效可能无声/偏移错误）" % (orig_dur, new_dur),
                            fg="#CC0000")
            else:
                self.replace_dur_label.config(
                    text="时长匹配: 原版 %.1fs vs 新 %.1fs" % (orig_dur, new_dur), fg="green")
        elif new_dur:
            self.replace_dur_label.config(
                text="新文件时长: %.1fs（未能读取原版时长）" % new_dur, fg="gray")
        else:
            self.replace_dur_label.config(text="（无法读取音频时长）", fg="gray")

    def _build_duration_summary(self, t, replace_file):
        """构造替换确认框中的时长对比行（提醒等长要求）"""
        try:
            orig_path = t.get("original_path", t.get("path"))
            orig_dur = 0.0
            if orig_path and os.path.exists(orig_path):
                orig_dur = self.adx.get_adx_info(orig_path).get("duration", 0.0) or 0.0
            new_dur = self._probe_audio_duration(replace_file) or 0.0
            if orig_dur > 0 and new_dur > 0:
                if abs(new_dur - orig_dur) / orig_dur <= 0.02:
                    return "时长: %.1fs ≈ 原版 %.1fs（等长 OK）" % (new_dur, orig_dur)
                if self.match_length_var.get():
                    return "时长: 原版 %.1fs vs 新 %.1fs（将自动补齐/截断到等长）" % (orig_dur, new_dur)
                if self.current_audio_type == "voice":
                    return "时长: 原版 %.1fs vs 新 %.1fs（等长已关，语音Ryo下超长完整播放）" % (orig_dur, new_dur)
                return "时长: 原版 %.1fs vs 新 %.1fs（已关闭等长，音效可能无声）" % (orig_dur, new_dur)
        except Exception:
            pass
        return ""

    def do_replace(self):
        """执行替换"""
        if not self.current_track:
            messagebox.showwarning("提示", "请先在列表中选择要替换的曲目")
            return

        replace_file = self.replace_file_var.get()
        if replace_file == "未选择文件" or not os.path.exists(replace_file):
            messagebox.showwarning("提示", "请先选择要替换的音乐文件")
            return

        t = self.current_track
        wave_id = t["wave_id"]
        real_index = t.get("real_index", t["wave_id"])
        awb_stem = t.get("awb_stem", "BGM")
        track_name = t["name"]

        # 读取高级选项：循环点 + 音量增益
        try:
            loop_start = int(self.loop_start_var.get().strip() or "0")
        except ValueError:
            messagebox.showwarning("参数错误", "循环起点必须是整数（样本数）")
            return
        try:
            loop_end = int(self.loop_end_var.get().strip() or "-1")
        except ValueError:
            messagebox.showwarning("参数错误", "循环终点必须是整数（样本数，-1=末尾）")
            return
        try:
            volume_gain = float(self.volume_gain_var.get().strip() or "1.0")
            if volume_gain <= 0:
                raise ValueError
        except ValueError:
            messagebox.showwarning("参数错误", "音量增益必须是正数（如 1.0、1.5、2.0）")
            return

        # 解析批量替换范围（可选）：留空=仅当前曲目
        batch_targets = []
        raw_range = ""
        try:
            raw_range = self.batch_range_var.get().strip()
        except Exception:
            raw_range = ""
        if raw_range:
            for part in raw_range.replace("，", ",").replace("~", "-").split(","):
                part = part.strip()
                if not part:
                    continue
                try:
                    if "-" in part:
                        a, b = part.split("-", 1)
                        lo, hi = int(a.strip()), int(b.strip())
                    else:
                        lo = hi = int(part)
                except ValueError:
                    messagebox.showwarning("参数错误", f"无法解析批量范围: {part}")
                    return
                if lo > hi:
                    lo, hi = hi, lo
                for tr in self.tracks:
                    wid = tr.get("wave_id")
                    if isinstance(wid, int) and lo <= wid <= hi and tr not in batch_targets:
                        batch_targets.append(tr)
            if not batch_targets:
                messagebox.showwarning("参数错误", f"批量范围内未找到可替换的曲目: {raw_range}")
                return
        else:
            batch_targets = [t]

        # 确认对话框（含高级选项摘要）
        adv_summary = []
        if loop_start != 0 or loop_end != -1:
            adv_summary.append(f"循环: {loop_start} ~ {loop_end if loop_end >= 0 else '末尾'}")
        if abs(volume_gain - 1.0) > 0.001:
            adv_summary.append(f"音量: {volume_gain}x")
        adv_text = f"\n高级设置: {', '.join(adv_summary)}" if adv_summary else ""

        dur_line = self._build_duration_summary(t, replace_file)
        dur_text = f"\n{dur_line}" if dur_line else ""
        if len(batch_targets) == 1:
            bt = batch_targets[0]
            confirm = messagebox.askyesno(
                "确认替换",
                f"即将替换以下曲目:\n\n"
                f"ID: {bt['wave_id']:05d}\n"
                f"曲名: {bt['name']}\n"
                f"替换为: {Path(replace_file).name}{adv_text}{dur_text}\n\n"
                f"是否继续？")
        else:
            ids = ", ".join(str(tr['wave_id']) for tr in batch_targets)
            confirm = messagebox.askyesno(
                "确认替换",
                f"即将批量替换 {len(batch_targets)} 个曲目:\n{ids}\n\n"
                f"替换为: {Path(replace_file).name}{adv_text}\n"
                f"将自动部署全部对应 Ryo Cue\n\n是否继续？")
        if not confirm:
            return

        self._update_status(f"正在处理替换: {track_name}...")
        self.replace_btn.config(state=DISABLED)

        def do_process():
            try:
                output_dir = self._replaced_dir
                output_dir.mkdir(parents=True, exist_ok=True)
                done = []
                for tr in batch_targets:
                    tr_wid = tr["wave_id"]
                    tr_real = tr.get("real_index", tr_wid)
                    tr_awb = tr.get("awb_stem", "BGM")
                    tr_name = tr["name"]
                    # BGM 用基础编码（不做对齐），音效/语音用高级对齐
                    _is_bgm = (self.current_audio_type == "bgm")
                    result_path = self.adx.process_replacement(
                        replace_file, tr_real, str(output_dir),
                        original_adx=tr.get("original_path", tr.get("path")),
                        loop_start=loop_start, loop_end=loop_end,
                        volume_gain=volume_gain,
                        match_length=(False if _is_bgm else self.match_length_var.get()),
                        match_level=(False if _is_bgm else self.match_level_var.get()),
                        match_spectrum=(False if _is_bgm else self.match_spectrum_var.get()),
                        match_bandwidth=(False if _is_bgm else self.match_bandwidth_var.get()),
                        match_noisefloor=(False if _is_bgm else self.match_noisefloor_var.get()),
                        match_stereo=(False if _is_bgm else self.match_stereo_var.get()),
                        match_envelope=(False if _is_bgm else self.match_envelope_var.get()),
                        match_lufs=(False if _is_bgm else self.match_lufs_var.get()),
                        match_dynamics=(False if _is_bgm else self.match_dynamics_var.get())
                    )
                    new_name = Path(replace_file).stem
                    for tr2 in self.tracks:
                        if tr2["wave_id"] == tr_wid:
                            tr2["replaced"] = True
                            tr2["replaced_path"] = result_path
                            tr2["replaced_name"] = new_name
                            tr2["path"] = result_path
                            tr2["size"] = os.path.getsize(result_path)
                            break
                    self.replacements[tr_wid] = {
                        "source_file": replace_file,
                        "replaced_file": result_path,
                        "track_name": tr_name,
                        "replaced_name": new_name,
                        "awb_stem": tr_awb,
                        "real_index": tr_real,
                        "loop_start": loop_start,
                        "loop_end": loop_end,
                        "volume_gain": volume_gain,
                        "timestamp": time.time(),
                    }
                    ryo_info = None
                    if self.ryo_export_var.get() and not _is_bgm:
                        try:
                            ryo_info = self._deploy_ryo(result_path, tr_awb, tr_real)
                        except Exception as e:
                            ryo_info = ("error", str(e))
                    done.append((tr_name, tr_wid, result_path, ryo_info))
                self.save_replacements()
                if len(done) == 1:
                    tn, tw, rp, ri = done[0]
                    self.root.after(0, lambda: self._replace_done(tn, rp, ri))
                else:
                    self.root.after(0, lambda: self._replace_done_batch(done))
            except ADXToolError as e:
                err_msg = str(e)
                self.root.after(0, lambda msg=err_msg: self._replace_error(msg))
            except Exception as e:
                err_msg = f"替换失败: {e}"
                self.root.after(0, lambda msg=err_msg: self._replace_error(msg))

        threading.Thread(target=do_process, daemon=True).start()

    def _replace_done(self, track_name: str, result_path: str, ryo_info=None):
        self.refresh_track_list()
        self.replace_btn.config(state=NORMAL)
        self.restore_btn.config(state=NORMAL)
        self._update_status(f"替换成功: {track_name} -> {Path(result_path).name}")
        msg = f"曲目 [{track_name}] 已替换完成！"
        if ryo_info:
            kind, data = ryo_info
            if kind == "ok":
                changes = "；".join(data.get("enabled_changes") or [])
                msg += ("\n\nRyo 播放层控音量已部署（volume=" + str(data.get("volume")) + "）"
                        "\n" + changes +
                        "\n\n启动游戏即可生效。若 Reloaded-II 正在运行，请先重启一次。")
            else:
                msg += "\n\nRyo 部署失败（不影响替换结果）：" + str(data)
        else:
            msg += "\n\n可点击 导出 Mod 生成最终文件。"
        messagebox.showinfo("替换成功", msg)

    def _replace_done_batch(self, done):
        """批量替换完成汇总提示"""
        self.refresh_track_list()
        self.replace_btn.config(state=NORMAL)
        self.restore_btn.config(state=NORMAL)
        n = len(done)
        self._update_status(f"批量替换成功: {n} 个曲目")
        msg = f"已批量替换 {n} 个曲目：\n"
        ok_cues = 0
        for tn, tw, rp, ri in done:
            line = f"  {tw:05d} {tn} -> {Path(rp).name}"
            if ri and ri[0] == "ok":
                line += "（Ryo已部署）"
                ok_cues += 1
            elif ri and ri[0] == "error":
                line += f"（Ryo部署失败: {ri[1]}）"
            msg += line + "\n"
        msg += f"\nRyo Cue 部署成功 {ok_cues}/{n} 个"
        msg += "\n\n启动游戏即可生效。若 Reloaded-II 正在运行，请先重启一次。"
        messagebox.showinfo("批量替换成功", msg)

    def _deploy_ryo(self, adx_path: str, awb_stem: str, real_index: int):
        """部署 Ryo Framework mod，返回 ("ok", info) 或 ("error", msg)"""
        cue_name = None
        try:
            cache_path = Path("_acb_cache.json")
            if cache_path.exists():
                cache = json.loads(cache_path.read_text(encoding="utf-8"))
                entry = cache.get(awb_stem.upper(), {})
                hit = (entry.get("wave_to_cue") or {}).get(str(real_index))
                if hit and len(hit) > 1 and hit[1]:
                    cue_name = hit[1]
        except Exception:
            pass
        if not cue_name:
            return ("error", "未找到 " + str(awb_stem) + " wave " + str(real_index) + " 的 Cue 名称，无法部署 Ryo。")
        try:
            vol = float(self.ryo_volume_var.get().strip() or "0.5")
        except ValueError:
            vol = 0.5
        info = self.adx.deploy_ryo_to_reloaded(adx_path, awb_stem.upper(), cue_name, volume=vol)
        return ("ok", info)

    def _replace_error(self, msg):
        self.replace_btn.config(state=NORMAL)
        self._update_status(f"替换失败: {msg}")
        messagebox.showerror("替换失败", msg)

    def restore_track(self):
        """恢复原始曲目"""
        if not self.current_track:
            return

        t = self.current_track
        if not t.get("replaced"):
            return

        wave_id = t["wave_id"]
        for tr in self.tracks:
            if tr["wave_id"] == wave_id:
                tr["replaced"] = False
                tr["replaced_path"] = None
                tr.pop("replaced_name", None)
                tr["path"] = tr.get("original_path", tr["path"])
                tr["size"] = os.path.getsize(tr["path"]) if os.path.exists(tr["path"]) else tr["size"]
                break

        # 移除替换记录并保存
        if wave_id in self.replacements:
            del self.replacements[wave_id]
            self.save_replacements()

        self.refresh_track_list()
        self.restore_btn.config(state=DISABLED)
        self._update_status(f"已恢复原始曲目: {t['name']}")

    def show_replacements(self):
        """显示当前已保存的替换记录"""
        if not self.replacements:
            messagebox.showinfo("替换记录", "当前没有已保存的替换记录。\n\n替换音乐后会自动保存，重启软件后可恢复。")
            return

        lines = [f"共 {len(self.replacements)} 首替换：\n"]
        for wid in sorted(self.replacements.keys()):
            info = self.replacements[wid]
            track_name = info.get("track_name", f"ID {wid}")
            src = Path(info.get("source_file", "")).name
            lines.append(f"  [{wid}] {track_name}")
            lines.append(f"      ← {src}")

        lines.append("\n\n替换文件保存在 replaced/ 文件夹中")
        lines.append("重启软件后，导入 AWB/ADX 时自动恢复替换。")

        messagebox.showinfo("替换记录", "\n".join(lines))

    def clear_all_replacements(self):
        """清空全部替换记录（不删除 replaced 文件夹中的文件）"""
        if not self.replacements:
            messagebox.showinfo("提示", "当前没有替换记录")
            return

        confirm = messagebox.askyesno(
            "清空全部替换",
            f"确定要清空全部 {len(self.replacements)} 首替换记录吗？\n\n"
            f"此操作将撤销所有替换标记（replaced/ 文件夹中的文件将保留）。"
        )
        if not confirm:
            return

        # 撤销所有替换标记
        for tr in self.tracks:
            if tr.get("replaced"):
                tr["replaced"] = False
                tr["replaced_path"] = None
                tr["path"] = tr.get("original_path", tr["path"])

        self.replacements.clear()
        self.save_replacements()
        self.refresh_track_list()
        self._update_status("已清空全部替换记录")

    # ==================== 导出 ====================

    def export_mod(self):
        """导出 Reloaded-II Mod（可自定义 Mod 名称和简介）"""
        replaced = [t for t in self.tracks if t.get("replaced")]
        if not replaced:
            messagebox.showwarning("提示", "没有已替换的曲目，无法导出 Mod")
            return

        output_dir = filedialog.askdirectory(title="选择 Mod 输出目录")
        if not output_dir:
            return

        default_name = f"P5R_CustomBGM_{len(replaced)}tracks"
        default_desc = f"Custom BGM replacement for Persona 5 Royal ({len(replaced)} tracks)"

        # 弹出对话框让用户编辑 Mod 名称和简介
        info = self._ask_mod_info(default_name, default_desc)
        if info is None:  # 用户取消
            return
        mod_name, mod_desc = info
        mod_name = mod_name.strip() or default_name
        mod_desc = mod_desc.strip() or default_desc

        # 分组：流式音频（FEmulator/AWB/）和非流式音频（Ryo/P5R/）
        replaced_files = {}  # 流式: {awb_stem: {real_index: path}}
        non_streaming_files = {}  # 非流式: {acb_name: [{cue_id, cue_name, adx_path}]}
        for t in replaced:
            if t.get("is_non_streaming"):
                acb = t.get("acb_name", t.get("awb_stem", "UNKNOWN"))
                non_streaming_files.setdefault(acb, []).append({
                    "cue_id": t.get("cue_id"),
                    "cue_name": t.get("cue_name", ""),
                    "adx_path": t["replaced_path"],
                })
            else:
                stem = t.get("awb_stem", "BGM")
                idx = t.get("real_index", t["wave_id"])
                replaced_files.setdefault(stem, {})[idx] = t["replaced_path"]

        self._update_status("正在构建 Mod...")

        def do_export():
            try:
                mod_path = self.awb.build_mod_structure(
                    replaced_files, output_dir, mod_name, mod_desc,
                    non_streaming_files=non_streaming_files if non_streaming_files else None
                )
                self.root.after(0, lambda: self._export_done(mod_path, len(replaced)))
            except Exception as e:
                err_msg = str(e)
                self.root.after(0, lambda msg=err_msg: self._export_error(msg))

        threading.Thread(target=do_export, daemon=True).start()

    def _ask_mod_info(self, default_name: str, default_desc: str):
        """弹出对话框让用户输入/编辑 Mod 名称和简介，返回 (名称, 简介)，取消返回 None"""
        dialog = Toplevel(self.root)
        dialog.title("Mod 信息")
        dialog.geometry("480x320")
        dialog.resizable(False, False)
        dialog.transient(self.root)
        dialog.grab_set()

        # 居中显示
        dialog.update_idletasks()
        x = self.root.winfo_rootx() + (self.root.winfo_width() - 480) // 2
        y = self.root.winfo_rooty() + (self.root.winfo_height() - 320) // 2
        dialog.geometry(f"+{x}+{y}")

        result = {"value": None}

        # 名称输入
        Label(dialog, text="Mod 名称：", font=("Arial", 10, "bold")).pack(pady=(15, 3))
        name_var = StringVar(value=default_name)
        name_entry = Entry(dialog, textvariable=name_var, width=50)
        name_entry.pack(padx=20, pady=(0, 2))
        name_entry.select_range(0, END)  # 全选便于直接输入
        name_entry.focus_set()
        Label(dialog, text="显示在 Reloaded-II 列表中的名称（也是文件夹名）",
              fg="gray", font=("Arial", 8)).pack()

        # 简介输入
        Label(dialog, text="Mod 简介：", font=("Arial", 10, "bold")).pack(pady=(12, 3))
        desc_text = Text(dialog, width=50, height=5, font=("Arial", 9))
        desc_text.pack(padx=20, pady=(0, 2))
        desc_text.insert("1.0", default_desc)
        Label(dialog, text="显示在 Reloaded-II 中的 Mod 描述（可选，留空用默认）",
              fg="gray", font=("Arial", 8)).pack()

        def on_ok():
            result["value"] = (name_var.get(), desc_text.get("1.0", "end-1c"))
            dialog.destroy()

        def on_cancel():
            dialog.destroy()

        btn_row = Frame(dialog)
        btn_row.pack(pady=10)
        Button(btn_row, text="确定", command=on_ok, width=10, bg="#4CAF50", fg="white").pack(side=LEFT, padx=10)
        Button(btn_row, text="取消", command=on_cancel, width=10).pack(side=LEFT, padx=10)

        dialog.bind('<Escape>', lambda e: on_cancel())

        # 等待对话框关闭
        dialog.wait_window()
        return result["value"]

    def _export_done(self, mod_path: str, count: int):
        self._update_status(f"Mod 导出成功: {mod_path}")
        messagebox.showinfo(
            "导出成功",
            f"Mod 已生成！\n\n"
            f"路径: {mod_path}\n"
            f"包含 {count} 首替换曲目\n\n"
            f"使用方法:\n"
            f"1. 将此文件夹复制到 Reloaded-II 的 Mods 目录\n"
            f"2. 在 Reloaded-II 中启用该 Mod\n"
            f"3. 确保已启用 P5R Essentials 作为依赖\n"
            f"4. 启动游戏即可"
        )

    def _export_error(self, msg):
        self._update_status(f"导出失败: {msg}")
        messagebox.showerror("导出失败", msg)

    # ==================== 工具设置 ====================

    def set_tools_dir(self):
        """设置工具目录"""
        folder = filedialog.askdirectory(title="选择工具目录（包含 adxencd.exe, vgaudiocli.exe 等）")
        if folder:
            self.tools_dir.set(folder)
            self.adx = ADXProcessor(folder)
            self.awb = AWBExtractor(folder)
            self.save_config()
            self._update_status(f"工具目录已设置: {folder}")
            self._check_tools_async()

    def edit_bgm_names(self):
        """编辑曲名数据库"""
        # 简单的编辑窗口
        editor = Toplevel(self.root)
        editor.title("编辑曲名数据库")
        editor.geometry("600x500")

        frame = Frame(editor)
        frame.pack(fill=BOTH, expand=True, padx=10, pady=10)

        Label(frame, text="格式: WaveID=曲名（每行一个）", font=("Arial", 9, "bold")).pack(anchor=W)

        text = Text(frame, wrap="none", font=("Consolas", 10))
        text.pack(fill=BOTH, expand=True, pady=5)

        # 填充现有数据
        for wid in sorted(BGM_NAMES.keys()):
            text.insert(END, f"{wid}={BGM_NAMES[wid]}\n")

        def save_names():
            content = text.get("1.0", END)
            try:
                for line in content.strip().split('\n'):
                    if '=' in line:
                        parts = line.split('=', 1)
                        wid = int(parts[0].strip())
                        name = parts[1].strip()
                        BGM_NAMES[wid] = name
                self.refresh_track_list()
                editor.destroy()
                self._update_status("曲名数据库已更新")
            except Exception as e:
                messagebox.showerror("保存失败", f"格式错误: {e}")

        Button(frame, text="保存", command=save_names, bg="#4CAF50", fg="white", width=15).pack(pady=5)

    # ==================== 帮助 ====================

    def show_help(self):
        """显示使用说明"""
        help_text = f"""
P5R BGM Editor 使用说明 v{APP_VERSION}
========================================

【工具简介】
支持 BGM / 音效 / 角色语音三类音频的导入、识别、试听与替换，
自动完成 转WAV → ADX编码 → P5R加密 → 多维音频对齐，并生成
Reloaded-II（AWB Emulator + Ryo Framework）兼容的 Mod。

【快速开始】
1. 文件 → 导入 BASE.CPK 所在的文件夹（选择游戏 CPK 目录）
   - 自动解包并识别 BGM、音效、角色语音三类音频
   - 也可：导入 BGM.AWB / 导入已解包的 ADX 文件夹
2. 顶部切换「BGM / 音效 / 角色语音」选项卡查看音频列表
3. 列表中选择要替换的曲目，右侧查看详情
4. 点击「选择音乐文件」选择音频（MP3/WAV/OGG/FLAC/M4A）
5. 按需设置高级选项（对齐 / 循环点 / 音量 / Ryo音量 / 批量范围）
6. 点击「执行替换」：自动 转WAV → ADX编码 → P5R加密 → 对齐
7. 替换完成后「导出 Mod」生成 Reloaded-II Mod

【三类音频】
- BGM：背景音乐（主BGM + 额外BGM BGM_01~16）
  · 替换即换曲；高级对齐勾选项在 BGM 界面自动隐藏（无需调整）
- 音效：游戏音效（E*_SE.AWB、SYSTEM.ACB、TITLE.ACB 等，含标题音效 232000~232003）
  · 等长匹配默认开启（防止无声/偏移）；支持重复音频折叠（▶ 展开同组）
- 角色语音：角色台词（BP01~BP10 战斗语音、VOICE_*.AWB、EVENT 场景语音等）
  · 已支持替换：走 Ryo 路径可完整播放超长音频（不受原时长限制）
  · 等长匹配默认关闭（仅音效需要强制等长）
  · 支持 AI 识别台词、翻译、台词标注、校准映射
  · 下拉菜单按角色分类：BP01=Joker, BP02=Skull, BP03=Panther, BP04=Fox,
    BP05=Queen, BP06=Navi, BP07=Crow, BP09=Violet（BP08 游戏中不存在）

【列表颜色说明】
- 黑色：主BGM   橙色：额外BGM   蓝色：游戏音效
- 紫色：角色语音  绿色：已替换  灰色：空槽位占位符

【替换高级选项（音效/语音界面显示）】
- 等长匹配原版：自动补齐/截断到原音频时长（音效默认开；语音Ryo下可关）
- 响度匹配原版：RMS 电平对齐原版，防止游戏内爆音
- 频谱对齐原版：整形各频段能量到原版轮廓，防止低频轰头/“炸”
- 带宽对齐：限幅到原版频段范围
- 底噪对齐：压掉过高的底噪
- 立体声宽度：声场对齐原版
- 包络对齐：起始包络（attack）形状贴近原版
- 感知响度 LUFS：人耳感知等响度对齐
- 动态限幅：压制瞬态过冲，兜底防爆
- Ryo 播放层控音量：volume=0.5，防止游戏内音量被自动放大（需 Ryo Framework）
- 循环起点/终点：样本数表示（44100Hz 下 1 秒=44100 样本），-1=末尾
- 音量增益：倍（1.0=原音量；P5R 播放偏安静时建议 1.5~2.5）
- 批量替换范围：如 232000-232003；留空=仅当前曲目（自动补齐全部 Ryo Cue）
- 重置为默认：恢复全部推荐值

【AI 语音识别翻译（角色语音）】
- 选中语音后点击「AI识别台词」
- 内置 Whisper medium 微调模型（P5R 日文识别）+ NLLB-200 int8 翻译模型
- 自动识别日文并翻译为中文，辅助台词标注
- 首次使用需加载模型（约 10-30 秒），后续更快
- 翻译词表参考 bilibili 游戏 wiki 与萌娘百科，优先使用官方译名

【台词标注与校准映射（角色语音）】
- 右侧中文台词列表显示该场景完整台词，选中语音对应台词自动标绿
- 「编辑标注」手动修改语音对应台词
- 「校准映射」：一句话对应两段语音时，可手动分割校准
- 标注随工具发布，他人可见

【试听功能】
- 选中曲目后「播放」试听原曲或替换后的音乐
- 支持暂停/继续/停止，可拖动进度条跳转
- 极短音效可勾选「极短音频循环播放5次」
- 播放到结尾自动停止（不循环）

【导出 Mod / 导出原曲 WAV】
- 文件 → 导出 Mod：可自定义 Mod 名称和简介
  · BGM/音效替换走 AWB Emulator（FEmulator/AWB/）
  · 非流式音频（SYSTEM/VOICE_SINGLEWORD/TITLE）自动走 Ryo Framework
  · 自动配置 Ryo 为依赖项，Reloaded-II 会自动提示安装
- 导出原曲 WAV：将选中的原曲解密为 WAV（保持原采样率）

【所需工具】（tools 目录；可通过 工具 → 设置工具目录 指定）
- VGAudioCli.exe：ADX 加密/解密/编码（必需）
- adxencd.exe：ADX 编码备选（CRI 官方专有工具）
- ffmpeg.exe：音频格式转换（必需）
- CriFsV2Lib/：CPK 解包 .NET 库（导入 BASE.CPK 所在文件夹时需要）
- CriPakTools / vgmstream：CPK 解包 / 音频解码备选
- 工具 → 工具完整性管理：自动校验 / 备份 / 恢复 tools 目录

【AI 模型】（models 目录，可选；角色语音识别翻译需要）
- faster-whisper-medium-p5r-v4-local/：日文语音识别模型（默认）
- faster-whisper-small-p5r-v2/：轻量备用
- nllb-200-distilled-600M-ct2-int8/：日中翻译模型（加载用）
- nllb-200-distilled-600M-p5r-v2-ct2-int8/：翻译可用性检测
- 首次使用自动加载，模型缺失时自动下载

【P5R 加密参数】
- 密钥: 9923540143823782
- 偏移19字节: 0x09

【注意事项】
- 替换前建议备份原始文件
- BGM 建议设置合适循环点，否则播放完会静音
- 导出 Mod 需要 Reloaded-II + P5R Essentials + CRI FileSystem V2 Hook 加载
- 非流式音频替换还需 Ryo Framework（Mod Browser 搜索安装）
- 若游戏内音量偏大：调低「Ryo 播放层控音量」（默认 0.5）
- AI 识别翻译仅供参考，建议结合手动标注校准

【彩蛋】
- 菜单栏右侧「魔罗」：作者的小彩蛋，点击可欣赏魔罗大人的雄伟～
        """
        help_win = Toplevel(self.root)
        help_win.title("使用说明")
        help_win.geometry("720x760")
        text_frame = Frame(help_win)
        text_frame.pack(fill=BOTH, expand=True)
        text = Text(text_frame, wrap="word", font=("Microsoft YaHei", 10), padx=12, pady=10)
        scroll = Scrollbar(text_frame, command=text.yview)
        text.configure(yscrollcommand=scroll.set)
        text.pack(side=LEFT, fill=BOTH, expand=True)
        scroll.pack(side=RIGHT, fill=Y)
        text.insert(END, help_text)
        text.config(state="disabled")


    def show_voice_text_research(self):
        """显示实机语音字幕溯源研究报告（帮助内查看）"""
        base_dir = os.path.dirname(os.path.abspath(__file__))
        report_path = os.path.join(base_dir, "VOICE_TEXT_RESEARCH.md")
        if not os.path.exists(report_path):
            messagebox.showinfo(
                "提示",
                "未找到研究报告文件 VOICE_TEXT_RESEARCH.md\n"
                "请确认该文件与 main.py 在同一目录。"
            )
            return
        try:
            with open(report_path, "r", encoding="utf-8") as f:
                content = f.read()
        except Exception as e:
            messagebox.showerror("错误", f"读取研究报告失败：{e}")
            return

        win = Toplevel(self.root)
        win.title("实机语音字幕溯源研究报告")
        win.geometry("860x740")

        text = Text(win, wrap="word", font=("Microsoft YaHei", 10), padx=14, pady=12)
        text.pack(fill=BOTH, expand=True)
        text.insert(END, content)
        text.config(state="disabled")

        footer = Label(
            win,
            text=f"完整文档：{report_path}（可另用 Markdown 编辑器打开）",
            font=("Microsoft YaHei", 8),
            fg="gray",
        )
        footer.pack(side=BOTTOM, fill=X, padx=8, pady=4)


    def show_ai_research(self):
        """显示 AI 语音识别与翻译研究报告（帮助内查看）"""
        base_dir = os.path.dirname(os.path.abspath(__file__))
        report_path = os.path.join(base_dir, "AI_RESEARCH.md")
        if not os.path.exists(report_path):
            messagebox.showinfo(
                "提示",
                "未找到研究报告文件 AI_RESEARCH.md\n"
                "请确认该文件与 main.py 在同一目录。"
            )
            return
        try:
            with open(report_path, "r", encoding="utf-8") as f:
                content = f.read()
        except Exception as e:
            messagebox.showerror("错误", f"读取研究报告失败：{e}")
            return

        win = Toplevel(self.root)
        win.title("AI 语音识别与翻译研究报告")
        win.geometry("900x760")

        text = Text(win, wrap="word", font=("Microsoft YaHei", 10), padx=14, pady=12)
        text.pack(fill=BOTH, expand=True)
        text.insert(END, content)
        text.config(state="disabled")

        footer = Label(
            win,
            text=f"完整文档：{report_path}（可另用 Markdown 编辑器打开）",
            font=("Microsoft YaHei", 8),
            fg="gray",
        )
        footer.pack(side=BOTTOM, fill=X, padx=8, pady=4)


    def show_sfx_replace_research(self):
        """显示音效替换调查报告（帮助内查看）"""
        base_dir = os.path.dirname(os.path.abspath(__file__))
        report_path = os.path.join(base_dir, "SFX_REPLACE_RESEARCH.md")
        if not os.path.exists(report_path):
            messagebox.showinfo(
                "提示",
                "未找到调查报告文件 SFX_REPLACE_RESEARCH.md\n"
                "请确认该文件与 main.py 在同一目录。"
            )
            return
        try:
            with open(report_path, "r", encoding="utf-8") as f:
                content = f.read()
        except Exception as e:
            messagebox.showerror("错误", f"读取调查报告失败：{e}")
            return

        win = Toplevel(self.root)
        win.title("音效替换调查报告")
        win.geometry("900x780")

        text = Text(win, wrap="word", font=("Microsoft YaHei", 10), padx=14, pady=12)
        text.pack(fill=BOTH, expand=True)
        text.insert(END, content)
        text.config(state="disabled")

        footer = Label(
            win,
            text=f"完整文档：{report_path}（可另用 Markdown 编辑器打开）",
            font=("Microsoft YaHei", 8),
            fg="gray",
        )
        footer.pack(side=BOTTOM, fill=X, padx=8, pady=4)


    def show_about(self):
        """显示关于（带可点击项目仓库链接）"""
        import webbrowser

        win = Toplevel(self.root)
        win.title("关于")
        win.geometry("500x600")
        win.resizable(False, False)
        win.transient(self.root)
        win.grab_set()

        # 居中显示
        win.update_idletasks()
        x = self.root.winfo_rootx() + (self.root.winfo_width() - 500) // 2
        y = self.root.winfo_rooty() + (self.root.winfo_height() - 560) // 2
        win.geometry(f"+{x}+{y}")

        # 顶部标题栏
        header = Frame(win, bg="#2C3E50")
        header.pack(fill=X)
        Label(header, text=f"P5R BGM Editor v{APP_VERSION}", font=("Arial", 18, "bold"),
              fg="white", bg="#2C3E50").pack(pady=(18, 2))
        Label(header, text="女神异闻录5皇家版 · 音乐/音效/语音 替换工具",
              font=("Microsoft YaHei", 10), fg="#BDC3C7", bg="#2C3E50").pack(pady=(2, 16))

        # 主体
        body = Frame(win)
        body.pack(fill=BOTH, expand=True, padx=24, pady=16)

        # 功能列表
        Label(body, text="功能特性", font=("Microsoft YaHei", 11, "bold"),
              anchor="w").pack(fill=X)
        features = [
            "BASE.CPK 自动解包（BGM + 音效 + 角色语音）",
            "三选项卡：BGM / 音效 / 角色语音",
            "ACB 解析自动识别曲名（Cue 名称）",
            "ADX 试听预览（可拖动进度条）",
            "一键音乐替换（自动转码+编码+加密）",
            "自定义循环点与音量增益",
            "导出原曲 WAV",
            "Reloaded-II Mod 导出（自定义名称/简介）",
            "非流式音频自动适配 Ryo Framework",
            "替换记录自动保存，重启恢复",
            "列表颜色区分（主BGM/额外BGM/音效/语音/已替换/空槽位）",
            "音效重复音频检测折叠（相同音频分组）",
            "角色语音按角色分类（BP01~BP10，含Joker/Skull/Panther等）",
            "AI 日文语音识别 + 中文翻译（Whisper small 微调 + NLLB-200）",
            "台词标注与校准映射（一句话对应多语音手动分割）",
            "SOUND_J.CPK 全量 ACB 合并（4700+ ACB，含战斗/事件/地牢语音）",
            "VOICE_DUNGEON 系列 cue 名修复（5958 wave 正确解析）",
        ]
        for feat in features:
            Label(body, text=f"  • {feat}", font=("Microsoft YaHei", 9),
                  fg="#34495E", anchor="w").pack(fill=X, pady=1)

        # 分隔线
        Frame(body, height=1, bg="#D5DBDB").pack(fill=X, pady=12)

        # 项目仓库（可点击链接）
        Label(body, text="项目仓库", font=("Microsoft YaHei", 11, "bold"),
              anchor="w").pack(fill=X)
        repo_row = Frame(body)
        repo_row.pack(fill=X, pady=(4, 2))
        Label(repo_row, text="GitHub 仓库：", font=("Microsoft YaHei", 9),
              width=12, anchor="w").pack(side=LEFT)
        repo_link = Label(repo_row, text="github.com/kaimeng114514/P5R-BGM-Editor（点击打开）",
                           font=("Microsoft YaHei", 9), fg="#1E6FD9", cursor="hand2")
        repo_link.pack(side=LEFT)
        repo_link.bind("<Button-1>", lambda e: webbrowser.open("https://github.com/kaimeng114514/P5R-BGM-Editor"))

        release_row = Frame(body)
        release_row.pack(fill=X, pady=2)
        Label(release_row, text="最新 Release：", font=("Microsoft YaHei", 9),
              width=12, anchor="w").pack(side=LEFT)
        release_link = Label(release_row, text="Releases 页面（点击打开）",
                              font=("Microsoft YaHei", 9), fg="#1E6FD9", cursor="hand2")
        release_link.pack(side=LEFT)
        release_link.bind("<Button-1>", lambda e: webbrowser.open("https://github.com/kaimeng114514/P5R-BGM-Editor/releases"))

        # 分隔线
        Frame(body, height=1, bg="#D5DBDB").pack(fill=X, pady=12)

        # 作者信息
        Label(body, text="作者信息", font=("Microsoft YaHei", 11, "bold"),
              anchor="w").pack(fill=X)
        Label(body, text="工具作者：凯梦", font=("Microsoft YaHei", 9),
              fg="#34495E", anchor="w").pack(fill=X, pady=1)
        bili_row = Frame(body)
        bili_row.pack(fill=X, pady=1)
        Label(bili_row, text="B站主页：", font=("Microsoft YaHei", 9),
              width=12, anchor="w").pack(side=LEFT)
        bili_link = Label(bili_row, text="b23.tv/wisObQo（点击打开）",
                          font=("Microsoft YaHei", 9), fg="#1E6FD9", cursor="hand2")
        bili_link.pack(side=LEFT)
        bili_link.bind("<Button-1>", lambda e: webbrowser.open("https://b23.tv/wisObQo"))

        douyin_row = Frame(body)
        douyin_row.pack(fill=X, pady=1)
        Label(douyin_row, text="抖音主页：", font=("Microsoft YaHei", 9),
              width=12, anchor="w").pack(side=LEFT)
        douyin_link = Label(douyin_row, text="抖音（点击打开）",
                            font=("Microsoft YaHei", 9), fg="#1E6FD9", cursor="hand2")
        douyin_link.pack(side=LEFT)
        douyin_link.bind("<Button-1>", lambda e: webbrowser.open("https://www.douyin.com/user/self?from_tab_name=main"))

        # 底部
        Label(win, text="基于 P5R Modding 社区研究成果开发",
              font=("Microsoft YaHei", 8), fg="#7F8C8D").pack(pady=(0, 4))
        Button(win, text="关闭", command=win.destroy, width=12,
               bg="#4CAF50", fg="white", font=("Microsoft YaHei", 10)).pack(pady=8)

        # Esc 关闭
        win.bind('<Escape>', lambda e: win.destroy())


    def _open_bilibili(self):
        """打开作者 B站主页"""
        import webbrowser
        webbrowser.open("https://b23.tv/wisObQo")

    def show_author_info(self):
        """显示作者详细介绍窗口"""
        import webbrowser

        win = Toplevel(self.root)
        win.title("作者信息")
        win.geometry("560x840")
        win.resizable(False, False)
        win.transient(self.root)
        win.grab_set()

        # 居中显示
        win.update_idletasks()
        x = self.root.winfo_rootx() + (self.root.winfo_width() - 500) // 2
        y = self.root.winfo_rooty() + (self.root.winfo_height() - 800) // 2
        win.geometry(f"+{x}+{y}")

        # 顶部：工具名称 + 版本
        header = Frame(win, bg="#2C3E50")
        header.pack(fill=X)
        Label(header, text=f"P5R BGM Editor v{APP_VERSION}", font=("Arial", 20, "bold"),
              fg="white", bg="#2C3E50").pack(pady=(22, 2))
        Label(header, text=f"女神异闻录5皇家版 · 音乐替换工具 v{APP_VERSION}",
              font=("Microsoft YaHei", 10), fg="#BDC3C7", bg="#2C3E50").pack(pady=(2, 20))

        # 主体信息
        body = Frame(win)
        body.pack(fill=BOTH, expand=True, padx=30, pady=20)

        # 作者信息行
        author_row = Frame(body)
        author_row.pack(fill=X, pady=6)
        Label(author_row, text="工具作者", font=("Microsoft YaHei", 11, "bold"),
              width=10, anchor="w").pack(side=LEFT)
        Label(author_row, text="凯梦", font=("Microsoft YaHei", 11),
              fg="#2C3E50").pack(side=LEFT)

        # B站主页（可点击）
        bili_row = Frame(body)
        bili_row.pack(fill=X, pady=6)
        Label(bili_row, text="B站主页", font=("Microsoft YaHei", 11, "bold"),
              width=10, anchor="w").pack(side=LEFT)
        bili_link = Label(bili_row, text="b23.tv/wisObQo（点击打开）",
                          font=("Microsoft YaHei", 11), fg="#1E6FD9", cursor="hand2")
        bili_link.pack(side=LEFT)
        bili_link.bind("<Button-1>", lambda e: webbrowser.open("https://b23.tv/wisObQo"))

        # 抖音主页（可点击）
        douyin_row = Frame(body)
        douyin_row.pack(fill=X, pady=6)
        Label(douyin_row, text="抖音主页", font=("Microsoft YaHei", 11, "bold"),
              width=10, anchor="w").pack(side=LEFT)
        douyin_link = Label(douyin_row, text="抖音（点击打开）",
                            font=("Microsoft YaHei", 11), fg="#1E6FD9", cursor="hand2")
        douyin_link.pack(side=LEFT)
        douyin_link.bind("<Button-1>", lambda e: webbrowser.open("https://www.douyin.com/user/self?from_tab_name=main"))

        # 分隔线
        Frame(body, height=1, bg="#D5DBDB").pack(fill=X, pady=16)

        # 工具简介
        Label(body, text="工具简介", font=("Microsoft YaHei", 11, "bold"),
              anchor="w").pack(fill=X)
        intro_text = (
            "专为《女神异闻录5皇家版》(P5R) 打造的音乐替换工具。\n\n"
            "支持 BGM.AWB 解包、曲目识别与试听预览，\n"
            "可一键将你自己的音乐替换进游戏，\n"
            "并自动完成编码加密、生成 Reloaded-II Mod，\n"
            "让游戏 BGM 随心而变。"
        )
        Label(body, text=intro_text, font=("Microsoft YaHei", 10),
              fg="#34495E", justify="left", anchor="w").pack(fill=X, pady=(6, 0))

        # 分隔线
        Frame(body, height=1, bg="#D5DBDB").pack(fill=X, pady=16)

        # 参考工具（使用的全部第三方开源工具，注明作者并向其致谢）
        Label(body, text="参考工具（向开源作者致谢）", font=("Microsoft YaHei", 11, "bold"),
              anchor="w").pack(fill=X, pady=(0, 4))
        ref_frame = Frame(body)
        ref_frame.pack(fill=BOTH, expand=True)
        ref_text = Text(ref_frame, height=22, width=60, font=("Microsoft YaHei", 9),
                        wrap=WORD, relief=GROOVE, bd=1, padx=8, pady=6)
        ref_scroll = Scrollbar(ref_frame, command=ref_text.yview)
        ref_text.configure(yscrollcommand=ref_scroll.set)
        ref_text.pack(side=LEFT, fill=BOTH, expand=True)
        ref_scroll.pack(side=RIGHT, fill=Y)
        # 可点击开源工具清单：(分类, 项目名, 用途, 作者, GitHub URL)
        ref_items = [
            ("【音频编码 / 解码】", "VGAudio / VGAudioCli", "ADX 编码、加密、解密", "Thealexbarney (Alex Barney)", "https://github.com/Thealexbarney/VGAudio"),
            ("", "vgmstream", "游戏音频解码", "bnnm 等", "https://github.com/vgmstream/vgmstream"),
            ("", "FFmpeg", "音频格式转换", "FFmpeg 开源团队", "https://github.com/FFmpeg/FFmpeg"),
            ("【CPK 解包】", "CriFsV2Lib", "CPK 解包 .NET 库", "Sewer56", "https://github.com/Sewer56/CriFsV2Lib"),
            ("", "CriPakTools", "CPK 解包备选", "esperknight", "https://github.com/esperknight/CriPakTools"),
            ("【剧情 / 文本】", "Atlus-Script-Tools", "AtlusScriptCompiler 脚本编译/反编译", "tge-was-taken", "https://github.com/tge-was-taken/Atlus-Script-Tools"),
            ("", "AtlusMSGEditor", "对话文本编辑", "tge-was-taken", "https://github.com/tge-was-taken/AtlusMSGEditor"),
            ("", "PersonaVCE", "Persona 语音剪辑", "ShrineFox", "https://github.com/ShrineFox/PersonaVoiceClipEditor"),
            ("【Mod 加载与音频替换】", "Reloaded-II", "Mod 加载器", "Sewer56", "https://github.com/Reloaded-Project/Reloaded-II"),
            ("", "FileEmulationFramework", "AWB Emulator", "Sewer56", "https://github.com/Sewer56/FileEmulationFramework"),
            ("", "Ryo Framework", "非流式音频替换", "RyoTune", "https://github.com/RyoTune/Ryo"),
            ("【AI 语音识别 / 翻译】", "faster-whisper", "语音识别引擎", "SYSTRAN (Guillaume Klein)", "https://github.com/SYSTRAN/faster-whisper"),
            ("", "Whisper", "语音识别模型", "OpenAI", "https://github.com/openai/whisper"),
            ("", "ctranslate2", "模型推理引擎", "OpenNMT (Guillaume Klein)", "https://github.com/OpenNMT/CTranslate2"),
            ("", "sentencepiece", "分词工具", "Google (Taku Kudo)", "https://github.com/google/sentencepiece"),
            ("", "NLLB", "多语言翻译模型", "Meta AI (FAIR)", "https://github.com/facebookresearch/fairseq"),
            ("【Python 依赖库】", "PyTorch", "深度学习框架", "Meta / PyTorch 团队", "https://github.com/pytorch/pytorch"),
            ("", "numpy", "数值计算", "numpy 社区", "https://github.com/numpy/numpy"),
            ("", "scipy", "科学计算", "scipy 社区", "https://github.com/scipy/scipy"),
            ("", "pydub", "音频处理", "Jiaaro", "https://github.com/jiaaro/pydub"),
            ("", "pygame", "音频播放", "pygame 社区", "https://github.com/pygame/pygame"),
            ("", "Pillow / PIL", "图像处理", "Pillow 团队", "https://github.com/python-pillow/Pillow"),
            ("", "pythonnet", ".NET 互操作", "pythonnet 社区", "https://github.com/pythonnet/pythonnet"),
        ]
        ref_text.insert("1.0", "（点击蓝色项目名可打开对应开源项目主页）\n\n")
        ref_text.tag_config("link", foreground="#1E6FD9", underline=True, font=("Microsoft YaHei", 9, "underline"))
        ref_text.tag_config("cat", font=("Microsoft YaHei", 9, "bold"), foreground="#2C3E50")
        for i, (cat, name, usage, author, url) in enumerate(ref_items):
            if cat:
                ref_text.insert("end", cat + "\n", "cat")
            ref_text.insert("end", "• ")
            tag = "link%d" % i
            ref_text.insert("end", name, tag)
            ref_text.tag_config(tag, foreground="#1E6FD9", underline=True)
            ref_text.tag_bind(tag, "<Button-1>", lambda e, u=url: webbrowser.open(u))
            ref_text.insert("end", "（%s）· %s\n" % (usage, author))
        ref_text.insert("end", "\n注：备选编码器 adxencd.exe 为 CRI 官方专有工具（非开源）。\n"
                               "衷心感谢以上所有开源项目与作者的无私奉献，本工具得以完成！")
        ref_text.config(state=DISABLED)

        # 分隔线
        Frame(body, height=1, bg="#D5DBDB").pack(fill=X, pady=16)

        # 感谢语
        Label(body, text="感谢使用 P5R BGM Editor，祝你游戏愉快！",
              font=("Microsoft YaHei", 9), fg="#7F8C8D").pack(pady=(0, 4))

        # 关闭按钮
        Button(win, text="关闭", command=win.destroy, width=12,
               bg="#4CAF50", fg="white", font=("Microsoft YaHei", 10)).pack(pady=12)

        # Esc 关闭
        win.bind('<Escape>', lambda e: win.destroy())

    def show_moro(self):
        """显示魔罗图片展示窗口"""
        img_path = Path("assets/moro.png")
        if not img_path.exists():
            messagebox.showwarning("提示", f"魔罗图片未找到:\n{img_path}")
            return

        win = Toplevel(self.root)
        win.title("魔罗")
        win.resizable(False, False)
        win.transient(self.root)
        win.grab_set()

        # 加载并缩放图片（最大高度 420）
        try:
            if HAS_PIL:
                img = Image.open(str(img_path))
                max_h = 420
                if img.height > max_h:
                    ratio = max_h / img.height
                    new_w = int(img.width * ratio)
                    img = img.resize((new_w, max_h), Image.LANCZOS)
                photo = ImageTk.PhotoImage(img)
                img_w, img_h = img.width, img.height
            else:
                photo = PhotoImage(file=str(img_path))
                img_w, img_h = photo.width(), photo.height()
        except Exception as e:
            messagebox.showerror("错误", f"加载魔罗图片失败:\n{e}")
            return

        # 内容区：左图右文
        content = Frame(win)
        content.pack(padx=18, pady=18)

        img_label = Label(content, image=photo, bd=2, relief=GROOVE)
        img_label.image = photo  # 保持引用防止被回收
        img_label.pack(side=LEFT, padx=(0, 18))

        text_frame = Frame(content)
        text_frame.pack(side=LEFT, fill=BOTH, expand=True)

        Label(text_frame, text="魔罗", font=("Microsoft YaHei", 20, "bold"),
              fg="#2C3E50").pack(anchor=W, pady=(0, 14))

        Label(text_frame,
              text="这个功能没什么用，就是作者单纯想展示一下魔罗",
              wraplength=240, justify=LEFT,
              font=("Microsoft YaHei", 11), fg="#34495E").pack(anchor=W, pady=(0, 20))

        Label(text_frame,
              text="哦齁齁齁哦哦真是雄伟呢魔罗大人～",
              wraplength=240, justify=LEFT,
              font=("Microsoft YaHei", 13, "bold"), fg="#E67E22").pack(anchor=W)

        # 关闭按钮
        Button(win, text="关闭", command=win.destroy, width=12,
               bg="#4CAF50", fg="white", font=("Microsoft YaHei", 10)).pack(pady=(0, 16))

        # Esc 关闭
        win.bind('<Escape>', lambda e: win.destroy())

        # 居中显示
        win.update_idletasks()
        w = win.winfo_width()
        h = win.winfo_height()
        x = self.root.winfo_rootx() + (self.root.winfo_width() - w) // 2
        y = self.root.winfo_rooty() + (self.root.winfo_height() - h) // 2
        win.geometry(f"+{max(x,0)}+{max(y,0)}")


def _is_model_preloading():
    """检查 AI 模型是否正在后台预加载"""
    try:
        import voice_ai
        # 预加载已启动但未完成 = 正在加载中
        return getattr(voice_ai, "_preload_started", False) and not voice_ai.is_preloaded()
    except Exception:
        return False


def main():
    root = Tk()

    # 设置主题样式
    style = ttk.Style()
    try:
        style.theme_use('clam')
    except Exception:
        pass

    app = P5RBGMEditor(root)

    # 窗口关闭时保存配置
    def on_close():
        app.save_config()
        app.stop_preview()
        root.destroy()

    root.protocol("WM_DELETE_WINDOW", on_close)
    root.mainloop()


if __name__ == "__main__":
    main()

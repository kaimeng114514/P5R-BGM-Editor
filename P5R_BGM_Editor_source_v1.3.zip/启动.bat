@echo off
chcp 65001 >nul
title P5R BGM Editor
cd /d "%~dp0"
echo ========================================
echo   P5R BGM Editor - 启动中...
echo ========================================
echo.

REM 尝试多种 Python 启动命令
where py >nul 2>nul
if %errorlevel%==0 (
    echo 使用 py 启动器启动...
    py main.py
    goto :check
)

where python >nul 2>nul
if %errorlevel%==0 (
    echo 使用 python 启动...
    python main.py
    goto :check
)

where python3 >nul 2>nul
if %errorlevel%==0 (
    echo 使用 python3 启动...
    python3 main.py
    goto :check
)

echo.
echo [错误] 未找到 Python！
echo 请安装 Python 3.8+ 并勾选 "Add Python to PATH"
echo 下载地址: https://www.python.org/downloads/
echo.
pause
exit /b 1

:check
if errorlevel 1 (
    echo.
    echo 程序运行出错，错误码: %errorlevel%
    echo 请检查上方错误信息。
    pause
)

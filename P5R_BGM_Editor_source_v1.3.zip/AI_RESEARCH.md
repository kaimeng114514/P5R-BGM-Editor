# P5R AI 语音识别与翻译研究报告

> 本文档记录本项目对《女神异闻录5 皇家版》(P5R) 的 **AI 语音识别** 与 **AI 翻译** 的完整研究历程、方法论、成果数据与踩坑教训。
> 写给后来的工具维护者 / 模型训练者——**避免重复走 v5-v8 的弯路**，直接使用已验证的最优路线（v4）。
> 配套文档：《VOICE_TEXT_RESEARCH.md》（实机语音字幕溯源，为什么文本不在文件里）。

---

## 一、一句话结论

**最终成果：`faster-whisper-medium-p5r-v4-local`（v4）已全面超越 small 基线。**
- 全量 696 条验证：读音匹配 **69.3%** vs small 36.9%；平均 WER **30.7%** vs 63.1%。
- 四档句长（≤15 / 16-25 / 26-40 / >40 字符）**全部领先**（81.0 / 63.4 / 66.7 / 58.7% vs 60.3 / 40.4 / 24.0 / 3.2%）。
- 九难句（E100_101 wave6-14）：**9/9** vs small 3/9。
- 翻译链路：**NLLB-600M 微调（日→中）+ P5R 专有词表 + 官方翻译查表** 三级兜底，已内置于工具。

---

## 二、研究背景（为什么要做 AI 识别）

1. P5R 大量 **"实机流程语音字幕"**（如开场「好，开始逃走吧！」）**不在任何静态文件**（BMD/exe/内存/GPU 字形纹理，详见 VOICE_TEXT_RESEARCH.md）。
2. 静态提取不可行 → 唯一可行途径：**Whisper 语音识别**（把日文语音转成文本）→ 再用**翻译模型**转中文。
3. 通用 Whisper 对 P5R 人名/场景词/实机语音识别差 → 必须**微调专用模型**。

---

## 三、AI 语音识别研究

### 3.1 数据链（全游戏规模）

```
ADX 语音（SOUND_J/EVENT AWB，acb_utils/adx_utils 解密）
  → WAV（16kHz 单声道）
  → 粗对齐 voice_text_aligned_full.json（15,732 条 / 749 AWB，BMD 台词↔语音 时间戳匹配）
  → Whisper 二次校验 realign_full_v5.py
  → 干净数据 voice_text_realigned_full.json（6,440 条 / 674 AWB，high 3,120 + medium 3,320）
  → 各版本训练集（v3/v4/v5/v6/v7/v8）
```

### 3.2 模型版本演进（核心：medium 微调方阵）

| 版本 | 训练数据 | 起点 | 九难句 | eval WER | 120短句 | 结论 |
|---|---|---|---|---|---|---|
| small-p5r-v2 | 早期 P5R 数据（~1万条） | whisper-small | 6/9* | - | **58.3%** | 原工具默认 |
| v2 (medium) | LoRA 早期 | whisper-medium | - | - | - | 过拟合，弃用 |
| v3 | 全量 + 数据泄漏修正 | whisper-medium | 4/9 | 227.2 | - | 数据泄漏修正 |
| **v4** | **27 难句 + 500 防遗忘** | v3 续训 | **9/9** | - | **80.0%** | ✅ **最终最优** |
| v5 | 全量增强 28,747（5 倍变速） | whisper-medium | 4/9 | 187.2 | 30.8% | 短句被破坏 |
| v6 | 27 难句 + 500 防遗忘 | v5 ckpt 续训 | 9/9 | 157.1 | 31.7% | 继承 v5 退化 |
| v7 | 全量 + 难句加权 | v6 merged | - | 崩溃(675) | - | merged→LoRA 加载坑 |
| v8 | 两阶段（阶段1 干净全量） | whisper-medium | - | 650 不降 | - | 干净数据收敛慢，终止 |

> *small 9 难句口径：历史记录 6/9；本报告严格口径（温度0/读音归一）实测 3/9。

### 3.3 关键教训（请后人务必记住）

1. **轻量微调 >> 全量增强**。v4 仅用 527 条（27 难句 + 500 防遗忘）就达到全面最优；v5 用 28,747 条增强数据反而把短句从 80% 打到 30.8%。**全量+增强会破坏 medium 的短句能力**。
2. **eval WER 低 ≠ 短句识别好**。v5 eval 187 但短句 30.8%；v6 eval 157 但短句 31.7%。必须以**实际短句 benchmark + 难句验收**为准。
3. **merged → LoRA 加载键不匹配（v7 崩溃根因）**：LoRALinear 参数键是 `X.base.weight/lora_A/lora_B`，merged 完整权重键是 `X.weight`。从 merged 往 LoRA 包装模型 `load_state_dict(strict=False)` 时所有 `X.weight` 成为 missing，base 保留**未微调原始权重** → 实际从基础模型起步训练，生成崩溃。**续训必须用 LoRA 结构 checkpoint（如 v5/v6 的 checkpoint-N），不要用 merged**。
4. **干净数据（无增强）收敛极慢**：v8 阶段1 用 5,744 条干净数据训 1400 步 eval 仍 650（v5 增强数据 1000 步已 566）。若走全量路线，**增强/变速数据不可省**。
5. **验证集必须零泄漏**：v5 曾把 val 泄漏进训练集导致 eval 失真，v3/v7 已修正（train/val 严格按 AWB 隔离）。
6. **难句需主动学习**：难句在数据集中占比极低（0.09%）会被淹没（v5 难句 4/9）。必须**过采样/专门构建难句子集**（v4/v6 的 27 难句 × 变速方案）。

### 3.4 推理参数优化（已固化进 voice_ai.py）

| 参数 | 值 | 原因 |
|---|---|---|
| device / compute | cuda / float16（无 GPU 回退 cpu/int8） | 提速（RTX 5060 每句 0.3-0.7s） |
| vad_filter | **False** | P5R 独立短语音，VAD 误滤轻音量句（wave7 道歉句） |
| initial_prompt | **禁用** | 微调模型已内化专有名词，prompt 反而干扰（wave7 被带偏成「ぜひぜひ」） |
| beam_size / temperature | 5 / 0.0 | 修正同音歧义（逃走/闘争 tōsō） |
| condition_on_previous_text | False | 每句独立 |
| 后处理 | 同音词校正表（闘争開始→逃走開始）+ p5r_terms 词表 | 双保险 |

### 3.5 最终验收（v4 vs small，统一口径：beam5/temp0/读音归一化）

| 指标（全量 696） | med_v4 | small | 领先 |
|---|---|---|---|
| 读音匹配 | **482/696（69.3%）** | 257/696（36.9%） | +32.4pt |
| 原文匹配 | **470/696（67.5%）** | 235/696（33.8%） | +33.7pt |
| 读音相似度 | **94.1%** | 85.9% | +8.2pt |
| 平均 WER | **30.7%** | 63.1% | 降一半 |
| 九难句 | **9/9** | 3/9 | +6 |

---

## 四、AI 翻译研究

### 4.1 翻译链路（三级兜底，由高到低）

```
1) official_translations.lookup_official(jp)   # 官方翻译查表（62 万条官方文本）
   → 命中 exact 标注「官方翻译」；fuzzy 命中标注「官方翻译(近似)」
2) p5r_terms.translate_with_note(jp)           # P5R 专有词表 + 规则翻译
   → 角色/人格面具/技能/常用语（3455 行词表，biligame 优先 + 萌娘百科）
3) NLLB-200-distilled-600M LoRA 微调           # 通用日→中（nllb-p5r-lora-v2）
   → CTranslate2 int8 量化，完全离线，0.2-0.6s/条
```

### 4.2 翻译模型细节

- **基础模型**：facebook/nllb-200-distilled-600M
- **微调**：LoRA（`finetune_nllb_lora.py`，平行语料 `parallel_corpus.json` / `_v2`）
- **产物**：`models/nllb-200-distilled-600M-p5r-v2-ct2`（CTranslate2 int8）
- **词表**：`p5r_terms.py`（3455 行）——角色名/人格面具/技能/战斗用语，专有名词优先官方译名
- **官方翻译库**：`official_translations.py` + `official_translations.json`（622 万字节，来自官方 BMD 反编译）

### 4.3 翻译来源标注

工具在输出中标注翻译来源：`官方翻译` / `官方翻译(近似)` / `AI翻译`，便于使用者判断可信度。

---

## 五、关键文件与模型索引

### 模型（models/ 目录）
| 模型 | 说明 |
|---|---|
| `faster-whisper-small-p5r-v2/` | small 微调（原默认） |
| **`faster-whisper-medium-p5r-v4-local/`** | **✅ 当前最优（工具 medium 指向）** |
| `faster-whisper-medium-p5r-v5-local/` / `v6-local` | 全量/难句版本（参考，勿用） |
| `nllb-200-distilled-600M-p5r-v2-ct2/` | NLLB 日中翻译（CTranslate2） |

### 数据与脚本
| 文件 | 说明 |
|---|---|
| `voice_text_aligned_full.json` / `voice_text_realigned_full.json` | 全量对齐/干净数据 |
| `p5r_voice_dataset_v{3..8}/` | 各版本训练集（v4 = 527 条，v5 = 28,747 增强，v8 = 两阶段） |
| `finetune_whisper_medium_v{3,4,5,6,7}.py` | medium 微调脚本（v4 为最优配置参考） |
| `finetune_whisper_medium_v8_stage1.py` | 两阶段脚本（已终止，参考） |
| `precompute_mel_v6.py` | mel 预计算（训练提速 3 件套之一） |
| `convert_medium_v{4,5,6}_to_ctranslate2.py` | CTranslate2 转换模板 |
| `compare_v6.py` / `verify_v4_final.py` | 九难句验收脚本 |
| `benchmark_v6_vs_small_v3.py` / `comprehensive_benchmark_v4.py` | 短句/全量 benchmark 脚本 |
| `voice_ai.py` | 工具 AI 识别模块（推理参数已优化） |
| `p5r_terms.py` / `official_translations.py` | 翻译词表/官方库 |

### 训练提速三件套（v6 起沿用）
1. **mel 预计算缓存**（`precompute_mel_v6.py`，避免每步重算 log-mel）
2. **TF32**（RTX 50 系，`torch.backends.cuda.matmul.allow_tf32=True`）
3. **dataloader 并行**（num_workers=2 + persistent + prefetch=4）

---

## 六、给后人的建议（正确路线）

**如果你要重训/再升级 medium，直接照抄 v4 路线，不要重复 v5-v8：**

1. **数据**：全量干净数据（realigned 6,440）+ **主动学习难句子集**（九难句 × 变速），训练集几百条即可，不要全量增强。
2. **起点**：从基础 whisper-medium（或 v3 之后的有理 checkpoint）续训，**用 LoRA 结构 checkpoint 续训，绝不从 merged 加载**。
3. **验收**：必须同时过 **① 九难句 9/9 ② 全量 696 读音匹配率 ③ 120 短句 benchmark** 三道关，单看 eval WER 会误判。
4. **推理**：禁 VAD、禁 initial_prompt、beam5 + temp0 + 同音词校正，GPU float16。
5. 若只是用工具：**medium 已指向 v4，无需再训练**。

---

*记录时间：2026-09-03 · 工具版本：P5R BGM Editor · 研究执行：主流程多轮微调实验 + 严格验收*

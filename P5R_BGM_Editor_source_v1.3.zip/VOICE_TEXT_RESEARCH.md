# P5R 实机流程语音字幕溯源研究报告

> 本文档记录对《女神异闻录5 皇家版》(Persona 5 Royal / P5R) 一类特殊字幕的完整调查过程与结论。
> 写给后来的工具维护者、Mod 作者和逆向研究者——**避免重复踩坑**，并理解这类文本为什么"找不到"、目前工具是如何处理的。

---

## 一、一句话结论

P5R 的 **"实机流程语音字幕"**（说话者用"少年般的声音 / 少女般的声音"等**泛称**、BMD 剧本中**没有对应文本**、由引擎脚本直接调用语音的字幕）**不存在于任何静态文件**（CPK / BMD / exe / tables / LSD / 社区工具全部穷尽）。它以 **GPU 预渲染字符字形纹理**形式在运行时逐字渲染，**不进入系统内存、不进入文件**，只能通过运行时手段（RenderDoc 帧捕获等）获取。

---

## 二、触发案例（调查起点）

| 项 | 内容 |
|---|---|
| 目标句 | **「好，开始逃走吧！」**（说话者"少年般的声音"） |
| 语音 | `E100_101.AWB` wave6 = cue `e100101_006_0003` |
| 日文 | `よし、逃走開始だ！` |
| 官方简体中文 | 好，开始逃走吧！ |
| 场景 | 开场赌场序章，跳过过场动画后第一句（玩家第一个看到的对话） |
| 状态 | ✅ 已通过游戏屏幕确认官方文本，固化进 `voice_extra_flow_text.json`（note=`官方文本（内存抓取）`） |

> ⚠️ 日文同音陷阱：`闘争開始` 与 `逃走開始` 读音相同（tōsō）。Whisper 三温度识别中，temp0.0/0.3 =「闘争開始」、temp0.8 =「逃走開始」——这正是"作战开始"与"开始逃走"语义歧义的来源。

---

## 三、穷尽调查清单（全部为已验证死路，请勿重试）

以下每一项都**实际执行过**，结果全部为"无目标句"。后人不要再浪费时间重复这些方向。

| # | 调查对象 | 方法 | 结果 |
|---|---|---|---|
| 1 | SC.CPK 全部 **2014 个 BMD** | AtlusScriptCompiler 逐一反编译（missing=0） | ❌ 无目标句 |
| 2 | BASE.CPK 全部 **1778 个 BMD** | 1GSM 压缩格式，`-Encoding P5` 全反编译 | ❌ 无目标句 |
| 3 | 中文台词库 `p5r_text_database_chs.json`（51070 条） | 搜「开始逃/逃走吧/逃走/少年般的声音」 | ❌ 0 命中 |
| 4 | SC/BASE 的 FTD / BF / EVT / DAT / BIN / 独立 MSG / PAC | 全部提取分析 | ❌ 无目标句 |
| 5 | BASE 的 **1761 个 .TXT**（与场景 BMD 同名）+ 35151 个其它扩展名文件 | 字节扫描 | ❌ 0 命中（TXT 只是脚本路径引用） |
| 6 | BASE 的 **52 个 .LSD**（47 个非空） | 大端偏移表 + Shift-JIS 解析 | ❌ 无（E100_002/004.LSD 是 12 字节空壳） |
| 7 | **P5R.exe**（377MB） | 明文 + zlib 8747 块解压 + LZ4 | ❌ 全 0 |
| 8 | 游戏**运行时内存扫描** | UTF-16LE / UTF-8 简繁 / GBK / 单字"逃" | ❌ 目标句 0 命中（单字"逃"有 24 条其它字幕 → 证明文本池在内存但目标句不在） |
| 9 | 标准 Windows API Hook | GDI `ExtTextOutW/TextOutW`、User32 `DrawTextW`、Direct2D/DirectWrite（未加载）、`MultiByteToWideChar/WideCharToMultiByte`、`wcscpy` | ❌ 全部 0 触发 |
| 10 | 社区工具 **P5R-Translation-Tool**（Meloman19，可从 exe 提取文本，Steam 1.0.4） | 完整下载+源码分析+对中文版 exe 提取 | ❌ exe 文本（MOVIE/OTHER/ARRAY/BMD/main TSV）**不含对话字幕** |
| 11 | B 站 / 中文社区资料 | 检索字库编码、文本编辑器、解包教程 | ❌ 无任何"实机语音字幕"提取方案 |
| 12 | SOUND_J/E.CPK、MOVIE_JE.CPK | 文件枚举 | ❌ 无文本类文件（仅 acb/awb/usm） |

---

## 四、为什么找不到（技术根因）

1. **P5R 是 Atlus 自研引擎**，不是 Unity / Unreal（无 UnityPlayer.dll / GameAssembly.dll / P5R_Data）。
2. **字幕通过 D3D11 直接渲染字体纹理**：每个字符 = 一个独立的 **96×96 预渲染字形纹理**（2D Render Target）+ 一次 `DrawIndexed(4)`。
3. 文本被**预渲染成 GPU 字形纹理**后，系统内存里没有纯文本字符串，普通内存扫描 / API Hook 全部失效。
4. **说话者泛称单独管理**：BMD 剧本中的说话者带角色名（如 `E100_101.msg` 仅 wave1-5 有文本且说话者为"少年的声音（坂本龙司）"等），而实机流程语音的说话者是泛称，两者分离。

---

## 五、如何拿到（已验证有效的方法）

**RenderDoc 帧捕获**（唯一成功路径）：

1. 用 RenderDoc（v1.46+，`C:\Users\凯梦\RenderDoc\RenderDoc_1.46_64\qrenderdoc.exe`）启动 P5R（Steam 需先登录，P5R 是 Steam AppID 1687950）。
2. 新游戏 → 空槽位 → 跳过免责声明/开场白 → 到达目标字幕。
3. 目标字幕停留时按 `F12` / `PrtScrn` 捕获帧（**F12 捕获还会自动打开 LOG&VOICE 面板**，历史对话一起显示）。
4. 在 RenderDoc 中逐 EID 分析 `DrawIndexed(4)` 事件，查看每个事件的输入纹理（字形纹理）。
5. 最终渲染目标（如 2560×1440 R8G8B8A8）上可直接读出官方简体中文文本。

> 关键发现：P5R 字幕 = **每个字符一个字形纹理 + 一次 Draw**，且字形纹理跨句复用。这解释了为什么内存 0 命中。

---

## 六、工具的解决方案（当前实现）

对"有语音但无 BMD 台词文本"的流程语音，工具通过独立文件补充参考文本，**不污染官方中文台词库**：

- **`voice_extra_flow_text.json`**：结构 `awb_extra_flow.E100_101.wave5~14`，每条含 `cue` / `jp` / `zh`（AI 识别参考文本）。
- **main.py**：`EXTRA_FLOW_TEXT_FILE` 常量 + `_get_extra_flow_text()` 方法 + `_build_jp_text_with_match` / `_build_subtitle_text_with_match` 两函数，接入流程语音显示。
- 获取到官方文本后，在对应条目加 `"note": "官方文本（内存抓取）"`，改前备份（如 `.bak_mem`），改后 `json.load` 验证。
- AI 识别链路：**Whisper small 微调**（日语识别，`whisper-small-p5r-v2`）→ **NLLB-200-distilled-600M LoRA 微调**（日→中，`nllb-p5r-lora-v2`），P5R 词表优先 biligame（次选萌娘百科）。
- 注意：AI 识别文本与官方文本的相似度目标 ≥90%，但**获取官方文本仍以人工确认 + 运行时抓取为准**。

---

## 六-补、AI 识别模型优化记录（2026-09-02，voice_ai.py 已按此优化）

**背景**：P5R 实机语音的日文无法从文件提取（见第九节），只能靠 Whisper 语音识别。工具内置微调模型 `faster-whisper-small-p5r-v2`（CTranslate2）。以下优化经实测验证后固化进 `voice_ai.py`（备份 `voice_ai.py.bak_optimize`）。

### 1. 推理加速：GPU float16（替代 CPU int8）
- 原配置 `device="cpu", compute_type="int8"`——完全没用上独显。
- 优化：自动检测 `torch.cuda.is_available()`，有 GPU 用 `cuda/float16`（RTX 5060 实测：medium 加载 2.8s，每句 0.3~0.7s），无 GPU 回退 `cpu/int8`。

### 2. 禁用 VAD（重要！）
- 原配置 `vad_filter=True`（min_silence=200ms/min_speech=150ms）。
- **问题**：P5R 每个 wave 是独立短语音，VAD 会把轻音量短句**误滤为静音**。典型案例 **wave7**（道歉「ごめん、ごめん…」音量低）被滤成空 → 工具原标记"静音/占位"，实为 VAD 误滤。
- 优化：`vad_filter=False`。wave7 立即可正确识别「ごめん、ごめん。ごめん、ごめん、ごめん。」。

### 3. 禁用 initial_prompt（关键教训！）
- 原配置带 P5R 词表 initial_prompt（角色名/人格面具/场景词），并按 AWB 前缀动态追加场景 hint。
- **问题**：**任何 initial_prompt 都会干扰短句识别**。实测 wave7 加 prompt 后从「ごめん、ごめん…」被带偏成「ぜひ、ぜひ、ぜひ…」；wave6 加不加都行；wave9 有/无 prompt 均受音频限制。
- 原因：`small-p5r-v2` 是 P5R **微调**模型，已内化角色/人格面具词汇，**不需要 prompt 提示**；prompt 反而压低了对实际语音的忠实度。
- 优化：移除 initial_prompt（专有名词修正交由后处理 `p5r_terms.translate_with_note` 承担）。

### 4. 最优解码参数（实测确认）
- `beam_size=5 + temperature=0.0 + condition_on_previous_text=False`——可稳定修正同音歧义（wave6「逃走開始」vs「闘争開始」）。
- 保留后处理同音词校正表（`闘争開始→逃走開始` 等），双保险。

### 5. 模型选择结论（勿盲目升 medium/large！）
- 对比实测：**small-p5r-v2（微调）整体优于 medium（通用未微调）**：
  | 句 | small-p5r-v2 | medium |
  |---|---|---|
  | wave7 | ごめん、ごめん… ✅ | はっはっは…（循环大笑）❌ |
  | wave11 | ジョーカーに集まってる ✅ | 上巻に集まってる ❌ |
  | wave6/8/10/12/13/14 | 全对 ✅ | 全对 ✅ |
  | wave9 | うまい用途（错） | 上手い洋道（略好仍错） |
- medium 未微调导致 P5R 人名/场景词识别反而更差。**保持 small-p5r-v2 为默认**。
- **wave9 局限**（「客の上で、会えて姿をさらしたのはうまい用途」vs 参考「客の前で堂々と…上手い手」）：赌场背景噪音下的声学混淆，参数/模型升级均难解决（无 large-v3 本地模型，3GB 下载成本高）。wave9 的参考文本已在 `voice_extra_flow_text.json`，不影响使用。

### 6. 优化后全量验证（E100_101 wave5-14，GPU 下 10 句共 15.9s 含首次加载）
- wave6「よし、逃走開始だ!」✅（同音歧义已修正）
- wave7「ごめん、ごめん。ごめん、ごめん、ごめん。」✅（VAD 误滤已修复，已固化 note=AI识别（优化模型））
- wave8/10/11/12/13/14 全对 ✅；wave10 命中官方翻译「嘿嘿嘿，不愧是ＪＯＫＥＲ」
- wave9 受音频限制（见上）

---

## 七、编码知识（重要，避免再踩坑）——【2026-09-02 已修正】

- 中文版 P5R 使用**简体字库 + Atlus 自研编码**（`.FNTMAP` 字符→字形映射），**不是** UTF-8 / UTF-16LE / GBK——这就是普通编码扫描找不到 Atlus 文本的根本原因。
- **✅ 正确编码名（本轮实测确认）**：
  - **简体中文 → `P5R_CHS`**（对应 `Atlus-Script-Tools\Charsets\P5R_CHS.tsv`，473 行/30KB）——完美解出「闹得真够大的」「接下来听NAVI的指示」等官方简体文本。
  - **日文 → `P5R_Japanese`**——完美解出「さすがジョーカー、うまい陽動だ」等。
  - 命令：`AtlusScriptCompiler.exe -In <bmd> -Decompile -OutFormat V1 -Encoding P5R_CHS -Out <out>`
- **⚠️ 纠错**：`AtlusMSGEditor\Charsets\P5R_Chinese.tsv` 是**错误**字符表（会中文乱码，勿用）；`-Encoding P5` 也会导致中/日文乱码。
- **⚠️ 关键教训**：此前用 `-Encoding P5` 反编译 BASE.CPK 得出"无目标句"的结论**不可靠**（乱码导致搜索失效）。2026-09-02 已用 `P5R_Japanese` 全量重反编译 BASE 1778 个 BMD，确认日文原版确实无「逃走開始」——这才是可靠结论。
- BASE.CPK 的 BMD 是 **1GSM 压缩**（文件头 `0700000000000606 3147534D`），直接字节扫描无效，必须反编译。
- 社区字库编码对照表：B站 cv19937910（P4G 繁体 / P5R 简体，用于替换 name.tbl 中的面具/敌人/技能/物品名，有字数限制）。

- **字符集扩充备用方案（2026-09-02 记录，B站 OPUS「为 atlus script tools 添加简中字符集」）**：
  - 链接：`https://b23.tv/n3tQUjM`（OPUS 732865860631265334）；仓库：`https://github.com/lraty-li/Persona-Modding/tree/main/charset_for_atlus_script_tool`
  - **原理**：用 PersonaEditor 从游戏字体 `FONT0.FNT` 导出字形 PNG → 切 96×96 单字符图 → 找相近电脑字体生成全字形 → annoy 向量库 + 余弦相似度**自动匹配「字形→字符」** → 输出 tsv 放 Charsets 文件夹，`-Encoding 文件名` 直接用。
  - **参考价值**：提供"从游戏字体自动扩充/重建字符集"的完整技术路径，输出格式与现有 P5R_CHS.tsv 兼容；适合**未来遇到生僻字缺失导致反编译乱码**时补全字符集。
  - **局限（作者自述）**：① 生僻字识别准确率不保证，作者**建议优先用手工维护的字-字库编码对照表**（另一篇 B 站专栏）；② 繁中 FONT0.FNT 导出有 bug（1535×83040 超大图，缩小后后半重复）；③ 字体与游戏字形非一一对应（例 `㈫` 被误配到「火」），需人工校正；④ 建议用「华康圆体简繁-Std-W9」，准确率较高。
  - **现状结论（2026-09-02 实测）**：现有 `P5R_CHS.tsv`（473 行字符矩阵 ≈ 7478 字符）+ `P5R_Japanese` 覆盖良好——SC.CPK 2014 BMD 反编译 missing=0，抽查 500 个 msg **0 个 U+FFFD 替换字符**。**当前字符集够用，此方案仅作备用**；若日后处理繁中/生僻字/其它 Atlus 游戏字符集时启用。

---

## 八、存档安全记录

- 用户存档：`C:\Users\凯梦\AppData\Roaming\SEGA\P5R\Steam\76561199473506283\savedata\`（槽位 1 = `DATA01\DATA.DAT` 有档；槽位 2~20 空）。
- 整个调查过程**全程新游戏选空槽位、不手动保存**，未触碰 DATA01。
- 完整备份位于项目目录 **`_saves_backup\`**（请勿删除）。

---

## 九、未来方向（批量获取所有实机语音字幕）——【2026-09-02 更新：规模已量化】

**⚠️ 决定性验证（2026-09-02）：实机语音字幕确实不在任何静态文件。**
- SC.CPK（简体中文）**2014 个 BMD** + BASE.CPK（日文原版）**1778 个 BMD** = **3792 个 BMD 全部用正确编码（P5R_CHS / P5R_Japanese）反编译**，搜索「好，开始逃走吧 / 逃走開始 / よし、逃走」等关键词：**0 命中**。
- SC.CPK 的 PAK/GMD/EPL/DAT/MSG/FTD 全部为 UI/战斗/字段系统资源，无事件字幕；ACB/AWB 仅含音频元数据（cue 名 = ID，非字幕）；MOVIE_JE 仅 .USM 视频。
- **✅ 2026-09-02 编码补扫（日文）**：对 BASE.CPK 全部**小文本文件（9524 个）**与**大文本文件（12960 个）**、SC.CPK 大文本文件（1122 个），用 **UTF-8 / UTF-16LE / Shift-JIS 三种编码**字节搜索「逃走開始」——**全部 0 命中**（此前字节扫描仅用 UTF-8，现已补齐日文常用编码）。
- **结论：实机语音字幕的日文与中文均不在任何静态文件（无论编码/文件类型/大小），是引擎运行时动态生成（GPU 字形纹理），静态提取不可行。**

> **日文获取途径**：文件提取不可行（已证明）。可行途径 = ① **Whisper 语音识别**（`faster-whisper-small-p5r-v2` 微调模型，GPU 约 0.6s/句，`beam_size=5 + temperature=0.0` 可修正同音歧义如「逃走/闘争」，已实测 E100_101 全部 10 句与官方/参考高度一致）；② 运行时切日文字幕 + RenderDoc 捕获（官方准确）。

**📊 实机流程语音规模（全游戏量化，2026-09-02）：**
- 全游戏含 `e{event}_{n}_{n}` 格式语音 cue 的事件 AWB 共 **605 个**；其中 **555 个存在"语音溢出"**（wave/cue 数 > BMD 匹配字幕数），**实机流程语音约 6774 句**。
- E100_101 为典型：**14 个语音 cue，BMD 仅 4 条字幕，溢出 10 句实机语音**（wave5-14，含 wave6「好，开始逃走吧！」）。
- 精确判定公式：实机语音数 ≈ `e 格式 cue 数 − BMD 匹配消息数`（排除 `e000000_000_0000` 占位 cue 与 `_SE` 音效）。
- 已生成 **`voice_overflow_candidates.csv`**（1250 个 wave 溢出 AWB，含 wave 数 / BMD 消息数 / 溢出量 / cue 样本）。

若要批量拿到所有这类字幕，静态文件路线已确认不通，只有运行时路线：

1. **Frida Hook D3D11 `DrawIndexed`**（最可行）：每个字符 = 一次 Draw，字形纹理跨句复用 → 建立"字形纹理哈希 → 字符"映射表（用已知字幕学习或 OCR 识别字形）→ 游戏内任何实机字幕自动解码。
2. **x64dbg 动态调试**：在 `DrawIndexed` / `CreateTexture2D` 下断点，回溯文本读取函数。
3. **RenderDoc 批量帧捕获**：每个实机字幕出现时捕获，从 GPU 纹理 OCR / 人工读取。
4. 注意：即使有映射表，**仍需让每句语音在游戏里实际播放**才能捕获对应帧——这是无法绕过的场景触发成本。

---

## 十、关键文件清单

| 文件 | 说明 |
|---|---|
| `voice_extra_flow_text.json` | 流程语音参考文本（AI 识别 + 已确认官方文本） |
| `voice_extra_flow_text.json.bak_mem` | 内存抓取前的备份 |
| `voice_extra_flow_candidates.csv` | 实机流程语音候选清单（430 个无 BMD 匹配事件 AWB） |
| `_saves_backup\` | 用户存档完整备份 |
| `extracted_sc_bmd\` | SC.CPK 全部 BMD 反编译产物（msg，P5R_CHS 简体） |
| `extracted_base_bmd\` | BASE.CPK 全部 BMD 反编译产物（msg，P5R_Japanese 日文） |
| `extracted_base_lsd\` | BASE.CPK 全部 LSD 文件 |
| `p5r_text_database_chs.json` | 中文台词库（51070 条，来自官方 BMD） |
| `_tmp_firstline.png` | 目标句游戏截图证据 |
| `tools\AtlusMSGEditor\AtlusScriptCompiler.exe` | BMD 反编译工具（`-Encoding P5`） |
| `tools\CriFsV2Lib\` | CPK 解包库（pythonnet） |

---

*记录时间：2026-09-02 · 工具版本：P5R BGM Editor v1.3.0 · 调查执行：主流程 + OrganizeAgent 多轮验证*

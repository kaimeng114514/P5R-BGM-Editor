﻿# -*- coding: utf-8 -*-
"""
voice_ai.py - P5R 语音台词 AI 识别模块
基于 faster-whisper 离线识别日文台词，支持 small / medium / large-v3 模型切换。
配合 P5R 专有词表（p5r_terms.py）做词汇校正与中文翻译。

模型存放于工具目录 models/ 下，首次使用自动下载。
模型大小配置保存在 ai_config.json。
"""
import os
import sys
import tempfile
import threading
from pathlib import Path

# 模型目录（工具目录下 models/）
MODEL_DIR = Path(__file__).resolve().parent / "models"
# 本地预下载模型目录（打包内置，避免运行时网络下载）
# 结构: models/faster-whisper-{size}-local/  包含 model.bin, config.json, tokenizer.json 等
LOCAL_MODEL_DIRS = {
    "small": MODEL_DIR / "faster-whisper-small-p5r-v2",
    # medium 已升级为 P5R 专用微调模型（LoRA 微调 2026-09-02）
    # 旧版未微调 medium 保留在 faster-whisper-medium-local（可回退）
    "medium": MODEL_DIR / "faster-whisper-medium-p5r-v4-local",
    "large-v3": MODEL_DIR / "faster-whisper-large-v3-local",
}
# 配置文件路径
CONFIG_FILE = Path(__file__).resolve().parent / "ai_config.json"
# 支持的模型大小
SUPPORTED_MODELS = ["small", "medium", "large-v3"]
# 默认模型大小（medium 是识别率和速度的平衡点）
DEFAULT_MODEL = "medium"

# 全局单例 + 加载锁
_engine = None
_engine_lock = threading.Lock()
_engine_loading = False
# 预加载状态（应用启动时后台预热模型）
_preload_started = False
_preload_done = False
_preload_error = None


def get_model_size():
    """从配置文件读取当前模型大小，不存在则返回默认值"""
    try:
        if CONFIG_FILE.exists():
            import json
            with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                cfg = json.load(f)
            size = cfg.get("model_size", DEFAULT_MODEL)
            if size in SUPPORTED_MODELS:
                return size
    except Exception:
        pass
    return DEFAULT_MODEL


def set_model_size(size):
    """设置模型大小并保存到配置文件，切换后需重启工具或调用 reload_model()"""
    if size not in SUPPORTED_MODELS:
        raise ValueError(f"不支持的模型大小: {size}，可选: {SUPPORTED_MODELS}")
    try:
        import json
        cfg = {"model_size": size}
        with open(CONFIG_FILE, "w", encoding="utf-8") as f:
            json.dump(cfg, f, ensure_ascii=False, indent=2)
        return True
    except Exception:
        return False


def reload_model():
    """重置已加载的模型引擎，下次识别时按新配置重新加载"""
    global _engine
    with _engine_lock:
        _engine = None
    return True


def _get_engine():
    """获取 faster-whisper 引擎（懒加载，只加载一次）"""
    global _engine, _engine_loading
    if _engine is not None:
        return _engine
    with _engine_lock:
        if _engine is not None:
            return _engine
        try:
            # 使用国内镜像源下载模型（Hugging Face 在国内访问不稳定）
            os.environ.setdefault("HF_ENDPOINT", "https://hf-mirror.com")
            # 禁用 xet 存储（cas-server.xethub.hf.co 会返回 401 Unauthorized）
            os.environ.setdefault("HF_HUB_DISABLE_XET", "1")
            from faster_whisper import WhisperModel
        except ImportError:
            raise RuntimeError(
                "未安装 faster-whisper 依赖。请运行: py -m pip install faster-whisper"
            )
        _engine_loading = True
        try:
            model_size = get_model_size()
            # 推理设备自动检测：优先 GPU（RTX 系列），否则 CPU。
            # GPU 用 float16（速度快、精度高），CPU 用 int8（量化加速）。
            try:
                import torch
                _use_cuda = bool(torch.cuda.is_available())
            except Exception:
                _use_cuda = False
            _device = "cuda" if _use_cuda else "cpu"
            _compute = "float16" if _use_cuda else "int8"
            # 优先使用本地预下载模型目录（避免运行时网络下载失败）
            local_dir = LOCAL_MODEL_DIRS.get(model_size)
            if local_dir and local_dir.exists() and (local_dir / "model.bin").exists():
                model_path = str(local_dir)
                print(f"[AI] 使用本地模型: {model_path} ({_device}/{_compute})")
                _engine = WhisperModel(
                    model_path,
                    device=_device,
                    compute_type=_compute,
                )
            else:
                # 本地模型不存在，回退到自动下载（使用国内镜像 + 禁用 xet）
                print(f"[AI] 本地模型未找到，尝试下载: {model_size} ({_device}/{_compute})")
                _engine = WhisperModel(
                    model_size,
                    device=_device,
                    compute_type=_compute,
                    download_root=str(MODEL_DIR),
                )
        finally:
            _engine_loading = False
        return _engine


def is_loading():
    return _engine_loading


def preload_model():
    """后台线程预热模型（应用启动时调用，避免首次识别等待）。

    注意：模型加载耗时长（medium 约 1.5GB），必须在后台线程调用。
    模型加载完成后 _preload_done 置 True，_get_engine() 直接返回已加载引擎。
    若模型不可用（未安装依赖等），静默失败，首次识别时再报错。
    """
    global _preload_started, _preload_done, _preload_error
    if _preload_started:
        return
    _preload_started = True
    _preload_done = False
    _preload_error = None

    def _do():
        global _preload_done, _preload_error
        try:
            # 本地模型不存在时跳过预加载（避免启动时触发网络下载）
            model_size = get_model_size()
            local_dir = LOCAL_MODEL_DIRS.get(model_size)
            if not (local_dir and local_dir.exists() and (local_dir / "model.bin").exists()):
                _preload_done = True
                _preload_error = f"本地模型 {model_size} 不存在，首次识别时再下载"
                return
            _get_engine()
            _preload_done = True
            print("[AI] 模型已后台预加载完成")
        except Exception as e:
            _preload_error = str(e)
            _preload_done = True
            print(f"[AI] 后台预加载失败（不影响首次识别自动加载）: {e}")

    t = threading.Thread(target=_do, daemon=True, name="ai-model-preload")
    t.start()


def is_preloaded():
    """模型是否已完成预加载（无论成功失败）"""
    return _preload_done


def preload_error():
    return _preload_error


def is_available():
    """检查是否已安装 faster-whisper"""
    try:
        import faster_whisper  # noqa: F401
        return True
    except ImportError:
        return False


def transcribe(wav_path, language="ja", context=None):
    """
    识别 WAV 音频中的语音并翻译。
    context: 可选上下文 dict，如 {"awb": "E080_040", "wave_id": 2450000}，
             用于动态调整 initial_prompt 提升识别准确率。
    返回 dict: {
        "jp": 日文识别文本,
        "zh": 中文翻译,
        "terms": 命中的 P5R 专有名词列表,
        "ok": bool,
        "error": 错误信息(可选)
    }
    """
    try:
        from p5r_terms import translate_with_note
    except ImportError:
        from p5r_terms import translate_with_note  # noqa

    try:
        model = _get_engine()
    except Exception as e:
        return {"ok": False, "error": f"模型加载失败: {e}"}

    try:
        # 【识别参数优化说明】
        # 1) 禁用 initial_prompt：small-p5r-v2 是 P5R 微调模型，已内化角色/人格面具等词汇，
        #    实测加 prompt 反而干扰识别（例：wave7「ごめん、ごめん…」被 prompt 带偏成「ぜひ、ぜひ…」）。
        # 2) 禁用 VAD：P5R 每个 wave 是独立短语音，VAD 会把轻音量短句（如道歉「ごめん、ごめん…」）误滤为静音。
        # 3) beam_size=5 + temperature=0.0：可修正同音歧义（wave6「逃走開始」vs「闘争開始」）。
        # 4) 专有名词等词汇修正由后处理 p5r_terms.translate_with_note + 下方同音词校正表承担。
        segments, info = model.transcribe(
            wav_path,
            language=language,
            beam_size=5,
            vad_filter=False,
            condition_on_previous_text=False,
            temperature=0.0,
        )
        # 收集片段文本
        parts = []
        for seg in segments:
            t = seg.text.strip()
            if t:
                parts.append(t)
        jp_text = "".join(parts)
        # P5R 场景同音词校正（高置信修正，避免同音陷阱；只改确定性的词）
        _homophone_fixes = {
            "闘争開始": "逃走開始",   # tōsō kaishi：P5R 逃跑场景（实机语音）几乎均为「逃走」
            "闘争する": "逃走する",
        }
        for _wrong, _right in _homophone_fixes.items():
            if _wrong in jp_text:
                jp_text = jp_text.replace(_wrong, _right)
        if not jp_text.strip():
            return {
                "ok": True,
                "jp": "",
                "zh": "",
                "terms": [],
                "note": "未识别到清晰语音（可能为纯音效/背景音乐）",
            }
        zh, hits = translate_with_note(jp_text)
        # 判断翻译来源：优先官方翻译查表（exact/fuzzy），否则为 AI 翻译
        zh_source = "AI翻译"
        try:
            from official_translations import lookup_official
            _, match_type = lookup_official(jp_text)
            if match_type == "exact":
                zh_source = "官方翻译"
            elif match_type.startswith("fuzzy"):
                zh_source = "官方翻译(近似)"
        except Exception:
            pass
        return {"ok": True, "jp": jp_text, "zh": zh, "terms": hits, "zh_source": zh_source}
    except Exception as e:
        return {"ok": False, "error": f"识别失败: {e}"}


def transcribe_file(path, language="ja", context=None):
    """
    直接识别任意音频文件（自动用 ffmpeg 转 WAV，若 ffmpeg 可用）。
    path: 音频文件（.adx/.wav/.mp3 等）
    """
    # 若是 adx，优先用 ADXProcessor 转换（保持 P5R 解密正确）
    ext = Path(path).suffix.lower()
    if ext == ".adx":
        return transcribe_adx(path, language, context=context)
    # 其他格式：尝试 ffmpeg 转 wav
    wav_path = _to_wav_via_ffmpeg(path)
    if wav_path:
        try:
            return transcribe(wav_path, language, context=context)
        finally:
            try:
                os.remove(wav_path)
            except Exception:
                pass
    # 已是 wav 直接识别
    return transcribe(path, language)


def transcribe_adx(adx_path, language="ja", context=None):
    """识别 ADX 语音：先用 ADXProcessor 解密转 WAV，再识别"""
    tmp_wav = None
    try:
        try:
            from adx_utils import ADXProcessor
        except ImportError:
            from adx_utils import ADXProcessor  # noqa

        tmp_wav = tempfile.mktemp(suffix=".wav", prefix="p5r_ai_")
        proc = ADXProcessor()
        proc.decrypt_adx_to_wav(adx_path, tmp_wav)
        return transcribe(tmp_wav, language, context=context)
    except Exception as e:
        return {"ok": False, "error": f"ADX 转 WAV 失败: {e}"}
    finally:
        if tmp_wav and os.path.exists(tmp_wav):
            try:
                os.remove(tmp_wav)
            except Exception:
                pass


def _to_wav_via_ffmpeg(path):
    """用 tools/ffmpeg.exe 把音频转成 wav，返回临时 wav 路径"""
    tools_ffmpeg = Path(__file__).resolve().parent / "tools" / "ffmpeg.exe"
    ffmpeg_cmd = str(tools_ffmpeg) if tools_ffmpeg.exists() else "ffmpeg"
    tmp_wav = tempfile.mktemp(suffix=".wav", prefix="p5r_ai_")
    try:
        import subprocess
        r = subprocess.run(
            [ffmpeg_cmd, "-y", "-i", str(path), "-ar", "16000", "-ac", "1", tmp_wav],
            capture_output=True,
            timeout=120,
        )
        if r.returncode == 0 and os.path.exists(tmp_wav):
            return tmp_wav
        os.remove(tmp_wav)
    except Exception:
        pass
    return None


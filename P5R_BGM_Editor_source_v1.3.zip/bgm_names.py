# -*- coding: utf-8 -*-
"""
P5R BGM 曲名数据库
Wave ID -> 曲名 映射
Wave ID 对应 BGM.AWB 中曲目编号，即 00006_streaming.adx 中的 00006

数据来源: Amicitia Wiki - Persona 5 Royal/ps4R.cpk/sound/bgm.awb
https://amicitia.miraheze.org/wiki/Persona_5_Royal/ps4R.cpk/sound/bgm.awb
"""

# 完整的 BGM 曲目映射（Wave ID -> 曲名）
BGM_NAMES = {
    # === P5R 第三学期新增/主要曲目 ===
    0: "Endless Days",
    1: "Ideal and the Real (slightly different version?)",
    2: "No More What Ifs -instrumental version-",
    3: "No More What Ifs (vocal version)",
    4: "No More What Ifs (radio version)",
    5: "I Believe",
    6: "Take Over",
    7: "Keep Your Faith",
    8: "Throw Away Your Mask",
    9: "Our Light",
    10: "Gentle Madman",
    11: "Out of Kindness",
    12: "So Happy World",
    13: "Mementos -Middle Layer-",
    14: "Mementos -Lower Layer-",
    15: "Mementos -Upper Layer-",
    16: "Our Light",
    17: "Wake Up, Get Up, Get Out There (full version)",
    18: "With the Stars and Us (old ending)",
    19: "Wake Up, Get Up, Get Out There (old opening)",
    20: "Colors Flying High",

    # === 静音/占位 ===
    21: "(Silence)",

    # === 结局/标题 ===
    22: "Ideal and the Real -end version-",
    23: "Prison Labor",
    24: "Colors Flying High -opening movie version-",
    25: "Culture Festival Dance",
    26: "Kichijoji 199X",
    27: "Royal Days -another version-",
    28: "wish come true",
    29: "Ideal and the Real",
    30: "Royal Days (title screen)",

    # === P3/P4 战斗曲（DLC/额外） ===
    31: "Mass Destruction",
    32: "Reach Out to the Truth",
    33: "Mementos -New Layer-",

    # === 迷你游戏/设施 ===
    34: "He's a Trickster ☆",
    35: "Another Ideology",
    36: "Another Ideology",
    37: "Ideal and the Real -end version-",
    38: "Unknown (????????)",
    39: "Rivers in the Desert instrumental (short version)",
    40: "Crane Game",
    41: "Crossroads",
    42: "Triple Seven",
    43: "Endless Days",
    44: "Big Bang Burger March",
    45: "Planetarium",
    46: "Welcome Home, Master!",
    47: "Time to Repent",
    48: "Meiji Shrine",
    49: "Tanaka's Shady Commodities",
    50: "Home Electronics Store",

    # === 版本变体 ===
    51: "New Beginning ELP version",
    52: "New Beginning ELP version drums only",

    # === 静音 ===
    53: "(Silence)",

    # === 日常/氛围 ===
    54: "Disquiet",
    55: "My Homie",
    56: "The Spirit",
    57: "What's Going On",
    58: "Blood of Villain",
    59: "Regret",
    60: "New Beginning",
    61: "New Beginning no intro",
    62: "Interrogation Room",
    63: "Desire",
    64: "Suspicion",
    65: "Confession/Secret (no intro)",
    66: "Confession/Secret",
    67: "Alleycat no intro",
    68: "Alleycat",
    69: "So Boring",
    70: "Wicked Plan no intro",
    71: "Wicked Plan",
    72: "Days of Sisters",
    73: "Alright",
    74: "Alright ELP Version",
    75: "Break it Down",
    76: "Break it Down ELP Version",
    77: "Swear to My Bones",

    # === 战斗/殿堂 ===
    78: "Life Will Change",
    79: "Life Will Change Instrumental",
    80: "Life Will Change intro only",
    81: "Sunset Bridge no intro",
    82: "Sunset Bridge",
    83: "Sweet",
    84: "Run, Run, Run!",
    85: "Tension",
    86: "High Pressure",
    87: "Awakening Ryuji's intro",
    88: "Awakening Makoto's intro",
    89: "Life Goes On",
    90: "Layer Cake",
    91: "Butterfly Kiss",
    92: "Phantom (old title screen)",
    93: "Sweatshop another version",
    94: "Sweatshop",
    95: "Price another version",
    96: "Price",
    97: "King, Queen and Slave -another version-",
    98: "King, Queen and Slave",
    99: "Have a Short Rest",
    100: "The Days When Mother Was There",
    101: "The Days When Mother Was There Another Version",
    102: "A Woman another version",
    103: "A Woman",
    104: "Mementos",
    105: "Freedom and Peace",
    106: "Whims of Fate",
    107: "Ark",
    108: "Will Power",
    109: "Yaldabaoth",
    110: "Our Beginning",
    111: "Triumph",
    112: "Keeper of Lust",
    113: "Talk",
    114: "Blooming Villain",
    115: "Blooming Villain intro only",
    116: "Rivers in the Desert Instrumental",
    117: "Rivers In the Desert Vocals",

    # === 主要战斗曲 ===
    118: "Last Surprise",
    119: "Hymn of the Soul",

    # === 日常/探索 ===
    120: "Tokyo Emergency",
    121: "Tokyo Daylight",
    122: "Beneath the Mask instrumental",
    123: "Beneath the Mask vocals",
    124: "Beneath the Mask rain instrumental",
    125: "Beneath the Mask rain vocals",
    126: "Swear to My Bones no intro",
}

# 曲目分类标签（用于 UI 筛选）- 基于正确的 Wave ID 更新
BGM_CATEGORIES = {
    "战斗": [6, 78, 79, 80, 108, 112, 114, 115, 116, 117, 118, 31, 32],
    "日常": [57, 67, 68, 69, 83, 89, 90, 91, 99, 106, 121, 122, 123, 124, 125],
    "殿堂": [58, 63, 64, 65, 66, 70, 71, 78, 114, 116, 117],
    "印象空间": [13, 14, 15, 33, 104],
    "第三学期": [1, 2, 3, 4, 5, 7, 8, 9, 10, 11, 12, 22, 27, 29, 35, 36, 37],
    "标题/开场": [17, 19, 20, 24, 30, 92],
    "结局": [9, 16, 18, 22, 37],
    "事件": [54, 59, 62, 72, 77, 85, 86, 87, 88, 109, 110, 111, 113, 120, 126],
    "迷你游戏": [34, 40, 41, 42, 44, 45, 46, 47, 48, 49, 50],
    "氛围/其他": [0, 43, 55, 56, 60, 61, 73, 74, 75, 76, 81, 82, 84, 93, 94, 95, 96, 97, 98, 100, 101, 102, 103, 105, 107, 119, 23, 25, 26, 28, 39, 51, 52],
}


def get_bgm_name(wave_id: int) -> str:
    """根据 Wave ID 获取曲名，未知则返回占位符"""
    return BGM_NAMES.get(wave_id, f"未知曲目 (ID: {wave_id:05d})")


def get_wave_id_from_filename(filename: str) -> int:
    """从 ADX 文件名提取 Wave ID
    支持两种格式:
    - streaming_30.adx -> 30 (AWB Emulator 标准格式)
    - 00030_streaming.adx -> 30 (旧格式)
    """
    import re
    # 优先匹配 streaming_ 后面的数字
    match = re.search(r'streaming[_-](\d+)', filename, re.IGNORECASE)
    if match:
        return int(match.group(1))
    # 回退：匹配文件名开头的数字
    match = re.match(r'(\d+)', filename)
    if match:
        return int(match.group(1))
    return -1


def is_known_track(wave_id: int) -> bool:
    """检查曲目是否在数据库中"""
    return wave_id in BGM_NAMES
